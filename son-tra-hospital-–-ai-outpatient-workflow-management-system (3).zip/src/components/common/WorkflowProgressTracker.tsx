import React from 'react';
import { Visit, VisitStatus } from '../../types';
import { CheckCircle2, Clock, AlertTriangle, ArrowRight, ShieldAlert, XCircle } from 'lucide-react';

interface WorkflowProgressTrackerProps {
  visit: Visit;
  compact?: boolean;
}

interface StepDef {
  key: string;
  name: string;
  isComplete: (status: VisitStatus) => boolean;
  isCurrent: (status: VisitStatus) => boolean;
  isWarning?: (status: VisitStatus) => boolean;
  isFailed?: (status: VisitStatus) => boolean;
}

const WORKFLOW_STEPS: StepDef[] = [
  {
    key: 'register',
    name: '1. Đăng ký hồ sơ',
    isComplete: (s) => s !== 'registered',
    isCurrent: (s) => s === 'registered',
  },
  {
    key: 'symptom',
    name: '2. Khai triệu chứng',
    isComplete: (s) => !['registered'].includes(s),
    isCurrent: (s) => s === 'symptom_declared',
  },
  {
    key: 'triage',
    name: '3. Triage AI',
    isComplete: (s) => !['registered', 'symptom_declared', 'pending_triage', 'pending_emergency_eval'].includes(s),
    isCurrent: (s) => ['pending_triage', 'pending_emergency_eval'].includes(s),
    isWarning: (s) => s === 'pending_emergency_eval',
  },
  {
    key: 'reception',
    name: '4. Duyệt & Cấp QR',
    isComplete: (s) => !['registered', 'symptom_declared', 'pending_triage', 'pending_emergency_eval'].includes(s),
    isCurrent: (s) => s === 'approved',
  },
  {
    key: 'checkin',
    name: '5. Check-in & Hàng đợi',
    isComplete: (s) => !['registered', 'symptom_declared', 'pending_triage', 'pending_emergency_eval', 'approved'].includes(s),
    isCurrent: (s) => ['checked_in', 'calling'].includes(s),
    isFailed: (s) => s === 'missed',
  },
  {
    key: 'consultation',
    name: '6. Khám lâm sàng',
    isComplete: (s) => ['pending_paraclinical', 'paraclinical_delayed', 'paraclinical_completed', 'diagnosed', 'pending_payment', 'paid', 'completed'].includes(s),
    isCurrent: (s) => s === 'in_consultation',
  },
  {
    key: 'paraclinical',
    name: '7. Cận lâm sàng & CĐHA',
    isComplete: (s) => ['paraclinical_completed', 'diagnosed', 'pending_payment', 'paid', 'completed'].includes(s),
    isCurrent: (s) => ['pending_paraclinical', 'paraclinical_delayed'].includes(s),
    isWarning: (s) => s === 'paraclinical_delayed',
  },
  {
    key: 'diagnosis',
    name: '8. Kết luận bác sĩ',
    isComplete: (s) => ['diagnosed', 'pending_payment', 'paid', 'completed'].includes(s),
    isCurrent: (s) => s === 'diagnosed',
  },
  {
    key: 'payment',
    name: '9. Thanh toán & BHYT',
    isComplete: (s) => ['paid', 'completed'].includes(s),
    isCurrent: (s) => s === 'pending_payment',
  },
  {
    key: 'invoice',
    name: '10. Hóa đơn điện tử',
    isComplete: (s) => s === 'completed',
    isCurrent: (s) => s === 'paid',
  },
];

export const WorkflowProgressTracker: React.FC<WorkflowProgressTrackerProps> = ({ visit, compact = false }) => {
  if (visit.status === 'cancelled') {
    return (
      <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center justify-between text-rose-800 text-sm">
        <div className="flex items-center gap-2">
          <XCircle className="w-5 h-5 text-rose-600" />
          <span className="font-semibold">Lượt khám đã được hủy bỏ</span>
          <span className="text-xs text-rose-600">· Lý do: {visit.cancellationReason || 'Theo yêu cầu'}</span>
        </div>
        <span className="text-xs font-mono text-rose-500">{visit.cancelledAt}</span>
      </div>
    );
  }

  if (compact) {
    return (
      <div className="flex items-center gap-1 overflow-x-auto py-1">
        {WORKFLOW_STEPS.map((step, idx) => {
          const complete = step.isComplete(visit.status);
          const current = step.isCurrent(visit.status);
          const warning = step.isWarning && step.isWarning(visit.status);
          const failed = step.isFailed && step.isFailed(visit.status);

          let bg = 'bg-slate-100 text-slate-400';
          if (failed) bg = 'bg-rose-500 text-white';
          else if (warning) bg = 'bg-amber-500 text-white animate-pulse';
          else if (complete) bg = 'bg-emerald-600 text-white';
          else if (current) bg = 'bg-blue-600 text-white ring-2 ring-blue-300';

          return (
            <div key={step.key} className="flex items-center gap-1 shrink-0" title={step.name}>
              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${bg}`}>
                {idx + 1}
              </div>
              {idx < WORKFLOW_STEPS.length - 1 && (
                <div className={`w-3 h-0.5 ${complete ? 'bg-emerald-400' : 'bg-slate-200'}`} />
              )}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
      <div className="flex items-center justify-between mb-3 border-b border-slate-100 pb-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Tiến trình điều phối quy trình (AI Orchestrator)</span>
          <span className="text-xs text-slate-400">· Mã lượt: <strong className="text-slate-800 font-mono">{visit.id}</strong></span>
        </div>
        <div className="flex items-center gap-2">
          {visit.emergencyFlag && (
            <span className="flex items-center gap-1 text-xs font-semibold text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-md border border-rose-200">
              <ShieldAlert className="w-3.5 h-3.5" /> Ca Khẩn Cấp (Ưu tiên 1)
            </span>
          )}
          {visit.manualTriageFlag && (
            <span className="text-xs text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
              Phân luồng thủ công
            </span>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
        {WORKFLOW_STEPS.map((step, idx) => {
          const complete = step.isComplete(visit.status);
          const current = step.isCurrent(visit.status);
          const warning = step.isWarning && step.isWarning(visit.status);
          const failed = step.isFailed && step.isFailed(visit.status);

          let border = 'border-slate-200 bg-slate-50/60 text-slate-500';
          let icon = <Clock className="w-4 h-4 text-slate-400 shrink-0" />;

          if (failed) {
            border = 'border-rose-300 bg-rose-50 text-rose-800';
            icon = <XCircle className="w-4 h-4 text-rose-600 shrink-0" />;
          } else if (warning) {
            border = 'border-amber-300 bg-amber-50 text-amber-800 shadow-xs animate-pulse';
            icon = <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />;
          } else if (complete) {
            border = 'border-emerald-200 bg-emerald-50/70 text-emerald-900';
            icon = <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />;
          } else if (current) {
            border = 'border-blue-400 bg-blue-50/80 text-blue-900 ring-2 ring-blue-200';
            icon = <Clock className="w-4 h-4 text-blue-600 shrink-0 animate-spin" />;
          }

          return (
            <div 
              key={step.key} 
              className={`p-2.5 rounded-lg border text-xs flex items-center gap-2 transition-all ${border}`}
            >
              {icon}
              <div className="truncate">
                <p className="font-semibold truncate">{step.name}</p>
                <p className="text-[11px] opacity-75">
                  {failed ? 'Bỏ lượt' : warning ? 'Cảnh báo/Trễ' : complete ? 'Hoàn thành' : current ? 'Đang xử lý' : 'Chưa đến'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
