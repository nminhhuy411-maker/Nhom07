import React from 'react';
import { useHospital } from '../../context/HospitalContext';
import { ShieldAlert, ArrowLeft, LogOut, Lock, AlertCircle, FileText } from 'lucide-react';
import { NavTab } from './Sidebar';

interface Forbidden403ScreenProps {
  attemptedTab: NavTab;
  onNavigateHome: () => void;
}

export const Forbidden403Screen: React.FC<Forbidden403ScreenProps> = ({ attemptedTab, onNavigateHome }) => {
  const { activeAccount, logout } = useHospital();

  const getTabVietnameseName = (tab: NavTab) => {
    switch (tab) {
      case 'doctor': return 'Dashboard Khám Bác Sĩ & Chỉ Định';
      case 'reception': return 'Phân Hệ Lễ Tân & Tiếp Đón';
      case 'queue': return 'Bảng Điều Phối Hàng Đợi Toàn Viện';
      case 'paraclinical': return 'Bộ Phận Cận Lâm Sàng (XN, XQ, SA)';
      case 'cashier': return 'Quầy Thu Phí & Quản Trị Viện Phí';
      case 'admin': return 'Bảng Quản Trị Hệ Thống & Cấu Hình AI';
      default: return tab;
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <div className="max-w-xl w-full bg-white border border-rose-200 rounded-3xl p-8 shadow-xl text-center space-y-6">
        {/* Warning Icon Badge */}
        <div className="w-20 h-20 mx-auto rounded-3xl bg-rose-50 border-2 border-rose-200 flex items-center justify-center text-rose-600 shadow-inner">
          <ShieldAlert className="w-10 h-10 animate-bounce" />
        </div>

        {/* Title */}
        <div className="space-y-2">
          <span className="px-3 py-1 bg-rose-100 text-rose-800 text-[11px] font-mono font-bold rounded-full uppercase tracking-wider border border-rose-300">
            HTTP 403 Forbidden · RouteGuard Enforced
          </span>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight">
            Từ Chối Quyền Truy Cập (Access Denied)
          </h2>
          <p className="text-sm text-slate-600">
            Bạn không có thẩm quyền truy cập vào phân hệ <strong className="text-rose-700">"{getTabVietnameseName(attemptedTab)}"</strong> (URL: <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-xs">#{attemptedTab}</code>).
          </p>
        </div>

        {/* Security Audit Details Card */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl text-left space-y-2 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <span className="text-slate-500 font-semibold">Tài khoản đang đăng nhập:</span>
            <span className="font-bold text-slate-800">{activeAccount.name} ({activeAccount.title})</span>
          </div>
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <span className="text-slate-500 font-semibold">Vai trò thực tế:</span>
            <span className="font-mono font-bold text-blue-700 uppercase">{activeAccount.role}</span>
          </div>
          <div className="flex items-center justify-between pb-2 border-b border-slate-200">
            <span className="text-slate-500 font-semibold">Căn cứ quy chế bảo vệ:</span>
            <span className="text-slate-800 font-medium">Chính sách bảo mật hồ sơ bệnh án & Phân quyền y tế</span>
          </div>
          <p className="text-[11px] text-slate-500 italic pt-1">
            * Nguyên tắc phân quyền: Mỗi nhân viên hoặc bệnh nhân chỉ được thao tác đúng phạm vi chức năng được cấp phép. Hành vi truy cập trái thẩm quyền được ghi nhận trong nhật ký an toàn hệ thống.
          </p>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={onNavigateHome}
            className="w-full sm:w-auto px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Quay Về Cổng Bệnh Nhân Hợp Lệ
          </button>
          
          <button
            onClick={logout}
            className="w-full sm:w-auto px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4 text-slate-500" /> Đăng Xuất (Chuyển Vai Trò Khác)
          </button>
        </div>
      </div>
    </div>
  );
};
