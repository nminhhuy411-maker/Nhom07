export type UserRole = 
  | 'patient' 
  | 'reception' 
  | 'doctor' 
  | 'paraclinical' 
  | 'pharmacy'
  | 'cashier' 
  | 'admin';

export type PermissionKey = 
  | 'view_patient_portal'
  | 'declare_symptoms'
  | 'approve_triage'
  | 'assign_slot_qr'
  | 'check_in_queue'
  | 'call_patient'
  | 'clinical_consultation'
  | 'order_paraclinical'
  | 'complete_diagnosis'
  | 'edit_prescription'
  | 'dispense_medication'
  | 'receive_lab_specimen'
  | 'input_lab_results'
  | 'validate_lab_results'
  | 'collect_payment'
  | 'issue_invoice'
  | 'manage_accounts'
  | 'manage_permissions'
  | 'view_all_patients_records';

export interface UserAccount {
  id: string;
  username: string;
  password?: string;
  name: string;
  role: UserRole;
  title: string;
  department?: string;
  avatar?: string;
  email?: string;
  status?: 'active' | 'locked';
  isActive?: boolean;
  createdAt?: string;
  mustChangePassword?: boolean;
  linkedPatientId?: string; // Khóa bệnh nhân cố định nếu là role patient (e.g. BN001)
  cccd?: string; // Số định danh công dân 12 số
  phone?: string; // Số điện thoại liên hệ
  dateOfBirth?: string; // Ngày sinh DD/MM/YYYY
  gender?: 'Nam' | 'Nữ' | 'Khác';
  address?: string; // Địa chỉ thường trú / cư trú
  registeredOnline?: boolean; // Đăng ký trực tuyến qua cổng bệnh nhân
  permissions?: PermissionKey[];
}

export interface PatientRegisterPayload {
  cccd: string;
  fullName: string;
  dateOfBirth: string;
  birthYear: number;
  gender: 'Nam' | 'Nữ' | 'Khác';
  nationality: string;
  phone: string;
  email?: string;
  address: string;
  username: string;
  password: string;
  bhytCode?: string;
}


export interface RBACTestScenario {
  id: number;
  code: string;
  name: string;
  role: UserRole;
  attemptedAction: string;
  targetResource: string;
  expectedResult: 'BLOCKED' | 'ALLOWED';
  actualResult?: 'BLOCKED' | 'ALLOWED';
  passed?: boolean;
  securityMessage?: string;
  policyRule: string;
}

export type PriorityLevel = 1 | 2 | 3; // 1: Khẩn cấp, 2: Ưu tiên cao, 3: Tiêu chuẩn

export type VisitStatus = 
  | 'registered'               // 1. Đã đăng ký thông tin
  | 'symptom_declared'        // 2. Đã khai triệu chứng
  | 'pending_triage'          // 3. Chờ duyệt phân luồng
  | 'pending_emergency_eval'  // 3b. Cảnh báo khẩn - Chờ đánh giá ca khẩn
  | 'approved'                // 4. Lễ tân đã duyệt & cấp lịch, mã QR
  | 'checked_in'               // 5. Đã check-in tại viện - Vào hàng đợi
  | 'calling'                 // 6. Đang gọi vào phòng khám (3 phút chờ)
  | 'in_consultation'         // 7. Bác sĩ đang khám lâm sàng
  | 'pending_paraclinical'    // 8. Chờ thực hiện cận lâm sàng
  | 'paraclinical_delayed'    // 8b. Cận lâm sàng chậm trễ quá 8h
  | 'paraclinical_completed'  // 9. Cận lâm sàng hoàn thành đủ kết quả
  | 'diagnosed'               // 10. Bác sĩ đã kết luận chuyên môn
  | 'pending_payment'         // 11. Chờ thanh toán viện phí
  | 'paid'                    // 12. Đã thanh toán / BHYT chi trả 100%
  | 'completed'               // 13. Toàn bộ quy trình hoàn tất
  | 'missed'                  // Bỏ lượt do vắng mặt khi gọi số
  | 'cancelled';              // Đã hủy lượt khám (UC15)

export interface Patient {
  id: string; // e.g. BN001
  cccd: string; // 12 số
  phone: string; // 10 số, bắt đầu bằng 0
  fullName: string;
  birthYear: number;
  dateOfBirth: string; // DD/MM/YYYY
  gender: 'Nam' | 'Nữ' | 'Khác';
  address: string;
  bhytCode: string; // Mã BHYT e.g. DN448090000001
  bhytRate: number; // 0.8 (80%), 1.0 (100%), 0 (0%)
  medicalHistory: string[];
  createdAt: string;
}

export interface StructuredSymptom {
  chiefComplaint: string;      // Triệu chứng chính
  onsetDuration: string;       // Khởi phát từ khi nào
  severity: 'Nhẹ' | 'Vừa' | 'Nặng' | 'Dữ dội'; // Mức độ
  associatedSymptoms: string[];// Triệu chứng kèm theo
  underlyingDiseases: string;  // Bệnh nền
  age: number;
  gender: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  timestamp: string;
}

export interface SymptomRecord {
  id: string;
  visitId: string;
  patientId: string;
  rawText: string;
  chatHistory: ChatMessage[];
  structuredSummary: StructuredSymptom;
  createdAt: string;
}

export interface StandardAITriageOutput {
  analysis_id: string;
  patient_id: string;
  visit_id?: string;
  timestamp: string;
  symptoms: string[];
  anatomical_location?: string;
  onset_duration?: string;
  severity_described?: string;
  associated_symptoms?: string[];
  missing_information: string[];
  red_flags: string[];
  recommended_department: string;
  priority_level: PriorityLevel;
  reason: string;
  confidence: number;
  need_more_information: boolean;
  follow_up_question?: string;
  uncertainties?: string[];
  requires_human_review: boolean;
  emergency_warning: boolean;
  emergency_instructions?: string;
  next_action: string;
  workflow_status: 'WAITING_INPUT' | 'EMERGENCY_ESCALATED' | 'WAITING_REVIEW' | 'APPROVED' | 'MANUAL_REQUIRED';
}

export interface AIRecommendation {
  id: string;
  analysis_id?: string;
  visitId: string;
  suggestedDepartment: string;
  suggestedPriority: PriorityLevel;
  isEmergency: boolean;
  emergencyTriggers: string[];
  rationale: string;
  confidence: number; // 0 - 1
  triageType: 'ai_auto' | 'ai_fallback_rule' | 'manual_required';
  createdAt: string;
  standardOutput?: StandardAITriageOutput;
}

export interface KnowledgeBaseDocument {
  id: string;
  category: 'department' | 'symptom' | 'red_flag' | 'triage_rule' | 'workflow' | 'rbac';
  title: string;
  code?: string;
  content: string;
  metadata?: Record<string, any>;
  version: string;
  approvedBy: string;
  updatedAt: string;
}

export interface AIFeedbackRecord {
  id: string;
  analysis_id: string;
  patient_id: string;
  visit_id: string;
  suggested_department: string;
  suggested_priority: PriorityLevel;
  rating: 'appropriate' | 'inappropriate' | 'wrong_department' | 'wrong_priority' | 'missed_red_flag' | 'missing_clarification';
  ratingLabel: string;
  reviewer_name: string;
  reviewer_role: UserRole;
  notes: string;
  correct_department?: string;
  correct_priority?: PriorityLevel;
  createdAt: string;
}

export interface AITestCase {
  id: number;
  name: string;
  inputDescription: string;
  sampleInput: string;
  expectedDepartment: string;
  expectedPriority: PriorityLevel;
  expectedEmergency: boolean;
  expectedNeedMoreInfo: boolean;
  actualDepartment?: string;
  actualPriority?: PriorityLevel;
  actualEmergency?: boolean;
  actualNeedMoreInfo?: boolean;
  actualReason?: string;
  analysis_id?: string;
  passed?: boolean;
  failureReason?: string;
  testCategory: string;
}

export interface TriageApproval {
  id: string;
  visitId: string;
  receptionistId: string;
  receptionistName: string;
  approvedDepartment: string;
  approvedPriority: PriorityLevel;
  isAdjusted: boolean;
  adjustmentReason?: string;
  slotTime: string; // e.g. 08:30 - 08:45
  appointmentDate: string; // DD/MM/YYYY
  assignedRoom: string;
  createdAt: string;
}

export interface QueueItem {
  id: string;
  visitId: string;
  patientId: string;
  patientName: string;
  queueNumber: number; // STT khám
  department: string;
  room: string;
  priority: PriorityLevel;
  checkInTime: string;
  status: 'waiting' | 'calling' | 'in_consultation' | 'missed' | 'completed' | 'cancelled';
  estimatedWaitMinutes: number;
  bumpedCount: number; // Số lần bị lùi lượt do trễ
  calledAt?: string; // Thời gian bắt đầu gọi số
}

export type LabServiceType = 'lab_test' | 'xray' | 'ultrasound';

export type LabOrderStatus = 
  | 'ordered'           // Đã chỉ định
  | 'received'          // Đã tiếp nhận tại phòng CLS
  | 'in_progress'       // Đang thực hiện
  | 'awaiting_result'   // Chờ trả kết quả
  | 'result_ready'      // Đã có kết quả sơ bộ
  | 'invalid'           // Không hợp lệ (cần làm lại)
  | 'delayed'           // Chậm trễ quá hạn 8 giờ
  | 'completed'         // Hoàn thành hợp lệ
  | 'cancelled';        // Đã hủy

export interface LabResultDetail {
  param: string;
  value: string;
  unit: string;
  referenceRange: string;
  isAbnormal: boolean;
}

export interface LabResult {
  summary: string;
  details: LabResultDetail[];
  technicianNotes: string;
  performedBy: string;
  completedAt: string;
  isValidated: boolean;
  validatedBy?: string;
  validatedAt?: string;
  attachmentName?: string;
}

export interface ClinicalOrder {
  id: string; // e.g. CLS-XN-001
  visitId: string;
  patientId: string;
  serviceType: LabServiceType;
  serviceName: string;
  roomName: string;
  price: number;
  orderTime: string;
  deadlineMinutes: number; // ~5, 7, 8 mins when normal fast random, 480 mins (8h) when unprocessable
  deadlineTimestamp: number; // epoch ms
  totalDurationSeconds?: number; // total target seconds (e.g. 300s, 420s, 480s, or 28800s)
  elapsedSeconds?: number; // live seconds elapsed
  status: LabOrderStatus;
  isDelayed: boolean;
  isUnprocessable?: boolean;
  delayReason?: string;
  delayAction?: 'extend' | 'cancel';
  invalidReason?: string;
  redoCount: number;
  result?: LabResult;
  historyLogs?: string[];
}

export interface InvoiceItem {
  code: string;
  name: string;
  category: 'exam' | 'lab_test' | 'xray' | 'ultrasound' | 'other';
  quantity: number;
  unitPrice: number;
  amount: number;
}

export interface Invoice {
  id: string; // e.g. HD-20261101-001
  visitId: string;
  patientId: string;
  patientName: string;
  cccd: string;
  bhytCode: string;
  bhytRate: number; // 0 - 1
  invoiceDate: string;
  items: InvoiceItem[];
  totalAmount: number;
  bhytAmount: number;
  patientPaymentAmount: number;
  status: 'pending' | 'paid' | 'cancelled';
  paymentMethod?: 'cash' | 'transfer' | 'bhyt_full';
  cashierName?: string;
  paidAt?: string;
}

export interface PrescriptionDrugItem {
  id: string;
  drugName: string;
  dosage: string;
  quantity: number;
  unit: string;
  instruction?: string;
  inStock?: boolean;
  stockAvailable?: number;
  availableStock?: number;
  activeIngredient?: string;
  note?: string;
}

export interface PrescriptionOrder {
  id: string;
  visitId: string;
  patientId: string;
  patientName: string;
  doctorName: string;
  department: string;
  diagnosis: string;
  status: 'new' | 'preparing' | 'ready' | 'dispensed' | 'out_of_stock' | 'cancelled';
  createdAt: string;
  dispensedAt?: string;
  dispensedBy?: string;
  items: PrescriptionDrugItem[];
  notes?: string;
}

export interface NotificationItem {
  id: string;
  targetRole: UserRole | 'all';
  targetPatientId?: string;
  title: string;
  message: string;
  type: 'info' | 'warning' | 'alert' | 'success';
  createdAt: string;
  isRead: boolean;
  actionLink?: string;
}

export interface WorkflowLog {
  id: string;
  visitId: string;
  patientId: string;
  patientName: string;
  actorName: string;
  role: UserRole | 'Hệ thống AI';
  action: string;
  stage: string;
  previousState: string;
  newState: string;
  reason?: string;
  timestamp: string;
}

export interface SystemConfig {
  checkInToleranceMinutes: number;   // Dung sai đến muộn (mặc định 15p)
  earlyCheckInMinutes: number;       // Được check-in trước giờ hẹn (mặc định 30p)
  callGracePeriodMinutes: number;    // Thời hạn có mặt khi gọi số (mặc định 3p)
  averageConsultationMinutes: number;// Thời gian khám trung bình (mặc định 10p)
  maxPatientsPerSlot: number;        // Số BN tối đa một khung giờ 15p (mặc định 3)
  labTimeoutMinutes: number;         // Hạn cận lâm sàng (480p = 8h)
  demoLabTimeoutSeconds: number;     // Hạn cận lâm sàng khi chạy chế độ demo (30s hoặc 60s)
  isDemoTimerEnabled: boolean;       // Bật bộ đếm demo thu nhỏ
  simulatedClockOffsetMinutes: number;// Cộng giờ giả lập
}

export interface Visit {
  id: string; // e.g. LK-001
  patientId: string;
  analysisId?: string; // Khóa liên kết phân tích AI duy nhất
  status: VisitStatus;
  priority: PriorityLevel;
  emergencyFlag: boolean;
  emergencyReason?: string;
  emergencyEvaluated?: boolean;
  manualTriageFlag: boolean;
  manualTriageReason?: string;
  assignedDepartment: string;
  assignedRoom: string;
  slotTime: string; // e.g. 08:30 - 08:45
  appointmentDate: string; // DD/MM/YYYY
  qrCode: string; // Mã QR xác thực
  qrUsed: boolean;
  qrUsedAt?: string;
  checkInTime?: string;
  isDelayedCheckIn?: boolean;
  reRegistered?: boolean;
  calledAt?: string;
  clinicalNotes?: string;
  finalDiagnosis?: string;
  prescriptionNotes?: string;
  requiresFollowUp?: boolean;
  followUpDate?: string;
  cancellationReason?: string;
  cancelledAt?: string;
  createdAt: string;
  updatedAt: string;
}
