import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { AIWorkflowOrchestrator } from '../../services/aiOrchestrator';
import { QrCodeView } from '../common/QrCodeView';
import { PriorityLevel, Visit, Patient } from '../../types';
import { 
  UserCheck, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Clock, 
  Calendar, 
  ArrowRight, 
  Search, 
  Filter, 
  X, 
  Eye, 
  Edit3, 
  Sparkles,
  QrCode,
  UserX,
  Users
} from 'lucide-react';
import { PatientAccountManagement } from '../admin/PatientAccountManagement';

export const ReceptionModule: React.FC = () => {
  const { 
    patients, 
    visits, 
    symptomRecords, 
    aiRecommendations, 
    evaluateEmergency, 
    approveTriage, 
    checkInPatient,
    reRegisterMissedPatient,
    config 
  } = useHospital();

  const [receptionView, setReceptionView] = useState<'triage' | 'patient_accounts'>('triage');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVisitId, setSelectedVisitId] = useState<string | null>(null);
  
  // Triage approval modal state
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [targetDept, setTargetDept] = useState('Tiêu hóa');
  const [targetPriority, setTargetPriority] = useState<PriorityLevel>(3);
  const [targetRoom, setTargetRoom] = useState('Phòng 103 - Nội Tiêu hóa');
  const [targetSlot, setTargetSlot] = useState('');
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [adjustReason, setAdjustReason] = useState('Khớp triệu chứng tiêu hóa lâm sàng');

  // Emergency evaluation modal
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [emergencyReasonInput, setEmergencyReasonInput] = useState('');

  // Quick reception check-in state
  const [checkInInput, setCheckInInput] = useState('');
  const [checkInAlert, setCheckInAlert] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // KPIs
  const totalRegisteredToday = visits.length;
  const pendingTriageVisits = visits.filter(v => v.status === 'pending_triage');
  const emergencyVisits = visits.filter(v => v.status === 'pending_emergency_eval');
  const manualTriageVisits = visits.filter(v => v.status === 'pending_triage' && v.manualTriageFlag);
  const approvedVisits = visits.filter(v => v.status === 'approved');
  const checkedInVisits = visits.filter(v => v.status === 'checked_in');

  const selectedVisit = visits.find(v => v.id === selectedVisitId);
  const selectedPatient = selectedVisit ? patients.find(p => p.id === selectedVisit.patientId) : null;
  const selectedAiRec = selectedVisit ? aiRecommendations.find(r => r.visitId === selectedVisit.id) : null;
  const selectedSymptoms = selectedVisit ? symptomRecords.find(s => s.visitId === selectedVisit.id) : null;

  // Department rooms dictionary
  const DEPARTMENT_ROOMS: Record<string, string> = {
    'Tiêu hóa': 'Phòng 103 - Nội Tiêu hóa',
    'Tim mạch': 'Phòng 201 - Nội Tim mạch',
    'Hô hấp': 'Phòng 102 - Nội Hô hấp',
    'Thần kinh': 'Phòng 204 - Nội Thần kinh',
    'Tai mũi họng': 'Phòng 105 - Tai Mũi Họng',
    'Da liễu': 'Phòng 106 - Da liễu',
    'Nội tổng quát': 'Phòng 101 - Khám Tổng quát',
  };

  const handleOpenReview = (visit: Visit) => {
    setSelectedVisitId(visit.id);
    const rec = aiRecommendations.find(r => r.visitId === visit.id);
    const dept = rec && rec.suggestedDepartment !== 'Cần phân luồng thủ công' ? rec.suggestedDepartment : 'Nội tổng quát';
    setTargetDept(dept);
    setTargetPriority(rec ? rec.suggestedPriority : 3);
    setTargetRoom(DEPARTMENT_ROOMS[dept] || 'Phòng 101 - Khám Tổng quát');

    // Suggest next available 15-min slot
    const slot = AIWorkflowOrchestrator.getNextAvailableSlot(visits, dept, config.maxPatientsPerSlot);
    setTargetSlot(slot);
    setIsAdjusting(false);
    setAdjustReason('Lễ tân đồng ý đề xuất phân luồng của AI');
    setIsReviewModalOpen(true);
  };

  const handleOpenEmergencyEval = (visit: Visit) => {
    setSelectedVisitId(visit.id);
    setTargetDept(visit.assignedDepartment || 'Tim mạch');
    setEmergencyReasonInput('Triệu chứng đau thắt ngực, khó thở cần cấp cứu khẩn cấp');
    setIsEmergencyModalOpen(true);
  };

  const handleConfirmEmergency = (confirm: boolean) => {
    if (!selectedVisitId) return;
    evaluateEmergency(selectedVisitId, confirm, targetDept, emergencyReasonInput);
    setIsEmergencyModalOpen(false);
    setSelectedVisitId(null);
  };

  const handleConfirmTriageApproval = () => {
    if (!selectedVisitId) return;
    if (isAdjusting && !adjustReason.trim()) {
      alert('Vui lòng nhập lý do điều chỉnh khoa hoặc mức ưu tiên (BR17).');
      return;
    }
    approveTriage(
      selectedVisitId,
      targetDept,
      targetPriority,
      targetSlot,
      targetRoom,
      isAdjusting,
      adjustReason
    );
    setIsReviewModalOpen(false);
    setSelectedVisitId(null);
  };

  const handleQuickCheckIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkInInput.trim()) return;
    const res = checkInPatient(checkInInput);
    if (res.success) {
      setCheckInAlert({ type: 'success', message: res.message });
      setCheckInInput('');
    } else {
      setCheckInAlert({ type: 'error', message: res.message });
    }
    setTimeout(() => setCheckInAlert(null), 6000);
  };

  // Filtered visits
  const filteredVisits = visits.filter(v => {
    const patient = patients.find(p => p.id === v.patientId);
    const nameMatch = patient ? patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()) : false;
    const cccdMatch = patient ? patient.cccd.includes(searchTerm) : false;
    const visitIdMatch = v.id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSearch = nameMatch || cccdMatch || visitIdMatch;

    if (!matchesSearch) return false;
    if (filterStatus === 'all') return true;
    if (filterStatus === 'pending') return v.status === 'pending_triage';
    if (filterStatus === 'emergency') return v.status === 'pending_emergency_eval';
    if (filterStatus === 'approved') return v.status === 'approved';
    if (filterStatus === 'checked_in') return v.status === 'checked_in';
    if (filterStatus === 'missed') return v.status === 'missed';
    return true;
  });

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Title & Quick Check-in Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#163A5F] bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-md">
              Bàn Tiếp Nhận & Phân Luồng
            </span>
            <span className="text-xs text-slate-400">· Tiếp đón & Cấp số QR</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Duyệt Phân Luồng Chuyên Khoa & Cấp Khung Giờ Khám
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Thẩm định đề xuất AI, xử lý ca khẩn cấp ưu tiên, cấp khung giờ tiếp đón theo phòng khám và phát hành mã QR check-in
          </p>
        </div>

        {/* Quick check-in input for reception */}
        <form onSubmit={handleQuickCheckIn} className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
          <QrCode className="w-4 h-4 text-slate-500 shrink-0" />
          <input
            type="text"
            placeholder="Quét QR / Nhập CCCD để check-in..."
            value={checkInInput}
            onChange={e => setCheckInInput(e.target.value)}
            className="w-48 sm:w-60 text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-blue-500"
          />
          <button
            type="submit"
            className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition-colors shadow-2xs whitespace-nowrap"
          >
            Check-in
          </button>
        </form>
      </div>

      {checkInAlert && (
        <div className={`p-3.5 rounded-xl border text-xs font-medium flex items-center justify-between ${
          checkInAlert.type === 'success' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-rose-50 text-rose-800 border-rose-200'
        }`}>
          <span>{checkInAlert.message}</span>
          <button onClick={() => setCheckInAlert(null)}><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* View Switcher: Triage List vs Patient Account Management */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 text-xs font-semibold">
        <button
          type="button"
          onClick={() => setReceptionView('triage')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer ${
            receptionView === 'triage' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5" /> Tiếp nhận & Phân luồng ca khám
        </button>
        <button
          type="button"
          onClick={() => setReceptionView('patient_accounts')}
          className={`px-4 py-2 rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer ${
            receptionView === 'patient_accounts' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5 text-teal-300" /> Quản lý Tài khoản Bệnh nhân
        </button>
      </div>

      {receptionView === 'patient_accounts' ? (
        <PatientAccountManagement allowLockToggle={false} />
      ) : (
        <>
          {/* KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Tổng đăng ký</span>
          <p className="text-xl font-bold font-mono text-slate-800 mt-1">{totalRegisteredToday}</p>
        </div>
        <div className={`p-3.5 border rounded-xl shadow-xs transition-all ${
          emergencyVisits.length > 0 ? 'bg-rose-50 border-rose-300 animate-pulse' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-rose-700 font-bold uppercase">Ca khẩn cấp</span>
            <ShieldAlert className="w-4 h-4 text-rose-600" />
          </div>
          <p className="text-xl font-bold font-mono text-rose-700 mt-1">{emergencyVisits.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Chờ duyệt AI</span>
          <p className="text-xl font-bold font-mono text-amber-600 mt-1">{pendingTriageVisits.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Cần phân thủ công</span>
          <p className="text-xl font-bold font-mono text-purple-600 mt-1">{manualTriageVisits.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Đã cấp lịch & QR</span>
          <p className="text-xl font-bold font-mono text-blue-600 mt-1">{approvedVisits.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Đã check-in</span>
          <p className="text-xl font-bold font-mono text-emerald-600 mt-1">{checkedInVisits.length}</p>
        </div>
      </div>

      {/* Emergency Red Banner if any (UC.04) */}
      {emergencyVisits.length > 0 && (
        <div className="bg-rose-600 text-white rounded-2xl p-4 shadow-lg border border-rose-700 flex flex-col md:flex-row items-center justify-between gap-4 animate-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/20 rounded-xl">
              <ShieldAlert className="w-6 h-6 text-white animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm uppercase tracking-wider">CẢNH BÁO: CÓ {emergencyVisits.length} CA BỆNH KHẨN CẤP CẦN ĐÁNH GIÁ NGAY!</h3>
                <span className="text-[10px] bg-white text-rose-800 font-bold px-2 py-0.5 rounded">Ưu tiên 1 - Khẩn cấp</span>
              </div>
              <p className="text-xs text-rose-100 mt-0.5">
                AI phát hiện dấu hiệu nguy hiểm (đau thắt ngực, khó thở, co giật...). Lễ tân cần xác nhận để đưa vào đầu hàng khoa khám ngay lập tức.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {emergencyVisits.map(ev => (
              <button
                key={ev.id}
                onClick={() => handleOpenEmergencyEval(ev)}
                className="px-4 py-2 bg-white text-rose-700 hover:bg-rose-50 text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
              >
                Đánh giá ca: {patients.find(p => p.id === ev.patientId)?.fullName} →
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <span className="text-slate-400 font-medium">Trạng thái:</span>
          {[
            { id: 'all', label: 'Tất cả' },
            { id: 'emergency', label: `Khẩn cấp (${emergencyVisits.length})` },
            { id: 'pending', label: `Chờ duyệt (${pendingTriageVisits.length})` },
            { id: 'approved', label: 'Đã duyệt' },
            { id: 'checked_in', label: 'Đã check-in' },
            { id: 'missed', label: 'Bỏ lượt' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                filterStatus === tab.id ? 'bg-blue-600 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm theo Tên BN, CCCD, Mã lượt..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Mã BN / Lượt</th>
                <th className="py-3 px-3">Họ và tên</th>
                <th className="py-3 px-3">SĐT / Năm sinh</th>
                <th className="py-3 px-4">Triệu chứng tóm tắt</th>
                <th className="py-3 px-3">Khoa AI đề xuất</th>
                <th className="py-3 px-3 text-center">Mức ưu tiên</th>
                <th className="py-3 px-3">Khung giờ hẹn</th>
                <th className="py-3 px-3">Trạng thái</th>
                <th className="py-3 px-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredVisits.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    Không tìm thấy lượt khám phù hợp với bộ lọc hiện tại.
                  </td>
                </tr>
              ) : (
                filteredVisits.map(visit => {
                  const patient = patients.find(p => p.id === visit.patientId)!;
                  const aiRec = aiRecommendations.find(r => r.visitId === visit.id);
                  const symptom = symptomRecords.find(s => s.visitId === visit.id);

                  return (
                    <tr 
                      key={visit.id} 
                      className={`hover:bg-slate-50/70 transition-colors ${
                        visit.status === 'pending_emergency_eval' ? 'bg-rose-50/50' : ''
                      }`}
                    >
                      <td className="py-3 px-4 whitespace-nowrap font-mono">
                        <span className="font-bold text-slate-900 block">{patient.id}</span>
                        <span className="text-[10px] text-slate-400">{visit.id}</span>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="font-bold text-slate-800 block text-xs">{patient.fullName}</span>
                        <span className="text-[10px] text-teal-700 font-mono">BHYT: {Math.round(patient.bhytRate * 100)}%</span>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap text-slate-600 font-mono text-[11px]">
                        <div>{patient.phone}</div>
                        <span className="text-slate-400 font-sans text-[10px]">{patient.birthYear} ({patient.gender})</span>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <p className="line-clamp-2 text-[11px] text-slate-700">
                          {symptom?.structuredSummary?.chiefComplaint || symptom?.rawText || 'Chưa khai triệu chứng'}
                        </p>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="font-bold text-blue-700 block">{visit.assignedDepartment}</span>
                        <span className="text-[10px] text-slate-400 truncate block max-w-[130px]">{visit.assignedRoom}</span>
                      </td>

                      <td className="py-3 px-3 text-center whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                          visit.priority === 1 
                            ? 'bg-rose-100 text-rose-700 border border-rose-200' 
                            : visit.priority === 2 
                              ? 'bg-amber-100 text-amber-700 border border-amber-200' 
                              : 'bg-blue-100 text-blue-700 border border-blue-200'
                        }`}>
                          {visit.priority === 1 ? 'P1 - Khẩn' : visit.priority === 2 ? 'P2 - Cao' : 'P3 - Thường'}
                        </span>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap font-mono text-[11px]">
                        <span className="font-semibold text-slate-800">{visit.slotTime}</span>
                        <span className="text-[10px] text-slate-400 block">{visit.appointmentDate}</span>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                          visit.status === 'pending_emergency_eval'
                            ? 'bg-rose-600 text-white animate-pulse'
                            : visit.status === 'pending_triage'
                              ? 'bg-amber-100 text-amber-800'
                              : visit.status === 'approved'
                                ? 'bg-blue-100 text-blue-800'
                                : visit.status === 'checked_in'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : visit.status === 'missed'
                                    ? 'bg-slate-200 text-slate-700'
                                    : 'bg-slate-100 text-slate-600'
                        }`}>
                          {visit.status === 'pending_emergency_eval' ? 'Cần đánh giá khẩn' :
                           visit.status === 'pending_triage' ? 'Chờ duyệt' :
                           visit.status === 'approved' ? 'Đã cấp lịch & QR' :
                           visit.status === 'checked_in' ? 'Đã check-in' :
                           visit.status === 'missed' ? 'Bỏ lượt' :
                           visit.status === 'in_consultation' ? 'Đang khám' :
                           visit.status === 'completed' ? 'Hoàn thành' : visit.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {visit.status === 'pending_emergency_eval' ? (
                            <button
                              onClick={() => handleOpenEmergencyEval(visit)}
                              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                            >
                              <ShieldAlert className="w-3.5 h-3.5" /> Đánh giá khẩn
                            </button>
                          ) : visit.status === 'pending_triage' ? (
                            <button
                              onClick={() => handleOpenReview(visit)}
                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" /> Duyệt & Cấp giờ
                            </button>
                          ) : visit.status === 'approved' ? (
                            <button
                              onClick={() => {
                                const res = checkInPatient(visit.qrCode);
                                alert(res.message);
                              }}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                            >
                              <UserCheck className="w-3.5 h-3.5" /> Check-in hộ
                            </button>
                          ) : visit.status === 'missed' && !visit.reRegistered ? (
                            <button
                              onClick={() => {
                                const ok = reRegisterMissedPatient(visit.id);
                                if (ok) alert('Đã hỗ trợ đăng ký lại thành công! Bệnh nhân được xếp cuối hàng.');
                              }}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 shadow-2xs"
                            >
                              Đăng ký lại lượt
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400">Đã xử lý</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: TRIAGE REVIEW & SLOT/QR ISSUANCE (UC.05) */}
      {isReviewModalOpen && selectedVisit && selectedPatient && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-5 animate-in zoom-in-95 duration-150 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h4 className="font-extrabold text-slate-900 text-base">
                  Duyệt Đề Xuất Phân Luồng & Cấp Khung Giờ
                </h4>
                <p className="text-xs text-slate-500">
                  Bệnh nhân: <strong className="text-slate-800">{selectedPatient.fullName}</strong> ({selectedPatient.id} · {selectedPatient.gender} · {selectedPatient.birthYear})
                </p>
              </div>
              <button onClick={() => setIsReviewModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* AI Recommendation Summary Box */}
            <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-xl space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-blue-900 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-blue-700" /> Đề xuất tự động của AI Orchestrator
                </span>
                <span className="font-mono text-[11px] font-bold bg-white text-blue-700 px-2 py-0.5 rounded border border-blue-200">
                  Độ tin cậy: {selectedAiRec ? Math.round(selectedAiRec.confidence * 100) : 90}%
                </span>
              </div>
              <p className="text-slate-700 leading-relaxed">
                {selectedAiRec?.rationale || 'Dựa trên phân tích triệu chứng khai báo.'}
              </p>
              <div className="pt-2 border-t border-blue-100 flex items-center gap-4 text-[11px] text-blue-950 font-medium">
                <span>Khoa đề xuất: <strong>{selectedAiRec?.suggestedDepartment || targetDept}</strong></span>
                <span>Mức ưu tiên: <strong>Ưu tiên {selectedAiRec?.suggestedPriority || 3}</strong></span>
              </div>
            </div>

            {/* Patient Symptoms Summary */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
              <span className="font-bold text-slate-700">Triệu chứng bệnh nhân khai:</span>
              <p className="text-slate-600 italic">"{selectedSymptoms?.rawText || 'Không có mô tả chi tiết'}"</p>
              <p className="text-[11px] text-slate-400 mt-1">
                Tiền sử: {selectedPatient.medicalHistory.join(', ') || 'Không ghi nhận'}
              </p>
            </div>

            {/* Actions: Approve as AI or Adjust */}
            <div className="space-y-3 text-xs">
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-800">
                  <input
                    type="radio"
                    name="decision"
                    checked={!isAdjusting}
                    onChange={() => {
                      setIsAdjusting(false);
                      if (selectedAiRec && selectedAiRec.suggestedDepartment !== 'Cần phân luồng thủ công') {
                        setTargetDept(selectedAiRec.suggestedDepartment);
                        setTargetPriority(selectedAiRec.suggestedPriority);
                        setTargetRoom(DEPARTMENT_ROOMS[selectedAiRec.suggestedDepartment] || 'Phòng 101 - Khám Tổng quát');
                      }
                    }}
                    className="text-blue-600"
                  />
                  <span>Chấp thuận đề xuất AI (Phù hợp)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-800">
                  <input
                    type="radio"
                    name="decision"
                    checked={isAdjusting}
                    onChange={() => setIsAdjusting(true)}
                    className="text-blue-600"
                  />
                  <span>Điều chỉnh chuyên khoa / Mức ưu tiên</span>
                </label>
              </div>

              {/* Adjustment Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Chuyên khoa khám *</label>
                  <select
                    disabled={!isAdjusting}
                    value={targetDept}
                    onChange={e => {
                      const d = e.target.value;
                      setTargetDept(d);
                      setTargetRoom(DEPARTMENT_ROOMS[d] || 'Phòng 101 - Khám Tổng quát');
                      const nextSlot = AIWorkflowOrchestrator.getNextAvailableSlot(visits, d, config.maxPatientsPerSlot);
                      setTargetSlot(nextSlot);
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium disabled:bg-slate-100"
                  >
                    {Object.keys(DEPARTMENT_ROOMS).map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Phòng khám chỉ định</label>
                  <input
                    type="text"
                    disabled
                    value={targetRoom}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 bg-slate-100 text-slate-700 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Mức ưu tiên khám *</label>
                  <select
                    disabled={!isAdjusting}
                    value={targetPriority}
                    onChange={e => setTargetPriority(Number(e.target.value) as PriorityLevel)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium disabled:bg-slate-100"
                  >
                    <option value={1}>1 - Khẩn cấp (Cấp cứu/Đầu hàng)</option>
                    <option value={2}>2 - Ưu tiên cao (Trẻ &lt;6t, Người &ge;65t, bệnh nặng)</option>
                    <option value={3}>3 - Tiêu chuẩn (Bình thường)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Khung giờ tiếp đón (15 phút) *</label>
                  <input
                    type="text"
                    value={targetSlot}
                    onChange={e => setTargetSlot(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-mono font-bold text-slate-800"
                  />
                </div>
              </div>

              {isAdjusting && (
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Lý do điều chỉnh chuyên khoa / mức ưu tiên *</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Bệnh nhân có tiền sử tăng huyết áp 160/100, điều chỉnh sang Tim mạch"
                    value={adjustReason}
                    onChange={e => setAdjustReason(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-amber-300 bg-amber-50/50 text-xs font-medium focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setIsReviewModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmTriageApproval}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <CheckCircle2 className="w-4 h-4" /> Xác nhận Duyệt & Cấp mã QR
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: EMERGENCY EVALUATION */}
      {isEmergencyModalOpen && selectedVisit && selectedPatient && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 border border-rose-300">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-6 h-6 text-rose-600" />
                <h4 className="font-extrabold text-slate-900 text-base">Đánh Giá & Phân Luồng Ca Khẩn Cấp</h4>
              </div>
              <button onClick={() => setIsEmergencyModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs space-y-1">
              <span className="font-bold block">Bệnh nhân: {selectedPatient.fullName} ({selectedPatient.id})</span>
              <p className="text-[11px]">Năm sinh: {selectedPatient.birthYear} ({new Date().getFullYear() - selectedPatient.birthYear} tuổi) · Tiền sử: {selectedPatient.medicalHistory.join(', ') || 'Chưa ghi nhận'}</p>
              <p className="text-[11px] font-bold text-rose-900 pt-1">
                Lý do kích hoạt cờ khẩn: {selectedVisit.emergencyReason}
              </p>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Khoa tiếp nhận cấp cứu *</label>
                <select
                  value={targetDept}
                  onChange={e => setTargetDept(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium"
                >
                  <option value="Tim mạch">Khoa Tim mạch / Cấp cứu Tim mạch</option>
                  <option value="Hô hấp">Khoa Hô hấp / Cấp cứu Hô hấp</option>
                  <option value="Tiêu hóa">Khoa Tiêu hóa</option>
                  <option value="Nội tổng quát">Khoa Cấp cứu Đa khoa</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Ghi chú đánh giá lâm sàng của Lễ tân *</label>
                <textarea
                  rows={2}
                  value={emergencyReasonInput}
                  onChange={e => setEmergencyReasonInput(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-rose-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => handleConfirmEmergency(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Không khẩn (Hạ mức P2)
              </button>
              <button
                onClick={() => handleConfirmEmergency(true)}
                className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <ShieldAlert className="w-4 h-4" /> Xác nhận Khẩn cấp & Đưa vào Đầu hàng
              </button>
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
