import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { Invoice } from '../../types';
import { 
  Receipt, 
  CreditCard, 
  QrCode, 
  Printer, 
  CheckCircle2, 
  Search, 
  Filter, 
  DollarSign, 
  X, 
  FileText, 
  ShieldCheck,
  Building,
  ArrowRight
} from 'lucide-react';

export const CashierModule: React.FC = () => {
  const { invoices, payInvoice, activeAccount } = useHospital();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'transfer'>('cash');

  // KPIs
  const totalInvoices = invoices.length;
  const pendingInvoices = invoices.filter(i => i.status === 'pending');
  const paidInvoices = invoices.filter(i => i.status === 'paid');
  const totalRevenue = invoices
    .filter(i => i.status === 'paid')
    .reduce((sum, i) => sum + i.patientPaymentAmount, 0);
  const totalBhytCovered = invoices
    .filter(i => i.status === 'paid')
    .reduce((sum, i) => sum + i.bhytAmount, 0);

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      inv.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.cccd.includes(searchTerm) ||
      inv.visitId.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'all' || inv.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const [paymentSuccess, setPaymentSuccess] = useState<string | null>(null);
  const selectedInvoice = invoices.find(i => i.id === selectedInvoiceId);

  const handleOpenInvoiceDetail = (inv: Invoice) => {
    setSelectedInvoiceId(inv.id);
    setPaymentSuccess(null);
    setIsInvoiceModalOpen(true);
  };

  const handleConfirmPayment = () => {
    if (!selectedInvoiceId) return;
    payInvoice(selectedInvoiceId, paymentMethod);
    setPaymentSuccess('Xác nhận thu viện phí thành công và đã xuất Hóa đơn điện tử hợp lệ!');
    setTimeout(() => {
      setPaymentSuccess(null);
      setIsInvoiceModalOpen(false);
    }, 1800);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
              Bộ Phận Tài Chính - Kế Toán
            </span>
            <span className="text-xs text-slate-400">· Hóa đơn điện tử & Giám định BHYT</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Quản Lý Viện Phí & Hóa Đơn Điện Tử
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Tự động tổng hợp chi phí khám và cận lâm sàng, khấu trừ BHYT (80% / 100%), xác nhận thu viện phí và phát hành hóa đơn điện tử
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-slate-500 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
            Thu ngân: <strong>{activeAccount.name}</strong>
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs text-slate-400 font-medium">Chờ thanh toán</span>
          <p className="text-2xl font-bold font-mono text-amber-600 mt-1">{pendingInvoices.length}</p>
          <span className="text-[11px] text-slate-400">Đã xong kết luận</span>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs text-slate-400 font-medium">Đã thanh toán / Xuất HĐ</span>
          <p className="text-2xl font-bold font-mono text-emerald-600 mt-1">{paidInvoices.length}</p>
          <span className="text-[11px] text-slate-400">BHYT & Tiền mặt</span>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs text-slate-400 font-medium">Tổng thực thu BN</span>
          <p className="text-2xl font-bold font-mono text-blue-700 mt-1">{totalRevenue.toLocaleString('vi-VN')} đ</p>
          <span className="text-[11px] text-slate-400">Đồng chi trả</span>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-xs text-slate-400 font-medium">Quỹ BHYT chi trả</span>
          <p className="text-2xl font-bold font-mono text-teal-700 mt-1">{totalBhytCovered.toLocaleString('vi-VN')} đ</p>
          <span className="text-[11px] text-slate-400">Bảo hiểm giám định</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <span className="text-slate-400 font-medium">Trạng thái:</span>
          {[
            { id: 'all', label: `Tất cả (${totalInvoices})` },
            { id: 'pending', label: `Chờ thanh toán (${pendingInvoices.length})` },
            { id: 'paid', label: `Đã thanh toán (${paidInvoices.length})` },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterStatus(tab.id)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                filterStatus === tab.id ? 'bg-emerald-700 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm theo Mã HĐ, Tên BN, CCCD..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Invoices Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Số Hóa Đơn</th>
                <th className="py-3 px-3">Bệnh nhân</th>
                <th className="py-3 px-3">Mã BHYT / Mức</th>
                <th className="py-3 px-3 text-right">Tổng viện phí</th>
                <th className="py-3 px-3 text-right">BHYT chi trả</th>
                <th className="py-3 px-3 text-right">BN thanh toán</th>
                <th className="py-3 px-3">Thời gian</th>
                <th className="py-3 px-3">Trạng thái</th>
                <th className="py-3 px-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    Không có hóa đơn nào phù hợp với bộ lọc hiện tại.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 whitespace-nowrap font-mono">
                      <span className="font-bold text-slate-900 block">{inv.id}</span>
                      <span className="text-[10px] text-slate-400">{inv.visitId}</span>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className="font-bold text-slate-800 block">{inv.patientName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">CCCD: {inv.cccd}</span>
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap font-mono text-[11px]">
                      <span className="text-teal-700 font-bold block">{inv.bhytCode}</span>
                      <span className="text-[10px] text-slate-400">Hưởng: {Math.round(inv.bhytRate * 100)}%</span>
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-[11px] whitespace-nowrap text-slate-700">
                      {inv.totalAmount.toLocaleString('vi-VN')} đ
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-[11px] whitespace-nowrap text-teal-700 font-semibold">
                      - {inv.bhytAmount.toLocaleString('vi-VN')} đ
                    </td>

                    <td className="py-3 px-3 text-right font-mono text-xs whitespace-nowrap font-bold text-blue-700">
                      {inv.patientPaymentAmount === 0 ? (
                        <span className="text-emerald-700">0 đ (100% BHYT)</span>
                      ) : (
                        `${inv.patientPaymentAmount.toLocaleString('vi-VN')} đ`
                      )}
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap font-mono text-[11px] text-slate-500">
                      {inv.invoiceDate}
                    </td>

                    <td className="py-3 px-3 whitespace-nowrap">
                      <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                        inv.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {inv.status === 'paid' ? 'Đã thu tiền' : 'Chờ thu'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <button
                        onClick={() => handleOpenInvoiceDetail(inv)}
                        className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-colors shadow-2xs flex items-center gap-1 ml-auto ${
                          inv.status === 'pending'
                            ? 'bg-blue-600 hover:bg-blue-700 text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                      >
                        {inv.status === 'pending' ? 'Thu phí & Xuất HĐ' : 'Xem & In HĐ'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ELECTRONIC INVOICE MODAL & PRINT VIEW */}
      {isInvoiceModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full p-6 space-y-6 animate-in zoom-in-95 duration-150 border border-slate-200 my-8">
            {/* Modal Actions Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 no-print">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-600" />
                <h4 className="font-extrabold text-slate-900 text-base">Hóa Đơn Điện Tử Viện Phí Ngoại Trú</h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" /> In Hóa Đơn
                </button>
                <button onClick={() => setIsInvoiceModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* PRINTABLE INVOICE PAPER AREA */}
            <div id="printable-invoice" className="border border-slate-300 rounded-xl p-8 bg-white space-y-6 text-slate-800 shadow-xs">
              {/* Hospital Header */}
              <div className="flex items-start justify-between border-b-2 border-slate-800 pb-4">
                <div>
                  <h2 className="font-black text-lg text-slate-900 uppercase tracking-tight">SỞ Y TẾ TP. ĐÀ NẴNG</h2>
                  <h1 className="font-black text-xl text-blue-900 uppercase">BỆNH VIỆN ĐA KHOA SƠN TRÀ</h1>
                  <p className="text-xs text-slate-500 mt-1">Địa chỉ: Đường Ngô Quyền, P. An Hải Bắc, Q. Sơn Trà, TP. Đà Nẵng</p>
                  <p className="text-xs text-slate-500 font-mono">Điện thoại: (0236) 3844.684 · MST: 0400123456</p>
                </div>
                <div className="text-right">
                  <p className="text-xs uppercase font-mono font-bold text-slate-500">Mẫu số: 01/BVST-HDDT</p>
                  <p className="text-sm font-black font-mono text-slate-900 mt-1">Số: {selectedInvoice.id}</p>
                  <p className="text-xs font-mono text-slate-500 mt-0.5">Ngày: {selectedInvoice.invoiceDate}</p>
                </div>
              </div>

              {/* Title */}
              <div className="text-center py-2">
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-wide">
                  HÓA ĐƠN ĐIỆN TỬ VIỆN PHÍ KHÁM CHỮA BỆNH
                </h2>
                <p className="text-xs text-slate-500 italic">(Bản thể hiện điện tử theo Nghị định 123/2020/NĐ-CP)</p>
              </div>

              {/* Patient Info Block */}
              <div className="grid grid-cols-2 gap-4 text-xs border-y border-slate-200 py-3">
                <div>
                  <p><span className="text-slate-500">Họ tên bệnh nhân:</span> <strong className="text-slate-900 uppercase">{selectedInvoice.patientName}</strong></p>
                  <p className="mt-1"><span className="text-slate-500">Số CCCD / Định danh:</span> <strong className="font-mono">{selectedInvoice.cccd}</strong></p>
                  <p className="mt-1"><span className="text-slate-500">Mã lượt khám:</span> <strong className="font-mono">{selectedInvoice.visitId}</strong></p>
                </div>
                <div>
                  <p><span className="text-slate-500">Mã thẻ BHYT:</span> <strong className="font-mono text-teal-800">{selectedInvoice.bhytCode}</strong></p>
                  <p className="mt-1"><span className="text-slate-500">Tỷ lệ BHYT thanh toán:</span> <strong>{Math.round(selectedInvoice.bhytRate * 100)}%</strong></p>
                  <p className="mt-1"><span className="text-slate-500">Hình thức thanh toán:</span> <strong className="capitalize">{selectedInvoice.paymentMethod || 'Tiền mặt / Chuyển khoản'}</strong></p>
                </div>
              </div>

              {/* Service Table */}
              <table className="w-full text-xs text-left border-collapse border border-slate-300">
                <thead className="bg-slate-100 font-bold text-slate-800 border-b border-slate-300">
                  <tr>
                    <th className="py-2 px-3 border-r border-slate-300 text-center w-10">STT</th>
                    <th className="py-2 px-3 border-r border-slate-300">Tên dịch vụ y tế & kỹ thuật</th>
                    <th className="py-2 px-3 border-r border-slate-300 text-center w-12">SL</th>
                    <th className="py-2 px-3 border-r border-slate-300 text-right w-28">Đơn giá (VNĐ)</th>
                    <th className="py-2 px-3 text-right w-28">Thành tiền (VNĐ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono text-[11px]">
                  {selectedInvoice.items.map((it, idx) => (
                    <tr key={idx}>
                      <td className="py-2 px-3 border-r border-slate-300 text-center">{idx + 1}</td>
                      <td className="py-2 px-3 border-r border-slate-300 font-sans font-medium text-slate-900">{it.name}</td>
                      <td className="py-2 px-3 border-r border-slate-300 text-center">{it.quantity}</td>
                      <td className="py-2 px-3 border-r border-slate-300 text-right">{it.unitPrice.toLocaleString('vi-VN')}</td>
                      <td className="py-2 px-3 text-right font-bold text-slate-900">{it.amount.toLocaleString('vi-VN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Financial Calculation Block */}
              <div className="flex justify-end text-xs font-mono">
                <div className="w-80 space-y-1.5 p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <div className="flex justify-between text-slate-600">
                    <span>1. Tổng viện phí phát sinh:</span>
                    <span className="font-bold text-slate-900">{selectedInvoice.totalAmount.toLocaleString('vi-VN')} đ</span>
                  </div>
                  <div className="flex justify-between text-teal-700">
                    <span>2. Quỹ BHYT chi trả ({Math.round(selectedInvoice.bhytRate * 100)}%):</span>
                    <span className="font-bold">- {selectedInvoice.bhytAmount.toLocaleString('vi-VN')} đ</span>
                  </div>
                  <div className="flex justify-between text-sm font-sans font-black pt-2 border-t border-slate-300 text-slate-900">
                    <span>3. Người bệnh cùng chi trả:</span>
                    <span className="text-blue-800 font-mono">{selectedInvoice.patientPaymentAmount.toLocaleString('vi-VN')} đ</span>
                  </div>
                </div>
              </div>

              {/* Signatures & Electronic Stamp */}
              <div className="grid grid-cols-2 gap-8 text-center text-xs pt-4 border-t border-slate-200">
                <div>
                  <p className="font-bold text-slate-800">NGƯỜI NỘP TIỀN</p>
                  <p className="text-[11px] text-slate-400 italic">(Ký, ghi rõ họ tên)</p>
                  <div className="h-16 flex items-end justify-center font-bold text-slate-800">
                    {selectedInvoice.patientName}
                  </div>
                </div>

                <div className="relative">
                  <p className="font-bold text-slate-800">NGƯỜI THU TIỀN / BỆNH VIỆN</p>
                  <p className="text-[11px] text-slate-400 italic">(Chữ ký điện tử tổ chức)</p>
                  
                  {selectedInvoice.status === 'paid' && (
                    <div className="absolute top-6 right-8 border-2 border-rose-600 text-rose-600 rounded-xl px-4 py-2 font-black uppercase text-xs tracking-wider rotate-[-8deg] shadow-xs">
                      ✓ ĐÃ THANH TOÁN
                      <span className="block text-[9px] font-mono font-normal">Ký số: BV SƠN TRÀ</span>
                      <span className="block text-[8px] font-mono">{selectedInvoice.paidAt}</span>
                    </div>
                  )}

                  <div className="h-16 flex items-end justify-center font-bold text-slate-800">
                    {selectedInvoice.cashierName || activeAccount.name}
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Actions for Cashier */}
            {selectedInvoice.status === 'pending' && (
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 no-print text-xs">
                <div className="flex items-center gap-4">
                  <span className="font-bold text-slate-700">Hình thức thu:</span>
                  <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-800">
                    <input
                      type="radio"
                      name="payMethod"
                      checked={paymentMethod === 'cash'}
                      onChange={() => setPaymentMethod('cash')}
                    />
                    <span>Tiền mặt</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer font-medium text-slate-800">
                    <input
                      type="radio"
                      name="payMethod"
                      checked={paymentMethod === 'transfer'}
                      onChange={() => setPaymentMethod('transfer')}
                    />
                    <span>Chuyển khoản QR</span>
                  </label>
                </div>

                <div className="flex items-center gap-2">
                  {paymentSuccess && (
                    <div className="p-2.5 px-3 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-lg text-xs font-bold flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>{paymentSuccess}</span>
                    </div>
                  )}
                  <button
                    onClick={handleConfirmPayment}
                    disabled={!!paymentSuccess}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Xác Nhận Thu {selectedInvoice.patientPaymentAmount.toLocaleString('vi-VN')} đ & Xuất Hóa Đơn
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
