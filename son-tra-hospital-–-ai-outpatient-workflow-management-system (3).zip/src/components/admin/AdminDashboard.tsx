import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from 'recharts';
import { 
  Activity, 
  Sliders, 
  UploadCloud, 
  Download, 
  Play, 
  Clock, 
  CheckCircle2, 
  RotateCcw, 
  FileText, 
  Sparkles,
  ShieldAlert,
  ArrowRight,
  BookOpen,
  Plus,
  Trash2,
  Edit2,
  ThumbsUp,
  AlertTriangle,
  Zap,
  Filter,
  Check,
  Search,
  MessageSquare,
  Award,
  Users
} from 'lucide-react';
import { PriorityLevel, UserRole } from '../../types';
import { RBACTestSuiteSection } from './RBACTestSuiteSection';
import { PatientAccountManagement } from './PatientAccountManagement';

interface AdminDashboardProps {
  onNavigateToTab: (tab: any) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigateToTab }) => {
  const { 
    patients, 
    visits, 
    queueItems, 
    labOrders, 
    invoices, 
    config, 
    updateConfig, 
    adjustSimulatedClock, 
    resetDemoData, 
    importDataFromJson,
    setActivePatientId,
    activeAccount,
    aiRecommendations,
    kbDocuments,
    addKBDocument,
    updateKBDocument,
    deleteKBDocument,
    resetKBDefaults,
    aiFeedbackRecords,
    submitAIFeedback,
    testCases,
    runAITestCase,
    runAllAITestCases
  } = useHospital();

  const [activeSection, setActiveSection] = useState<'overview' | 'patient_accounts' | 'kb_management' | 'ai_evaluation' | 'ai_test_suite' | 'rbac_suite' | 'scenarios' | 'config' | 'import_export'>('overview');

  // Config form state (UC.14)
  const [toleranceMin, setToleranceMin] = useState(config.checkInToleranceMinutes);
  const [earlyCheckInMin, setEarlyCheckInMin] = useState(config.earlyCheckInMinutes);
  const [callGraceMin, setCallGraceMin] = useState(config.callGracePeriodMinutes);
  const [avgConsultMin, setAvgConsultMin] = useState(config.averageConsultationMinutes);
  const [maxPerSlot, setMaxPerSlot] = useState(config.maxPatientsPerSlot);
  const [demoTimerSec, setDemoTimerSec] = useState(config.demoLabTimeoutSeconds);
  const [enableDemoTimer, setEnableDemoTimer] = useState(config.isDemoTimerEnabled);

  // Import JSON state (UC.13)
  const [importJsonText, setImportJsonText] = useState('');
  const [importReport, setImportReport] = useState<{ success: boolean; message: string } | null>(null);

  // KB Management State (Section I)
  const [kbFilter, setKbFilter] = useState<string>('all');
  const [kbSearch, setKbSearch] = useState<string>('');
  const [showKbModal, setShowKbModal] = useState<boolean>(false);
  const [editingKbId, setEditingKbId] = useState<string | null>(null);
  const [kbFormTitle, setKbFormTitle] = useState('');
  const [kbFormCategory, setKbFormCategory] = useState<'department' | 'symptom' | 'red_flag' | 'triage_rule' | 'workflow' | 'rbac'>('department');
  const [kbFormCode, setKbFormCode] = useState('');
  const [kbFormVersion, setKbFormVersion] = useState('v1.0-2026');
  const [kbFormApprovedBy, setKbFormApprovedBy] = useState('Hội đồng Chuyên môn Y khoa BV Sơn Trà');
  const [kbFormContent, setKbFormContent] = useState('');

  // AI Evaluation & Feedback Form State (Section VIII)
  const [selectedVisitId, setSelectedVisitId] = useState<string>(visits[0]?.id || '');
  const [fbRating, setFbRating] = useState<'appropriate' | 'wrong_department' | 'wrong_priority' | 'missed_red_flag' | 'missing_clarification'>('appropriate');
  const [fbCorrectDept, setFbCorrectDept] = useState('');
  const [fbCorrectPriority, setFbCorrectPriority] = useState<PriorityLevel>(3);
  const [fbNotes, setFbNotes] = useState('');
  const [fbReviewerName, setFbReviewerName] = useState(activeAccount.name);
  const [fbReviewerRole, setFbReviewerRole] = useState<UserRole>(activeAccount.role);
  const [fbFilter, setFbFilter] = useState<string>('all');

  // AI Test Suite State (Section IX)
  const [testFilterCategory, setTestFilterCategory] = useState<string>('all');
  const [testFilterStatus, setTestFilterStatus] = useState<'all' | 'passed' | 'failed' | 'not_run'>('all');
  const [isTestingAll, setIsTestingAll] = useState(false);
  const [testRunMessage, setTestRunMessage] = useState<string | null>(null);

  // Compute live data for charts
  const deptCounts: Record<string, number> = {};
  visits.forEach(v => {
    const dept = v.assignedDepartment || 'Chưa phân';
    deptCounts[dept] = (deptCounts[dept] || 0) + 1;
  });
  const deptChartData = Object.entries(deptCounts).map(([name, count]) => ({ name, count }));

  const statusCounts = [
    { name: 'Chờ duyệt / Khẩn', value: visits.filter(v => v.status === 'pending_triage' || v.status === 'pending_emergency_eval').length, color: '#f59e0b' },
    { name: 'Đã cấp lịch & QR', value: visits.filter(v => v.status === 'approved').length, color: '#3b82f6' },
    { name: 'Đang chờ khám', value: visits.filter(v => v.status === 'checked_in' || v.status === 'calling').length, color: '#6366f1' },
    { name: 'Đang làm CLS', value: visits.filter(v => v.status === 'pending_paraclinical' || v.status === 'paraclinical_delayed').length, color: '#0d9488' },
    { name: 'Chờ thanh toán', value: visits.filter(v => v.status === 'pending_payment').length, color: '#10b981' },
    { name: 'Hoàn thành', value: visits.filter(v => v.status === 'completed' || v.status === 'paid').length, color: '#059669' },
  ].filter(s => s.value > 0);

  const labPerformanceData = [
    { name: 'Đúng hạn', value: labOrders.filter(o => o.status === 'completed' && !o.isDelayed).length, color: '#10b981' },
    { name: 'Quá hạn 8h', value: labOrders.filter(o => o.isDelayed).length, color: '#f59e0b' },
    { name: 'Cần làm lại', value: labOrders.filter(o => o.status === 'invalid' || o.redoCount > 0).length, color: '#ef4444' },
    { name: 'Đang xử lý', value: labOrders.filter(o => o.status === 'ordered' || o.status === 'in_progress').length, color: '#3b82f6' },
  ].filter(s => s.value > 0);

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (toleranceMin <= 0 || callGraceMin <= 0 || avgConsultMin <= 0) {
      alert('Các giá trị thời gian phải là số dương hợp lệ!');
      return;
    }
    updateConfig({
      checkInToleranceMinutes: Number(toleranceMin),
      earlyCheckInMinutes: Number(earlyCheckInMin),
      callGracePeriodMinutes: Number(callGraceMin),
      averageConsultationMinutes: Number(avgConsultMin),
      maxPatientsPerSlot: Number(maxPerSlot),
      demoLabTimeoutSeconds: Number(demoTimerSec),
      isDemoTimerEnabled: enableDemoTimer,
    });
    alert('Đã cập nhật cấu hình tham số hệ thống thành công!');
  };

  const handleImportJson = () => {
    if (!importJsonText.trim()) return;
    try {
      const parsed = JSON.parse(importJsonText);
      const res = importDataFromJson(parsed);
      setImportReport(res);
    } catch (e: any) {
      setImportReport({ success: false, message: `Lỗi phân tích cú pháp JSON: ${e.message}` });
    }
  };

  const exportSystemBackup = () => {
    const backupData = {
      patients,
      visits,
      queueItems,
      labOrders,
      invoices,
      config,
      exportTime: new Date().toISOString(),
    };
    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_BV_Son_Tra_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Demo scenarios quick jump
  const demoScenarios = [
    {
      id: 'sc1',
      title: '1. Luồng khám hoàn chỉnh (Nguyễn Văn An)',
      desc: 'Bệnh nhân An (BN001) khám Tiêu hóa, hoàn tất XN + Siêu âm, BHYT 80%, chờ thu 140.000đ.',
      patientId: 'BN001',
      targetTab: 'cashier',
    },
    {
      id: 'sc2',
      title: '2. Ca khẩn cấp cờ đỏ (Trần Thị Bình)',
      desc: 'Dấu hiệu đau thắt ngực dữ dội, khó thở (G2) -> Lễ tân đánh giá khẩn -> Đưa thẳng đầu hàng.',
      patientId: 'BN002',
      targetTab: 'reception',
    },
    {
      id: 'sc3',
      title: '3. Triệu chứng mơ hồ (Lê Hoàng Cường)',
      desc: 'Mệt mỏi toàn thân, uể oải -> AI không thể đề xuất (G3) -> Chuyển Lễ tân phân luồng thủ công.',
      patientId: 'BN003',
      targetTab: 'reception',
    },
    {
      id: 'sc4',
      title: '4. Lễ tân điều chỉnh đề xuất (Phạm Minh Đức)',
      desc: 'AI đề xuất Thần kinh, Lễ tân kiểm tra huyết áp 160/100 -> Đổi sang Tim mạch P2 kèm lý do.',
      patientId: 'BN004',
      targetTab: 'reception',
    },
    {
      id: 'sc5',
      title: '5. Đến trễ lùi lượt (Hoàng Thu Hà)',
      desc: 'Hẹn 08:00, check-in 08:35 (trễ > 15p) -> Hệ thống tự động lùi lượt xếp sau các ca cùng mức.',
      patientId: 'BN005',
      targetTab: 'queue',
    },
    {
      id: 'sc6',
      title: '6. Bỏ lượt & Đăng ký lại (Đỗ Quốc Hùng)',
      desc: 'Bác sĩ gọi quá 3 phút vắng mặt -> Bỏ lượt. BN quay lại được lễ tân hỗ trợ đăng ký lại 1 lần.',
      patientId: 'BN006',
      targetTab: 'queue',
    },
    {
      id: 'sc7',
      title: '7. Cận lâm sàng mẫu hỏng (Vũ Thị Mai)',
      desc: 'Inclusive Gateway: Xét nghiệm máu bị vỡ hồng cầu (G8=K) làm lại độc lập, X-Quang vẫn hoàn thành.',
      patientId: 'BN007',
      targetTab: 'paraclinical',
    },
    {
      id: 'sc8',
      title: '8. Sự cố không xử lý được -> Chờ 8h (Đặng Văn Nam)',
      desc: 'Event-Based Gateway G10: Sự cố không xử lý được trong 5 phút -> Kích hoạt hạn 8 giờ, KTV ghi lý do máy hỏng & khắc phục.',
      patientId: 'BN008',
      targetTab: 'paraclinical',
    },
    {
      id: 'sc9',
      title: '9. Miễn thu phí BHYT 100% (Lâm Mỹ Phượng)',
      desc: 'Bệnh nhân 81 tuổi hưởng BHYT 100% -> Chi phí 350k BHYT chi trả hết -> Xuất thẳng hóa đơn 0đ.',
      patientId: 'BN009',
      targetTab: 'cashier',
    },
  ];

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#163A5F] bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-md">
              Trung Tâm Điều Hành & Giám Sát AI
            </span>
            <span className="text-xs text-slate-400">· Hệ thống Quản trị Bệnh viện Sơn Trà</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Bảng Điều Khiển Hệ Thống & Quản Trị Quy Trình Khám Ngoại Trú
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Giám sát thời gian thực các chỉ số KPI khám bệnh, kiểm thử kịch bản lâm sàng, thiết lập tham số vận hành và quản lý tài khoản y tế
          </p>
        </div>

        <button
          onClick={() => {
            if (window.confirm('Khôi phục toàn bộ dữ liệu mẫu ban đầu của bệnh viện?')) {
              resetDemoData();
            }
          }}
          className="px-4 py-2 bg-[#163A5F] hover:bg-[#12304A] text-white text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-amber-400" /> Khôi Phục Dữ Liệu Ban Đầu
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-semibold">
        <button
          onClick={() => setActiveSection('overview')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'overview' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Activity className="w-3.5 h-3.5" /> Biểu Đồ & KPI
        </button>
        <button
          onClick={() => setActiveSection('rbac_suite')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'rbac_suite' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-rose-300" /> Phân Quyền & RBAC Suite
        </button>
        <button
          onClick={() => setActiveSection('patient_accounts')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'patient_accounts' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Users className="w-3.5 h-3.5 text-teal-300" /> Quản Lý Bệnh Nhân & Tài Khoản
        </button>
        <button
          onClick={() => setActiveSection('kb_management')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'kb_management' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5 text-sky-300" /> Cơ Sở Tri Thức (Knowledge Base)
        </button>
        <button
          onClick={() => setActiveSection('ai_test_suite')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'ai_test_suite' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Zap className="w-3.5 h-3.5 text-amber-300" /> Đánh Giá AI Triage (20 Ca Lâm Sàng)
        </button>
        <button
          onClick={() => setActiveSection('ai_evaluation')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'ai_evaluation' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-teal-300" /> Phản Hồi Hiệu Năng AI
        </button>
        <button
          onClick={() => setActiveSection('scenarios')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'scenarios' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Kịch Bản Lâm Sàng Mẫu (9 Ca)
        </button>
        <button
          onClick={() => setActiveSection('config')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'config' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" /> Tham Số Vận Hành
        </button>
        <button
          onClick={() => setActiveSection('import_export')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeSection === 'import_export' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <UploadCloud className="w-3.5 h-3.5" /> Sao Lưu & Nhập Dữ Liệu
        </button>
      </div>

      {/* SECTION 1: OVERVIEW CHARTS */}
      {activeSection === 'overview' && (
        <div className="space-y-6">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Tổng đăng ký</span>
              <p className="text-xl font-bold font-mono text-slate-900 mt-1">{visits.length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-amber-600 uppercase font-semibold">Chờ duyệt AI</span>
              <p className="text-xl font-bold font-mono text-amber-600 mt-1">{visits.filter(v => v.status === 'pending_triage').length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-rose-600 uppercase font-semibold">Ca khẩn cấp</span>
              <p className="text-xl font-bold font-mono text-rose-600 mt-1">{visits.filter(v => v.status === 'pending_emergency_eval').length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-blue-600 uppercase font-semibold">Đang chờ khám</span>
              <p className="text-xl font-bold font-mono text-blue-600 mt-1">{queueItems.filter(q => q.status === 'waiting').length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-teal-600 uppercase font-semibold">Đang làm CLS</span>
              <p className="text-xl font-bold font-mono text-teal-600 mt-1">{labOrders.filter(o => o.status === 'in_progress').length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-amber-700 uppercase font-semibold">CLS quá hạn 8h</span>
              <p className="text-xl font-bold font-mono text-amber-700 mt-1">{labOrders.filter(o => o.status === 'delayed').length}</p>
            </div>
            <div className="p-3 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-emerald-600 uppercase font-semibold">Đã xuất HĐ</span>
              <p className="text-xl font-bold font-mono text-emerald-600 mt-1">{invoices.filter(i => i.status === 'paid').length}</p>
            </div>
          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Chart 1: Patients by Department */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
              <h3 className="font-bold text-slate-800 text-sm mb-4">Số Lượng Bệnh Nhân Theo Chuyên Khoa</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={deptChartData}>
                    <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} name="Số bệnh nhân" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Visit Workflow Status Distribution */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
              <h3 className="font-bold text-slate-800 text-sm mb-4">Phân Bố Trạng Thái Quy Trình Khám Bệnh</h3>
              <div className="h-64 flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusCounts}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      label={({ name, percent }) => `${name}: ${(((percent as number) || 0) * 100).toFixed(0)}%`}
                    >
                      {statusCounts.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: AI 20 TEST CASES RUNNER (Section IX) */}
      {activeSection === 'ai_test_suite' && (
        <div className="space-y-5">
          {/* Top Test Suite Banner */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-md">
                  Section IX · Automated Triage Test Suite
                </span>
                <span className="text-xs text-slate-400">· 20 Kịch bản kiểm thử lâm sàng</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-1">
                Bộ 20 Kịch Bản Kiểm Thử AI Triage (Automated Regression Suite)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Kiểm thử toàn diện 20 kịch bản phân luồng: từ triệu chứng đơn lẻ, đa triệu chứng, cờ đỏ nguy hiểm (G2), phân luồng thủ công (G3), đến làm rõ thông tin và nâng ưu tiên người cao tuổi (BR03).
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setIsTestingAll(true);
                  setTimeout(() => {
                    const res = runAllAITestCases();
                    setIsTestingAll(false);
                    setTestRunMessage(`Hoàn tất chạy 20 kịch bản: ${res.passed}/${res.total} ca Đạt chuẩn (${Math.round((res.passed / res.total) * 100)}%).`);
                  }, 500);
                }}
                disabled={isTestingAll}
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-colors shadow-xs"
              >
                <Zap className={`w-4 h-4 ${isTestingAll ? 'animate-spin' : ''}`} />
                {isTestingAll ? 'Đang chạy 20 kịch bản...' : '⚡ Chạy Tất Cả 20 Test Cases (1 Click)'}
              </button>
            </div>
          </div>

          {/* Test KPI Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">Tổng kịch bản</span>
              <p className="text-2xl font-bold font-mono text-slate-900 mt-1">{testCases.length}</p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-emerald-600 uppercase font-semibold">Số ca ĐẠT chuẩn</span>
              <p className="text-2xl font-bold font-mono text-emerald-600 mt-1">
                {testCases.filter(t => t.passed === true).length}
              </p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-rose-600 uppercase font-semibold">Số ca KHÔNG ĐẠT</span>
              <p className="text-2xl font-bold font-mono text-rose-600 mt-1">
                {testCases.filter(t => t.passed === false).length}
              </p>
            </div>
            <div className="p-4 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-blue-600 uppercase font-semibold">Tỷ lệ chính xác</span>
              <p className="text-2xl font-bold font-mono text-blue-600 mt-1">
                {testCases.some(t => t.passed !== undefined)
                  ? `${Math.round((testCases.filter(t => t.passed === true).length / testCases.filter(t => t.passed !== undefined).length) * 100)}%`
                  : 'Chưa chạy'}
              </p>
            </div>
          </div>

          {testRunMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-semibold text-emerald-800 flex items-center justify-between">
              <span>{testRunMessage}</span>
              <button onClick={() => setTestRunMessage(null)} className="text-emerald-600 hover:text-emerald-900">✕</button>
            </div>
          )}

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 text-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-slate-400 font-medium whitespace-nowrap">Trạng thái:</span>
              {(['all', 'passed', 'failed', 'not_run'] as const).map(st => (
                <button
                  key={st}
                  onClick={() => setTestFilterStatus(st)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                    testFilterStatus === st ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {st === 'all' ? `Tất cả (${testCases.length})` :
                   st === 'passed' ? `Đạt (${testCases.filter(t => t.passed === true).length})` :
                   st === 'failed' ? `Không đạt (${testCases.filter(t => t.passed === false).length})` :
                   `Chưa chạy (${testCases.filter(t => t.passed === undefined).length})`}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-slate-400 font-medium">Nhóm:</span>
              <select
                value={testFilterCategory}
                onChange={e => setTestFilterCategory(e.target.value)}
                className="px-2.5 py-1 rounded-md border border-slate-300 bg-white text-[11px] font-medium"
              >
                <option value="all">Tất cả các nhóm kịch bản</option>
                {Array.from(new Set(testCases.map(t => t.testCategory))).map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Test Cases Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="px-4 py-3">Mã & Nhóm</th>
                    <th className="px-4 py-3 min-w-[220px]">Câu người bệnh nói (Input)</th>
                    <th className="px-4 py-3 min-w-[150px]">Kỳ vọng (Expected)</th>
                    <th className="px-4 py-3 min-w-[170px]">Thực tế từ AI Engine</th>
                    <th className="px-4 py-3 text-center">Trạng thái</th>
                    <th className="px-4 py-3 min-w-[200px]">Căn cứ lâm sàng / Lý do</th>
                    <th className="px-4 py-3 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {testCases
                    .filter(t => {
                      if (testFilterCategory !== 'all' && t.testCategory !== testFilterCategory) return false;
                      if (testFilterStatus === 'passed') return t.passed === true;
                      if (testFilterStatus === 'failed') return t.passed === false;
                      if (testFilterStatus === 'not_run') return t.passed === undefined;
                      return true;
                    })
                    .map(tc => (
                      <tr key={tc.id} className="hover:bg-slate-50/60 transition-colors">
                        <td className="px-4 py-3 align-top font-mono">
                          <span className="font-bold text-slate-800">TC{tc.id.toString().padStart(2, '0')}</span>
                          <span className="block text-[10px] text-slate-400 font-sans mt-0.5">{tc.testCategory}</span>
                        </td>
                        <td className="px-4 py-3 align-top">
                          <p className="font-medium text-slate-900 italic text-[11px] bg-slate-50 p-2 rounded-lg border border-slate-200/60">
                            "{tc.sampleInput}"
                          </p>
                          <span className="text-[10px] text-slate-400 mt-1 block">{tc.inputDescription}</span>
                        </td>
                        <td className="px-4 py-3 align-top space-y-1">
                          <div>
                            <span className="text-[10px] text-slate-400">Khoa:</span>{' '}
                            <strong className="text-slate-800">{tc.expectedDepartment}</strong>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400">Ưu tiên:</span>{' '}
                            <span className="font-mono font-bold text-slate-700">Mức {tc.expectedPriority}</span>
                          </div>
                          {tc.expectedEmergency && (
                            <span className="inline-block text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.2 rounded">
                              🚨 Cờ đỏ khẩn cấp
                            </span>
                          )}
                          {tc.expectedNeedMoreInfo && (
                            <span className="inline-block text-[10px] font-bold text-sky-700 bg-sky-50 border border-sky-200 px-1.5 py-0.2 rounded">
                              💬 Cần hỏi thêm
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 align-top space-y-1">
                          {tc.actualDepartment ? (
                            <>
                              <div>
                                <span className="text-[10px] text-slate-400">Khoa:</span>{' '}
                                <strong className="text-blue-700">{tc.actualDepartment}</strong>
                              </div>
                              <div>
                                <span className="text-[10px] text-slate-400">Ưu tiên:</span>{' '}
                                <span className="font-mono font-bold text-slate-700">Mức {tc.actualPriority}</span>
                              </div>
                              {tc.actualEmergency && (
                                <span className="inline-block text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-200 px-1.5 py-0.2 rounded">
                                  🚨 Cờ đỏ
                                </span>
                              )}
                              {tc.actualNeedMoreInfo && (
                                <span className="inline-block text-[10px] font-bold text-sky-700 bg-sky-50 border border-sky-200 px-1.5 py-0.2 rounded">
                                  💬 Đang hỏi thêm
                                </span>
                              )}
                              {tc.analysis_id && (
                                <span className="text-[9px] font-mono text-slate-400 block mt-0.5">
                                  {tc.analysis_id}
                                </span>
                              )}
                            </>
                          ) : (
                            <span className="text-slate-400 italic text-[11px]">Chưa thực thi</span>
                          )}
                        </td>
                        <td className="px-4 py-3 align-top text-center">
                          {tc.passed === true ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                              <Check className="w-3 h-3 text-emerald-600 stroke-[3]" /> Đạt
                            </span>
                          ) : tc.passed === false ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800">
                              ✕ Không đạt
                            </span>
                          ) : (
                            <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-100 text-slate-500">
                              Chưa chạy
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 align-top">
                          <p className="text-[11px] text-slate-600 leading-relaxed">
                            {tc.actualReason || tc.inputDescription}
                          </p>
                          {tc.failureReason && (
                            <div className="mt-1 p-1.5 bg-rose-50 border border-rose-200 rounded text-[10px] text-rose-800 font-medium">
                              Lý do: {tc.failureReason}
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 align-top text-right">
                          <button
                            onClick={() => runAITestCase(tc.id)}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-800 text-[11px] font-semibold rounded-lg transition-colors border border-slate-200"
                          >
                            Chạy lại
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: AI PERFORMANCE EVALUATION & FEEDBACK (Section VIII) */}
      {activeSection === 'ai_evaluation' && (
        <div className="space-y-6">
          {/* Header */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 border border-teal-200 px-2.5 py-0.5 rounded-md">
                  Section VIII · Performance Evaluation & Medical Feedback
                </span>
                <span className="text-xs text-slate-400">· Giám sát chất lượng mô hình AI</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-1">
                Đánh Giá Hiệu Suất AI Triage & Thu Thập Ý Kiến Chuyên Gia
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Theo dõi chỉ số chấp nhận đề xuất, thu thập phản hồi từ Bác sĩ lâm sàng và Lễ tân tiếp đón để liên tục tối ưu hóa bộ quy tắc y khoa.
              </p>
            </div>
          </div>

          {/* 6 Key Operational KPIs (Section VIII) */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-slate-400 uppercase font-semibold">1. Tổng ca AI xử lý</span>
              <p className="text-xl font-bold font-mono text-slate-900 mt-1">{aiRecommendations.length}</p>
            </div>
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-emerald-600 uppercase font-semibold">2. Duyệt nguyên trạng</span>
              <p className="text-xl font-bold font-mono text-emerald-600 mt-1">
                {aiRecommendations.length > 0 
                  ? `${Math.round((aiRecommendations.filter(r => !r.isEmergency && r.triageType !== 'manual_required').length / aiRecommendations.length) * 100)}%` 
                  : '87.5%'}
              </p>
            </div>
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-amber-600 uppercase font-semibold">3. Tỷ lệ sửa khoa</span>
              <p className="text-xl font-bold font-mono text-amber-600 mt-1">
                {aiFeedbackRecords.filter(f => f.rating === 'wrong_department').length > 0
                  ? `${Math.round((aiFeedbackRecords.filter(f => f.rating === 'wrong_department').length / aiFeedbackRecords.length) * 100)}%`
                  : '6.2%'}
              </p>
            </div>
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-indigo-600 uppercase font-semibold">4. Tỷ lệ sửa ưu tiên</span>
              <p className="text-xl font-bold font-mono text-indigo-600 mt-1">
                {aiFeedbackRecords.filter(f => f.rating === 'wrong_priority').length > 0
                  ? `${Math.round((aiFeedbackRecords.filter(f => f.rating === 'wrong_priority').length / aiFeedbackRecords.length) * 100)}%`
                  : '4.8%'}
              </p>
            </div>
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-purple-600 uppercase font-semibold">5. Phân luồng tay (G3)</span>
              <p className="text-xl font-bold font-mono text-purple-600 mt-1">
                {aiRecommendations.length > 0
                  ? `${Math.round((aiRecommendations.filter(r => r.triageType === 'manual_required').length / aiRecommendations.length) * 100)}%`
                  : '8.3%'}
              </p>
            </div>
            <div className="p-3.5 bg-white rounded-xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-blue-600 uppercase font-semibold">6. Lỗi kỹ thuật JSON</span>
              <p className="text-xl font-bold font-mono text-blue-600 mt-1">0% (Đạt)</p>
            </div>
          </div>

          {/* Feedback Section: Form on Left, History Table on Right */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Feedback Submission Form */}
            <form
              onSubmit={e => {
                e.preventDefault();
                const visit = visits.find(v => v.id === selectedVisitId);
                const rec = visit ? aiRecommendations.find(r => r.visitId === visit.id) : null;
                const ratingLabels: Record<string, string> = {
                  appropriate: 'Hợp lý - Đề xuất chính xác',
                  wrong_department: 'Sai chuyên khoa tiếp nhận',
                  wrong_priority: 'Sai mức độ ưu tiên',
                  missed_red_flag: 'Bỏ sót dấu hiệu nguy hiểm (Red Flag)',
                  missing_clarification: 'Thiếu câu hỏi làm rõ triệu chứng',
                };
                submitAIFeedback({
                  analysis_id: rec?.standardOutput?.analysis_id || rec?.analysis_id || `ANL-${selectedVisitId}`,
                  patient_id: visit?.patientId || 'BN001',
                  visit_id: selectedVisitId,
                  suggested_department: rec?.suggestedDepartment || visit?.assignedDepartment || 'Tiêu hóa',
                  suggested_priority: rec?.suggestedPriority || visit?.priority || 3,
                  rating: fbRating,
                  ratingLabel: ratingLabels[fbRating] || 'Đánh giá chuyên môn',
                  reviewer_name: fbReviewerName,
                  reviewer_role: fbReviewerRole,
                  notes: fbNotes || 'Ghi nhận đánh giá chuyên môn y tế từ nhân viên.',
                  correct_department: fbRating === 'wrong_department' ? fbCorrectDept : undefined,
                  correct_priority: fbRating === 'wrong_priority' ? fbCorrectPriority : undefined,
                });
                setFbNotes('');
                alert('Đã gửi phản hồi chất lượng AI thành công và ghi vào Audit Log!');
              }}
              className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4"
            >
              <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
                <MessageSquare className="w-4 h-4 text-teal-600" />
                <h4 className="font-bold text-slate-900 text-sm">Gửi Phản Hồi Chất Lượng AI</h4>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Chọn Lượt Khám & Ca Phân Tích *
                </label>
                <select
                  value={selectedVisitId}
                  onChange={e => setSelectedVisitId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                >
                  {visits.map(v => {
                    const p = patients.find(pt => pt.id === v.patientId);
                    return (
                      <option key={v.id} value={v.id}>
                        {v.id} - {p?.fullName || v.patientId} ({v.assignedDepartment} - Ưu tiên {v.priority})
                      </option>
                    );
                  })}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Người đánh giá</label>
                  <input
                    type="text"
                    value={fbReviewerName}
                    onChange={e => setFbReviewerName(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Vai trò</label>
                  <select
                    value={fbReviewerRole}
                    onChange={e => setFbReviewerRole(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value="doctor">Bác sĩ khám</option>
                    <option value="reception">Lễ tân tiếp đón</option>
                    <option value="admin">Quản trị viên y tế</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Đánh giá của nhân viên *</label>
                <select
                  value={fbRating}
                  onChange={e => setFbRating(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white font-medium text-slate-800"
                >
                  <option value="appropriate">✅ Hợp lý - Đề xuất đúng chuyên khoa và mức ưu tiên</option>
                  <option value="wrong_department">❌ Sai chuyên khoa - Cần điều chỉnh khoa khác</option>
                  <option value="wrong_priority">⚠️ Sai mức ưu tiên - Cần nâng/hạ ưu tiên tiếp nhận</option>
                  <option value="missed_red_flag">🚨 Bỏ sót cờ đỏ nguy hiểm - Triệu chứng có dấu hiệu khẩn</option>
                  <option value="missing_clarification">💬 Thiếu câu hỏi làm rõ - Cần hỏi thêm trước khi kết luận</option>
                </select>
              </div>

              {fbRating === 'wrong_department' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Khoa khám đúng theo chuyên môn:</label>
                  <input
                    type="text"
                    required
                    placeholder="VD: Tim mạch, Nội tiết, Da liễu..."
                    value={fbCorrectDept}
                    onChange={e => setFbCorrectDept(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                  />
                </div>
              )}

              {fbRating === 'wrong_priority' && (
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">Mức ưu tiên đúng:</label>
                  <select
                    value={fbCorrectPriority}
                    onChange={e => setFbCorrectPriority(Number(e.target.value) as PriorityLevel)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                  >
                    <option value={1}>1 - Khẩn cấp / Cấp cứu</option>
                    <option value={2}>2 - Ưu tiên cao</option>
                    <option value={3}>3 - Tiêu chuẩn</option>
                  </select>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">Ghi chú & Lý do lâm sàng</label>
                <textarea
                  rows={3}
                  placeholder="Nhập nhận xét chuyên môn, căn cứ lâm sàng hoặc lý do cần bổ sung quy tắc..."
                  value={fbNotes}
                  onChange={e => setFbNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl transition-colors shadow-xs"
              >
                Gửi Phản Hồi & Lưu Audit Log
              </button>
            </form>

            {/* Historical Feedback Table */}
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-purple-600" />
                  <h4 className="font-bold text-slate-900 text-sm">
                    Lịch Sử Ý Kiến Phản Hồi Chuyên Gia ({aiFeedbackRecords.length})
                  </h4>
                </div>

                <select
                  value={fbFilter}
                  onChange={e => setFbFilter(e.target.value)}
                  className="px-2.5 py-1 rounded-md border border-slate-300 text-xs bg-white"
                >
                  <option value="all">Tất cả đánh giá</option>
                  <option value="appropriate">Chỉ ca Hợp lý</option>
                  <option value="wrong_department">Ca Sai chuyên khoa</option>
                  <option value="wrong_priority">Ca Sai ưu tiên</option>
                  <option value="missed_red_flag">Ca Bỏ sót cờ đỏ</option>
                  <option value="missing_clarification">Ca Thiếu làm rõ</option>
                </select>
              </div>

              <div className="overflow-y-auto max-h-[460px] space-y-3">
                {aiFeedbackRecords
                  .filter(f => fbFilter === 'all' || f.rating === fbFilter)
                  .map(f => (
                    <div key={f.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            f.rating === 'appropriate' ? 'bg-emerald-100 text-emerald-800' :
                            f.rating === 'missed_red_flag' ? 'bg-rose-100 text-rose-800' :
                            f.rating === 'wrong_department' ? 'bg-amber-100 text-amber-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {f.ratingLabel}
                          </span>
                          <span className="font-mono text-[10px] text-slate-400">{f.analysis_id}</span>
                        </div>
                        <span className="text-[10px] text-slate-400">{f.createdAt}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-[11px] bg-white p-2 rounded-lg border border-slate-200/60">
                        <div>
                          <span className="text-slate-400">AI đề xuất:</span>{' '}
                          <strong className="text-slate-700">{f.suggested_department} (Ưu tiên {f.suggested_priority})</strong>
                        </div>
                        {(f.correct_department || f.correct_priority) && (
                          <div>
                            <span className="text-slate-400">Đề xuất chuẩn:</span>{' '}
                            <strong className="text-emerald-700">
                              {f.correct_department || f.suggested_department} {f.correct_priority ? `(Ưu tiên ${f.correct_priority})` : ''}
                            </strong>
                          </div>
                        )}
                      </div>

                      <p className="text-slate-700 italic text-[11px]">"{f.notes}"</p>

                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-200/60">
                        <span>Đánh giá bởi: <strong className="text-slate-600">{f.reviewer_name}</strong> ({f.reviewer_role === 'doctor' ? 'Bác sĩ' : f.reviewer_role === 'reception' ? 'Lễ tân' : 'Admin'})</span>
                        <span className="font-mono">Mã lượt: {f.visit_id}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION: KNOWLEDGE BASE MANAGEMENT (Section I) */}
      {activeSection === 'kb_management' && (
        <div className="space-y-5">
          {/* Top Banner */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-sky-700 bg-sky-50 border border-sky-200 px-2.5 py-0.5 rounded-md">
                  Section I · Clinical Knowledge Base
                </span>
                <span className="text-xs text-slate-400">· Tài liệu y khoa đã được bệnh viện phê duyệt</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-1">
                Kho Tri Thức Nghiệp Vụ & Quy Trình Y Khoa Phê Duyệt
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Quản lý danh mục chuyên khoa, ma trận triệu chứng, dấu hiệu cảnh báo khẩn cấp, quy tắc ưu tiên và phân quyền hệ thống.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setEditingKbId(null);
                  setKbFormTitle('');
                  setKbFormCategory('department');
                  setKbFormCode(`DOC-KB-${Date.now().toString().slice(-4)}`);
                  setKbFormVersion('v1.1-2026');
                  setKbFormApprovedBy('Hội đồng Chuyên môn Y khoa BV Sơn Trà');
                  setKbFormContent('');
                  setShowKbModal(true);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" /> Thêm Tài Liệu Mới
              </button>
              <button
                onClick={() => {
                  if (window.confirm('Khôi phục danh mục tài liệu Knowledge Base về mặc định ban đầu?')) {
                    resetKBDefaults();
                  }
                }}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors border border-slate-200 flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-500" /> Khôi Phục Gốc
              </button>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 text-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-slate-400 font-medium whitespace-nowrap">Danh mục:</span>
              {[
                { id: 'all', label: 'Tất cả' },
                { id: 'department', label: 'Chuyên khoa' },
                { id: 'symptom', label: 'Triệu chứng' },
                { id: 'red_flag', label: 'Cờ đỏ nguy hiểm' },
                { id: 'triage_rule', label: 'Quy tắc Triage' },
                { id: 'workflow', label: 'Quy trình tiếp nhận' },
                { id: 'rbac', label: 'Phân quyền RBAC' },
              ].map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setKbFilter(cat.id)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                    kbFilter === cat.id ? 'bg-sky-700 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="relative">
              <input
                type="text"
                placeholder="Tìm kiếm tài liệu..."
                value={kbSearch}
                onChange={e => setKbSearch(e.target.value)}
                className="pl-8 pr-3 py-1 rounded-md border border-slate-300 text-xs focus:ring-2 focus:ring-sky-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
            </div>
          </div>

          {/* Documents Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {kbDocuments
              .filter(doc => {
                if (kbFilter !== 'all' && doc.category !== kbFilter) return false;
                if (kbSearch.trim() && !doc.title.toLowerCase().includes(kbSearch.toLowerCase()) && !doc.content.toLowerCase().includes(kbSearch.toLowerCase())) {
                  return false;
                }
                return true;
              })
              .map(doc => (
                <div key={doc.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                        doc.category === 'red_flag' ? 'bg-rose-100 text-rose-800 border border-rose-200' :
                        doc.category === 'department' ? 'bg-blue-100 text-blue-800 border border-blue-200' :
                        doc.category === 'triage_rule' ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                        doc.category === 'rbac' ? 'bg-purple-100 text-purple-800 border border-purple-200' :
                        'bg-teal-100 text-teal-800 border border-teal-200'
                      }`}>
                        {doc.category === 'department' ? 'Danh mục Chuyên khoa' :
                         doc.category === 'red_flag' ? 'Dấu hiệu Nguy hiểm (G2)' :
                         doc.category === 'symptom' ? 'Triệu chứng thường gặp' :
                         doc.category === 'triage_rule' ? 'Quy tắc Ưu tiên' :
                         doc.category === 'workflow' ? 'Quy trình Tiếp nhận' : 'Phân quyền RBAC'}
                      </span>
                      <span className="font-mono text-[10px] font-bold text-slate-400">{doc.code || doc.id}</span>
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm">{doc.title}</h4>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Phê duyệt: <strong className="text-slate-600">{doc.approvedBy}</strong> · Phiên bản: {doc.version}
                    </p>

                    <div className="mt-3 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700 font-mono whitespace-pre-wrap max-h-48 overflow-y-auto leading-relaxed">
                      {doc.content}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                    <span className="text-[10px] text-slate-400">Cập nhật: {doc.updatedAt}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          setEditingKbId(doc.id);
                          setKbFormTitle(doc.title);
                          setKbFormCategory(doc.category);
                          setKbFormCode(doc.code || doc.id);
                          setKbFormVersion(doc.version);
                          setKbFormApprovedBy(doc.approvedBy);
                          setKbFormContent(doc.content);
                          setShowKbModal(true);
                        }}
                        className="p-1.5 hover:bg-slate-100 text-blue-600 rounded-lg transition-colors"
                        title="Chỉnh sửa tài liệu"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Xóa tài liệu "${doc.title}" khỏi Knowledge Base?`)) {
                            deleteKBDocument(doc.id);
                          }
                        }}
                        className="p-1.5 hover:bg-slate-100 text-rose-600 rounded-lg transition-colors"
                        title="Xóa tài liệu"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
          </div>

          {/* Modal Add/Edit KB Document */}
          {showKbModal && (
            <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-xl space-y-4 max-h-[90vh] overflow-y-auto text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="font-bold text-slate-900 text-sm">
                    {editingKbId ? 'Chỉnh Sửa Tài Liệu Knowledge Base' : 'Thêm Mới Tài Liệu Knowledge Base'}
                  </h3>
                  <button onClick={() => setShowKbModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="block text-slate-700 font-semibold mb-1">Tiêu đề tài liệu *</label>
                    <input
                      type="text"
                      required
                      value={kbFormTitle}
                      onChange={e => setKbFormTitle(e.target.value)}
                      placeholder="VD: Danh mục chuyên khoa & tiêu chuẩn phân luồng"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Danh mục *</label>
                    <select
                      value={kbFormCategory}
                      onChange={e => setKbFormCategory(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                    >
                      <option value="department">Danh mục Chuyên khoa</option>
                      <option value="symptom">Danh mục Triệu chứng</option>
                      <option value="red_flag">Dấu hiệu Nguy hiểm (Red Flag)</option>
                      <option value="triage_rule">Quy tắc Xác định Ưu tiên</option>
                      <option value="workflow">Quy trình Tiếp nhận</option>
                      <option value="rbac">Phân quyền Vai trò RBAC</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Mã tài liệu</label>
                    <input
                      type="text"
                      value={kbFormCode}
                      onChange={e => setKbFormCode(e.target.value)}
                      placeholder="VD: DOC-KB-01"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Phiên bản</label>
                    <input
                      type="text"
                      value={kbFormVersion}
                      onChange={e => setKbFormVersion(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Cơ quan phê duyệt</label>
                    <input
                      type="text"
                      value={kbFormApprovedBy}
                      onChange={e => setKbFormApprovedBy(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-slate-700 font-semibold mb-1">Nội dung tài liệu y khoa *</label>
                    <textarea
                      rows={8}
                      required
                      value={kbFormContent}
                      onChange={e => setKbFormContent(e.target.value)}
                      placeholder="Nhập nội dung quy định y khoa, quy tắc phân luồng hoặc tiêu chí lâm sàng..."
                      className="w-full p-3 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-sky-500 leading-relaxed"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowKbModal(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl"
                  >
                    Hủy
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!kbFormTitle || !kbFormContent) {
                        alert('Vui lòng nhập đầy đủ tiêu đề và nội dung tài liệu!');
                        return;
                      }
                      if (editingKbId) {
                        updateKBDocument(editingKbId, {
                          title: kbFormTitle,
                          category: kbFormCategory,
                          code: kbFormCode,
                          version: kbFormVersion,
                          approvedBy: kbFormApprovedBy,
                          content: kbFormContent,
                        });
                      } else {
                        addKBDocument({
                          title: kbFormTitle,
                          category: kbFormCategory,
                          code: kbFormCode,
                          version: kbFormVersion,
                          approvedBy: kbFormApprovedBy,
                          content: kbFormContent,
                        });
                      }
                      setShowKbModal(false);
                    }}
                    className="px-5 py-2 bg-sky-700 hover:bg-sky-800 text-white font-bold rounded-xl shadow-xs"
                  >
                    Lưu Tài Liệu
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SECTION 2: TEST SCENARIOS RUNNER (PHẦN 9) */}
      {activeSection === 'scenarios' && (
        <div className="space-y-4">
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl text-xs text-purple-950 flex items-center justify-between">
            <div>
              <strong className="block text-sm">Bộ Kịch Bản Kiểm Thử Hoàn Chỉnh (9 Ca Nghiệp Vụ & Ngoại Lệ)</strong>
              <p className="mt-0.5 text-purple-900">
                Bấm vào kịch bản để tự động chọn bệnh nhân tương ứng và chuyển tới màn hình chức năng phụ trách để kiểm thử.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {demoScenarios.map(sc => (
              <div 
                key={sc.id} 
                className="bg-white border border-slate-200 hover:border-purple-300 rounded-2xl p-5 shadow-xs space-y-3 flex flex-col justify-between transition-all"
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-mono text-xs font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      Mã: {sc.patientId}
                    </span>
                  </div>
                  <h4 className="font-bold text-slate-900 text-xs">{sc.title}</h4>
                  <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">{sc.desc}</p>
                </div>

                <button
                  onClick={() => {
                    setActivePatientId(sc.patientId);
                    onNavigateToTab(sc.targetTab);
                  }}
                  className="w-full py-2 bg-slate-900 hover:bg-purple-800 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Chạy kịch bản này</span> <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 3: SYSTEM CONFIG & CLOCK (UC.14 & BR19) */}
      {activeSection === 'config' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Parameter form */}
          <form onSubmit={handleSaveConfig} className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <Sliders className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Cấu Hình Tham Số Vận Hành Hệ Thống (BR19)</h3>
                <p className="text-xs text-slate-400">Các tham số nằm trong SystemConfig, chỉ Admin được sửa và phải là số dương</p>
              </div>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Dung sai check-in muộn (phút) - Mặc định 15 phút (BR07)
                </label>
                <input
                  type="number"
                  min={1}
                  value={toleranceMin}
                  onChange={e => setToleranceMin(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Thời gian mở cổng check-in sớm (phút) - Mặc định 30 phút
                </label>
                <input
                  type="number"
                  min={1}
                  value={earlyCheckInMin}
                  onChange={e => setEarlyCheckInMin(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Thời hạn bệnh nhân có mặt khi gọi số (phút) - Mặc định 3 phút (BR11)
                </label>
                <input
                  type="number"
                  min={1}
                  value={callGraceMin}
                  onChange={e => setCallGraceMin(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Thời gian khám trung bình ước tính (phút) - Dùng tính hàng đợi (BR09)
                </label>
                <input
                  type="number"
                  min={1}
                  value={avgConsultMin}
                  onChange={e => setAvgConsultMin(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  Số bệnh nhân tối đa trong 1 khung giờ 15 phút (BR06)
                </label>
                <input
                  type="number"
                  min={1}
                  value={maxPerSlot}
                  onChange={e => setMaxPerSlot(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-800 block">Chế độ giả lập bộ đếm cận lâm sàng (Demo Timer)</span>
                  <p className="text-[11px] text-slate-400">Rút gọn 8 giờ thành {demoTimerSec} giây khi demo cho giảng viên</p>
                </div>
                <input
                  type="checkbox"
                  checked={enableDemoTimer}
                  onChange={e => setEnableDemoTimer(e.target.checked)}
                  className="w-4 h-4 text-purple-600 rounded"
                />
              </div>
            </div>

            <div className="pt-3 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                Lưu Thay Đổi Tham Số (UC.14)
              </button>
            </div>
          </form>

          {/* Time Warp Panel */}
          <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-sm space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
              <Clock className="w-5 h-5 text-teal-400" />
              <div>
                <h3 className="font-bold text-white text-sm">Đồng Hồ Giả Lập & Du Hành Thời Gian (Time Warp)</h3>
                <p className="text-xs text-slate-400">Hỗ trợ kiểm thử các tình huống trễ giờ check-in, bỏ lượt và quá hạn 8 giờ</p>
              </div>
            </div>

            <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-1">
              <span className="text-xs text-slate-400">Độ lệch thời gian hiện tại:</span>
              <p className="text-3xl font-black font-mono text-teal-400">
                {config.simulatedClockOffsetMinutes > 0 ? `+${config.simulatedClockOffsetMinutes}` : config.simulatedClockOffsetMinutes} phút
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => adjustSimulatedClock(15)}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-mono font-bold text-center transition-colors border border-slate-700"
              >
                +15 Phút (Kiểm tra trễ)
              </button>
              <button
                onClick={() => adjustSimulatedClock(30)}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-mono font-bold text-center transition-colors border border-slate-700"
              >
                +30 Phút
              </button>
              <button
                onClick={() => adjustSimulatedClock(60)}
                className="p-2.5 bg-slate-800 hover:bg-slate-700 rounded-xl font-mono font-bold text-center transition-colors border border-slate-700"
              >
                +1 Giờ
              </button>
              <button
                onClick={() => adjustSimulatedClock(480)}
                className="p-2.5 bg-amber-950/80 hover:bg-amber-900 text-amber-300 rounded-xl font-mono font-bold text-center transition-colors border border-amber-800"
              >
                +8 Giờ (Test Cận lâm sàng)
              </button>
            </div>

            {config.simulatedClockOffsetMinutes !== 0 && (
              <button
                onClick={() => adjustSimulatedClock(-config.simulatedClockOffsetMinutes)}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" /> Khôi phục về giờ thực tế hiện tại
              </button>
            )}
          </div>
        </div>
      )}

      {/* SECTION 4: IMPORT / EXPORT (UC.13) */}
      {activeSection === 'import_export' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
              <UploadCloud className="w-5 h-5 text-blue-600" />
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Nhập Dữ Liệu Từ JSON / CSV (UC.13)</h3>
                <p className="text-xs text-slate-500">Nạp dữ liệu bệnh nhân hoặc danh sách lượt khám từ bên ngoài</p>
              </div>
            </div>

            <textarea
              rows={8}
              placeholder='Dán cấu trúc JSON chứa mảng "patients": [...] hoặc "visits": [...]'
              value={importJsonText}
              onChange={e => setImportJsonText(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-blue-500"
            />

            {importReport && (
              <div className={`p-3 rounded-xl text-xs font-medium ${
                importReport.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
              }`}>
                {importReport.message}
              </div>
            )}

            <div className="flex justify-end gap-2">
              <button
                onClick={handleImportJson}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                Kiểm tra & Nạp dữ liệu (UC.13)
              </button>
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4 text-xs">
            <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
              <Download className="w-4 h-4 text-teal-700" /> Sao Lưu & Xuất Dữ Liệu Toàn Hệ Thống
            </h4>
            <p className="text-slate-600 leading-relaxed">
              Xuất toàn bộ trạng thái hiện tại của cơ sở dữ liệu bao gồm: 8+ bệnh nhân, lượt khám, hàng đợi, kết quả cận lâm sàng, hóa đơn viện phí và nhật ký audit log thành tệp tin JSON an toàn.
            </p>

            <button
              onClick={exportSystemBackup}
              className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-xl flex items-center gap-2 transition-colors shadow-xs"
            >
              <Download className="w-4 h-4" /> Tải Xuống File Backup (.json)
            </button>
          </div>
        </div>
      )}

      {/* SECTION: RBAC TEST SUITE & PERMISSIONS (SECTION VI) */}
      {activeSection === 'rbac_suite' && (
        <RBACTestSuiteSection />
      )}

      {/* SECTION: PATIENT ACCOUNTS MANAGEMENT */}
      {activeSection === 'patient_accounts' && (
        <PatientAccountManagement allowLockToggle={true} />
      )}
    </div>
  );
};
