import { 
  Patient, 
  Visit, 
  PriorityLevel, 
  StructuredSymptom, 
  AIRecommendation, 
  WorkflowLog, 
  NotificationItem, 
  ClinicalOrder, 
  SystemConfig,
  UserRole
} from '../types';
import { AITriageEngine } from './aiTriageEngine';

// Dictionaries for medical triage rules
const DANGER_KEYWORDS = [
  'đau ngực', 'tức ngực', 'đau thắt ngực', 'khó thở', 'ngất', 'bất tỉnh', 
  'co giật', 'liệt', 'méo miệng', 'chảy máu nhiều', 'nôn ra máu', 'đau bụng dữ dội', 
  'hôn mê', 'sốc', 'khò khè nặng', 'tím tái', 'gãy xương hở', 'chấn thương đầu'
];

const DEPARTMENT_KEYWORDS: Record<string, { keywords: string[]; room: string }> = {
  'Tim mạch': {
    keywords: ['tim', 'huyết áp', 'hồi hộp', 'đánh trống ngực', 'mạch nhanh', 'nhói ngực', 'phù chân', 'tăng huyết áp'],
    room: 'Phòng 201 - Nội Tim mạch',
  },
  'Tiêu hóa': {
    keywords: ['bụng', 'dạ dày', 'thượng vị', 'buồn nôn', 'nôn', 'tiêu chảy', 'ợ chua', 'ợ hơi', 'táo bón', 'đầy bụng', 'khó tiêu', 'đau bụng'],
    room: 'Phòng 103 - Nội Tiêu hóa',
  },
  'Hô hấp': {
    keywords: ['ho', 'sốt', 'đờm', 'khạc đờm', 'phổi', 'ngạt mũi', 'viêm họng', 'khàn tiếng', 'thở rít', 'viêm phế quản'],
    room: 'Phòng 102 - Nội Hô hấp',
  },
  'Thần kinh': {
    keywords: ['đầu', 'đau đầu', 'chóng mặt', 'hoa mắt', 'mất ngủ', 'tê bì', 'đau nửa đầu', 'tiền đình', 'run tay chân'],
    room: 'Phòng 204 - Nội Thần kinh',
  },
  'Tai mũi họng': {
    keywords: ['tai', 'mũi', 'họng', 'ù tai', 'chảy mủ tai', 'viêm xoang', 'ngạt mũi', 'chảy máu cam', 'amidan', 'đau tai'],
    room: 'Phòng 105 - Tai Mũi Họng',
  },
  'Da liễu': {
    keywords: ['da', 'ngứa', 'mẩn đỏ', 'dị ứng', 'mề đay', 'mụn', 'vảy nến', 'nấm da', 'bọng nước', 'phát ban'],
    room: 'Phòng 106 - Da liễu',
  },
  'Nội tổng quát': {
    keywords: ['khám sức khỏe', 'sút cân', 'mệt', 'uể oải', 'chán ăn', 'khám tổng quát'],
    room: 'Phòng 101 - Khám Tổng quát',
  },
};

// Normalize Vietnamese string for keyword matching
export function normalizeVietnamese(str: string): string {
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'd')
    .trim();
}

export class AIWorkflowOrchestrator {
  /**
   * Analyzes raw patient text and structured questionnaire to generate AI triage recommendation
   * using the upgraded AITriageEngine, Knowledge Base and Rule Engine.
   */
  static analyzeSymptoms(
    patient: Patient,
    symptomText: string,
    historyText?: string,
    chatHistory: any[] = []
  ): AIRecommendation {
    const standardOut = AITriageEngine.processTriageConversation(
      patient,
      symptomText,
      chatHistory
    );

    return {
      id: `AIR-${standardOut.analysis_id}`,
      analysis_id: standardOut.analysis_id,
      visitId: '',
      suggestedDepartment: standardOut.recommended_department,
      suggestedPriority: standardOut.priority_level,
      isEmergency: standardOut.emergency_warning,
      emergencyTriggers: standardOut.red_flags,
      rationale: standardOut.reason,
      confidence: standardOut.confidence,
      triageType: standardOut.emergency_warning ? 'ai_auto' : standardOut.recommended_department === 'Cần phân luồng thủ công' ? 'manual_required' : 'ai_auto',
      createdAt: standardOut.timestamp,
      standardOutput: standardOut,
    };
  }

  /**
   * BR06: Suggests the next available 15-minute appointment slot for a department
   */
  static getNextAvailableSlot(
    existingVisits: Visit[],
    department: string,
    maxPatientsPerSlot: number = 3
  ): string {
    const slots = [
      '08:00 - 08:15', '08:15 - 08:30', '08:30 - 08:45', '08:45 - 09:00',
      '09:00 - 09:15', '09:15 - 09:30', '09:30 - 09:45', '09:45 - 10:00',
      '10:00 - 10:15', '10:15 - 10:30', '10:30 - 10:45', '10:45 - 11:00',
      '13:30 - 13:45', '13:45 - 14:00', '14:00 - 14:15', '14:15 - 14:30',
      '14:30 - 14:45', '14:45 - 15:00', '15:00 - 15:15', '15:15 - 15:30',
    ];

    for (const slot of slots) {
      const count = existingVisits.filter(
        v => v.assignedDepartment === department && v.slotTime === slot && v.status !== 'cancelled'
      ).length;
      if (count < maxPatientsPerSlot) {
        return slot;
      }
    }
    return '15:30 - 15:45';
  }

  /**
   * Helper to check check-in time validity (BR07)
   */
  static evaluateCheckInTiming(
    slotTime: string,
    config: SystemConfig
  ): { isValid: boolean; isEarly: boolean; isLate: boolean; message: string } {
    if (!slotTime || slotTime.includes('Khẩn cấp') || !slotTime.includes('-')) {
      return { isValid: true, isEarly: false, isLate: false, message: 'Check-in tiếp nhận ưu tiên.' };
    }

    try {
      const [startStr] = slotTime.split('-').map(s => s.trim());
      const [startHour, startMin] = startStr.split(':').map(Number);

      const now = new Date();
      // Apply simulated clock offset
      now.setMinutes(now.getMinutes() + (config.simulatedClockOffsetMinutes || 0));

      const slotMinutes = startHour * 60 + startMin;
      const currentMinutes = now.getHours() * 60 + now.getMinutes();

      const diff = currentMinutes - slotMinutes; // negative = early, positive = late

      if (diff < -config.earlyCheckInMinutes) {
        return {
          isValid: false,
          isEarly: true,
          isLate: false,
          message: `Quý khách đến quá sớm! Hệ thống chỉ mở cổng check-in từ ${config.earlyCheckInMinutes} phút trước giờ hẹn (tức từ ${formatMinutesToTime(slotMinutes - config.earlyCheckInMinutes)}). Vui lòng ngồi chờ tại sảnh tiếp đón.`,
        };
      }

      if (diff > config.checkInToleranceMinutes) {
        return {
          isValid: true,
          isEarly: false,
          isLate: true,
          message: `Quý khách đến muộn hơn dung sai cho phép (${diff} phút muộn > ${config.checkInToleranceMinutes} phút). Hệ thống thực hiện lùi lượt xếp sau các bệnh nhân cùng mức ưu tiên trong hàng đợi.`,
        };
      }

      return {
        isValid: true,
        isEarly: false,
        isLate: false,
        message: 'Check-in đúng khung giờ hợp lệ.',
      };
    } catch {
      return { isValid: true, isEarly: false, isLate: false, message: 'Check-in hợp lệ.' };
    }
  }

  /**
   * Creates a formal audit log entry
   */
  static createLog(
    visit: Visit,
    patient: Patient,
    actorName: string,
    role: UserRole | 'Hệ thống AI',
    action: string,
    stage: string,
    previousState: string,
    newState: string,
    reason?: string
  ): WorkflowLog {
    const now = new Date();
    const timeStr = `${now.toLocaleDateString('vi-VN')} ${now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}`;
    return {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      visitId: visit.id,
      patientId: patient.id,
      patientName: patient.fullName,
      actorName,
      role,
      action,
      stage,
      previousState,
      newState,
      reason,
      timestamp: timeStr,
    };
  }

  /**
   * Dispatches a targeted role notification
   */
  static createNotification(
    targetRole: UserRole | 'all',
    title: string,
    message: string,
    type: 'info' | 'warning' | 'alert' | 'success',
    targetPatientId?: string,
    actionLink?: string
  ): NotificationItem {
    return {
      id: `NOTIF-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      targetRole,
      targetPatientId,
      title,
      message,
      type,
      createdAt: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      isRead: false,
      actionLink,
    };
  }
}

function formatMinutesToTime(totalMinutes: number): string {
  const h = Math.floor(totalMinutes / 60) % 24;
  const m = totalMinutes % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}
