import React from 'react';

interface QrCodeProps {
  value: string;
  size?: number;
  className?: string;
  label?: string;
}

/**
 * Deterministic SVG QR Code generator simulating clinical standard QR format
 */
export const QrCodeView: React.FC<QrCodeProps> = ({ value, size = 180, className = '', label }) => {
  // Generate deterministic grid pattern based on string hash
  const gridSize = 25;
  const cells: boolean[][] = [];

  // Simple string hash
  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = (hash << 5) - hash + value.charCodeAt(i);
    hash |= 0;
  }

  // Generate 25x25 matrix
  for (let r = 0; r < gridSize; r++) {
    cells[r] = [];
    for (let c = 0; c < gridSize; c++) {
      // Finder patterns (3 corners: top-left, top-right, bottom-left)
      const isFinderTL = (r < 7 && c < 7);
      const isFinderTR = (r < 7 && c >= gridSize - 7);
      const isFinderBL = (r >= gridSize - 7 && c < 7);

      if (isFinderTL) {
        const border = r === 0 || r === 6 || c === 0 || c === 6;
        const inner = r >= 2 && r <= 4 && c >= 2 && c <= 4;
        cells[r][c] = border || inner;
      } else if (isFinderTR) {
        const border = r === 0 || r === 6 || c === gridSize - 7 || c === gridSize - 1;
        const inner = r >= 2 && r <= 4 && c >= gridSize - 5 && c <= gridSize - 3;
        cells[r][c] = border || inner;
      } else if (isFinderBL) {
        const border = r === gridSize - 7 || r === gridSize - 1 || c === 0 || c === 6;
        const inner = r >= gridSize - 5 && r <= gridSize - 3 && c >= 2 && c <= 4;
        cells[r][c] = border || inner;
      } else if (r === 6 || c === 6) {
        // Timing patterns
        cells[r][c] = (r + c) % 2 === 0;
      } else {
        // Deterministic content bits
        const seed = (r * 31 + c * 17 + Math.abs(hash) + value.charCodeAt((r + c) % value.length)) % 100;
        cells[r][c] = seed < 48;
      }
    }
  }

  const cellSize = size / gridSize;

  return (
    <div className={`flex flex-col items-center p-3 bg-white border border-slate-200 rounded-xl shadow-xs ${className}`}>
      <svg 
        width={size} 
        height={size} 
        viewBox={`0 0 ${size} ${size}`}
        className="shape-rendering-crispEdges"
      >
        <rect width={size} height={size} fill="#ffffff" />
        {cells.map((row, r) =>
          row.map((active, c) =>
            active ? (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize + 0.3}
                height={cellSize + 0.3}
                fill="#0f172a"
              />
            ) : null
          )
        )}
      </svg>
      {label && (
        <span className="mt-2 text-xs font-mono font-semibold text-slate-700 tracking-wider">
          {label}
        </span>
      )}
    </div>
  );
};
