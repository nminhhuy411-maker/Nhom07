import React, { useState, useMemo } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { 
  ShieldCheck, 
  Lock, 
  LogIn, 
  User, 
  UserCheck, 
  Stethoscope, 
  FlaskConical, 
  Receipt, 
  Pill,
  Eye, 
  EyeOff, 
  KeyRound, 
  CheckCircle2, 
  AlertCircle,
  Building2,
  Sparkles,
  UserPlus,
  ArrowRight,
  Phone,
  Mail,
  MapPin,
  Calendar,
  CreditCard,
  Shield,
  FileCheck,
  HelpCircle,
  Check,
  X
} from 'lucide-react';
import { UserRole, PatientRegisterPayload } from '../../types';

interface DemoAccountItem {
  role: UserRole;
  label: string;
  username: string;
  password: string;
  title: string;
  name: string;
  department: string;
  cccd?: string;
}

const DEMO_CREDENTIALS: DemoAccountItem[] = [
  { role: 'admin', label: 'Quản trị viên', username: 'admin', password: 'Admin@2026', title: 'Quản trị viên Hệ thống', name: 'Nguyễn Minh Huy', department: 'Phòng CNTT & Quản trị' },
  { role: 'reception', label: 'Lễ tân tiếp đón', username: 'tiepnhan01', password: 'TiepNhan@2026', title: 'Tiếp nhận & Phân luồng', name: 'Lê Thị Hoa', department: 'Khoa Khám bệnh - Bàn 01' },
  { role: 'doctor', label: 'Bác sĩ điều trị', username: 'bacsi01', password: 'BacSi@2026', title: 'Bác sĩ Khám & Điều trị', name: 'BS. CKI Trần Minh Tuấn', department: 'Khoa Nội Tiêu hóa - PK 201' },
  { role: 'paraclinical', label: 'Cận lâm sàng', username: 'canlamsang01', password: 'CLS@2026', title: 'Kỹ thuật viên Trưởng', name: 'KTV. Nguyễn Đức Trung', department: 'Khoa Cận lâm sàng & CĐHA' },
  { role: 'cashier', label: 'Thu ngân viện phí', username: 'thungan01', password: 'ThuNgan@2026', title: 'Nhân viên Thu ngân', name: 'CN. Hoàng Mai Anh', department: 'Quầy Thu phí 02' },
  { role: 'pharmacy', label: 'Nhà thuốc ngoại trú', username: 'nhathuoc01', password: 'NhaThuoc@2026', title: 'Dược sĩ Phát thuốc', name: 'DS. Lê Thị Mai', department: 'Nhà thuốc Ngoại trú' },
  { role: 'patient', label: 'Bệnh nhân mẫu', username: 'benhnhan01', password: 'BenhNhan@2026', title: 'Bệnh nhân Ngoại trú', name: 'Nguyễn Văn An', department: 'Cổng Bệnh nhân', cccd: '048090000001' },
];

export const LoginScreen: React.FC = () => {
  const { login, registerPatientAccount, forgotPasswordLookup, changePassword } = useHospital();

  // Mode: 'login' | 'register'
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState('admin');
  const [password, setPassword] = useState('Admin@2026');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loginError, setLoginError] = useState('');
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Registration form state (4 groups)
  const [regForm, setRegForm] = useState({
    // Group 1: Identity
    cccd: '',
    fullName: '',
    dateOfBirth: '1995-05-15',
    gender: 'Nam' as 'Nam' | 'Nữ' | 'Khác',
    nationality: 'Việt Nam',
    // Group 2: Contact
    phone: '',
    email: '',
    province: 'TP. Đà Nẵng',
    district: 'Q. Sơn Trà',
    ward: 'P. An Hải Tây',
    street: '',
    // Group 3: Account & Security
    username: '',
    useCccdAsUsername: true,
    regPassword: '',
    confirmPassword: '',
    // Group 4: Consent & Terms
    accuracyConsent: false,
    privacyConsent: false,
  });

  const [showRegPassword, setShowRegPassword] = useState(false);
  const [showRegConfirmPassword, setShowRegConfirmPassword] = useState(false);
  const [regError, setRegError] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [regSuccessData, setRegSuccessData] = useState<{ patientId: string; username: string; fullName: string } | null>(null);

  // Modals
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotInput, setForgotInput] = useState('');
  const [forgotResult, setForgotResult] = useState<{ success: boolean; message: string; tempPw?: string } | null>(null);

  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false);
  const [changeForm, setChangeForm] = useState({ oldPw: '', newPw: '', confirmPw: '' });
  const [changeMsg, setChangeMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Calculate age from dateOfBirth
  const calculatedAge = useMemo(() => {
    if (!regForm.dateOfBirth) return null;
    const birthYear = new Date(regForm.dateOfBirth).getFullYear();
    const currentYear = new Date().getFullYear();
    return currentYear - birthYear;
  }, [regForm.dateOfBirth]);

  // Password strength calculation
  const passwordStrength = useMemo(() => {
    const pw = regForm.regPassword;
    if (!pw) return { score: 0, label: 'Chưa nhập', color: 'bg-slate-200', text: 'text-slate-400' };

    let score = 0;
    if (pw.length >= 8) score += 1;
    if (/[A-Z]/.test(pw)) score += 1;
    if (/[a-z]/.test(pw)) score += 1;
    if (/[0-9]/.test(pw)) score += 1;
    if (/[^A-Za-z0-9]/.test(pw)) score += 1;

    if (score <= 2) return { score: 1, label: 'Yếu (Cần thêm ký tự)', color: 'bg-rose-500', text: 'text-rose-600' };
    if (score <= 4) return { score: 2, label: 'Trung bình (Đạt chuẩn)', color: 'bg-amber-500', text: 'text-amber-600' };
    return { score: 3, label: 'Mạnh (Bảo mật tối ưu)', color: 'bg-emerald-500', text: 'text-emerald-600' };
  }, [regForm.regPassword]);

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'admin': return <ShieldCheck className="w-4 h-4 text-purple-600" />;
      case 'reception': return <UserCheck className="w-4 h-4 text-blue-600" />;
      case 'doctor': return <Stethoscope className="w-4 h-4 text-emerald-600" />;
      case 'paraclinical': return <FlaskConical className="w-4 h-4 text-teal-600" />;
      case 'cashier': return <Receipt className="w-4 h-4 text-amber-600" />;
      case 'pharmacy': return <Pill className="w-4 h-4 text-indigo-600" />;
      default: return <User className="w-4 h-4 text-slate-600" />;
    }
  };

  const handleFillDemo = (demo: DemoAccountItem) => {
    setAuthMode('login');
    setLoginIdentifier(demo.username);
    setPassword(demo.password);
    setLoginError('');
  };

  // Login handler
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setIsLoggingIn(true);

    try {
      const res = login(loginIdentifier, password);
      if (!res.success) {
        setLoginError(res.message);
      }
    } catch (err: any) {
      console.error('Login error:', err);
      setLoginError(err?.message || 'Đăng nhập không thành công. Vui lòng kiểm tra lại thông tin.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Helper to format full name to Title Case
  const handleFullNameChange = (val: string) => {
    // Format Title Case: "nguyen van an" -> "Nguyễn Văn An"
    const formatted = val.replace(/(^|\s)\S/g, l => l.toUpperCase());
    setRegForm(prev => ({ ...prev, fullName: formatted }));
  };

  // CCCD change handler: also update username if useCccdAsUsername is true
  const handleCccdChange = (val: string) => {
    const onlyDigits = val.replace(/\D/g, '').slice(0, 12);
    setRegForm(prev => ({
      ...prev,
      cccd: onlyDigits,
      username: prev.useCccdAsUsername ? onlyDigits : prev.username
    }));
  };

  // Registration handler
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    // Validations
    if (!regForm.cccd || regForm.cccd.length !== 12) {
      setRegError('Số CCCD không hợp lệ: Phải gồm đúng 12 chữ số.');
      return;
    }

    if (!regForm.fullName.trim() || regForm.fullName.trim().length < 3) {
      setRegError('Vui lòng nhập đầy đủ họ và tên người khám bệnh.');
      return;
    }

    if (!regForm.phone || regForm.phone.length !== 10 || !regForm.phone.startsWith('0')) {
      setRegError('Số điện thoại không hợp lệ: Phải gồm đúng 10 chữ số và bắt đầu bằng số 0.');
      return;
    }

    if (regForm.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(regForm.email)) {
      setRegError('Định dạng email không hợp lệ.');
      return;
    }

    const usernameToUse = (regForm.useCccdAsUsername ? regForm.cccd : regForm.username).trim();
    if (!usernameToUse) {
      setRegError('Vui lòng nhập tên đăng nhập hoặc chọn sử dụng số CCCD làm tên đăng nhập.');
      return;
    }

    if (regForm.regPassword.length < 8) {
      setRegError('Mật khẩu phải có ít nhất 8 ký tự.');
      return;
    }

    if (!/[A-Z]/.test(regForm.regPassword) || !/[a-z]/.test(regForm.regPassword) || !/[0-9]/.test(regForm.regPassword)) {
      setRegError('Mật khẩu phải bao gồm ít nhất 1 chữ hoa, 1 chữ thường và 1 chữ số.');
      return;
    }

    if (regForm.regPassword !== regForm.confirmPassword) {
      setRegError('Mật khẩu xác nhận không khớp. Vui lòng kiểm tra lại.');
      return;
    }

    if (!regForm.accuracyConsent) {
      setRegError('Vui lòng tích cam kết tính chính xác của các thông tin đã khai báo.');
      return;
    }

    if (!regForm.privacyConsent) {
      setRegError('Vui lòng đồng ý với Điều khoản dịch vụ và Chính sách bảo mật dữ liệu y tế.');
      return;
    }

    setIsRegistering(true);

    try {
      const fullAddress = `${regForm.street ? regForm.street + ', ' : ''}${regForm.ward}, ${regForm.district}, ${regForm.province}`;
      
      let dobFormatted = '01/01/1990';
      let birthYear = 1990;
      if (regForm.dateOfBirth) {
        if (regForm.dateOfBirth.includes('-')) {
          const parts = regForm.dateOfBirth.split('-');
          if (parts.length === 3) {
            const y = parseInt(parts[0], 10);
            const m = parts[1].padStart(2, '0');
            const d = parts[2].padStart(2, '0');
            dobFormatted = `${d}/${m}/${y}`;
            birthYear = isNaN(y) ? 1990 : y;
          }
        } else if (regForm.dateOfBirth.includes('/')) {
          dobFormatted = regForm.dateOfBirth;
          const parts = regForm.dateOfBirth.split('/');
          if (parts.length === 3) {
            const y = parseInt(parts[2], 10);
            birthYear = isNaN(y) ? 1990 : y;
          }
        }
      }

      const payload: PatientRegisterPayload = {
        cccd: regForm.cccd,
        fullName: regForm.fullName.trim(),
        dateOfBirth: dobFormatted,
        birthYear,
        gender: regForm.gender,
        nationality: regForm.nationality,
        phone: regForm.phone,
        email: regForm.email.trim() || undefined,
        address: fullAddress,
        username: usernameToUse,
        password: regForm.regPassword,
        bhytCode: `DN448${regForm.cccd.slice(-7)}`
      };

      const res = registerPatientAccount(payload);

      if (!res.success) {
        setRegError(res.message);
      } else {
        setRegSuccessData({
          patientId: res.patientId || 'BN-NEW',
          username: res.username || usernameToUse,
          fullName: regForm.fullName.trim()
        });
      }
    } catch (err: any) {
      console.error('Registration error:', err);
      setRegError(err?.message || 'Có lỗi xảy ra trong quá trình đăng ký. Vui lòng thử lại.');
    } finally {
      setIsRegistering(false);
    }
  };

  // Immediate login after successful registration
  const handleLoginWithRegistered = () => {
    if (!regSuccessData) return;
    const res = login(regSuccessData.username, regForm.regPassword);
    if (!res.success) {
      setAuthMode('login');
      setLoginIdentifier(regSuccessData.username);
      setPassword(regForm.regPassword);
      setRegSuccessData(null);
    }
  };

  // Forgot password lookup handler
  const handleForgotLookup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotInput.trim()) return;
    const res = forgotPasswordLookup(forgotInput.trim());
    setForgotResult(res);
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex items-center justify-center p-3 sm:p-4 md:p-8 antialiased">
      <div className="max-w-6xl w-full bg-white rounded-2xl shadow-xl border border-slate-200/80 overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-[640px]">
        
        {/* Left Column: Hospital Brand & Key Guarantees */}
        <div className="lg:col-span-5 bg-[#163A5F] text-white p-6 sm:p-8 md:p-10 flex flex-col justify-between relative overflow-hidden">
          {/* Subtle geometric background accents */}
          <div className="absolute top-0 right-0 -mr-16 -mt-16 w-72 h-72 rounded-full bg-[#2878B5]/25 blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-72 h-72 rounded-full bg-[#16A6A1]/20 blur-3xl pointer-events-none" />

          <div className="relative z-10">
            {/* Header / Brand */}
            <div className="flex items-center gap-3.5 mb-7">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#16A6A1] to-[#2878B5] flex items-center justify-center shadow-lg font-bold text-white text-lg tracking-wider">
                ST
              </div>
              <div>
                <span className="text-[11px] font-semibold tracking-wider text-teal-300 uppercase block">
                  Bệnh viện Đa khoa Sơn Trà
                </span>
                <h1 className="text-lg font-bold tracking-tight text-white leading-tight">
                  SON TRA HOSPITAL
                </h1>
                <p className="text-[11px] text-slate-300">Hệ thống điều phối quy trình khám bệnh ngoại trú</p>
              </div>
            </div>

            {/* Sub-headline */}
            <div className="bg-white/10 rounded-xl p-4 border border-white/10 backdrop-blur-sm mb-6">
              <div className="flex items-center gap-2 text-teal-300 text-xs font-semibold uppercase tracking-wider mb-1.5">
                <Sparkles className="w-4 h-4 shrink-0" /> Nền tảng Y tế Thông minh & AI Orchestrator
              </div>
              <p className="text-xs text-slate-200 leading-relaxed">
                Tích hợp AI Triage phân luồng khoa khám, chuẩn hóa tiếp nhận, giám sát cận lâm sàng thời gian thực và quản lý đơn thuốc ngoại trú.
              </p>
            </div>

            {/* Key Advantages Checklist */}
            <div className="space-y-3 text-xs text-slate-200">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-300 shrink-0 mt-0.5" />
                <span><strong>Đăng ký hồ sơ bằng CCCD:</strong> Chuẩn hóa dữ liệu định danh công dân 12 số, loại bỏ trùng lặp hồ sơ bệnh án.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-300 shrink-0 mt-0.5" />
                <span><strong>Tự động điều phối phân quyền:</strong> Tự động nhận diện vai trò y tế, chặn đứng hành vi leo thang đặc quyền.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-300 shrink-0 mt-0.5" />
                <span><strong>Cổng Bệnh nhân Real-time:</strong> Khai triệu chứng với Chatbot AI, nhận số thứ tự, theo dõi hàng đợi và kết quả khám tức thời.</span>
              </div>
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-300 shrink-0 mt-0.5" />
                <span><strong>Bảo mật thông tin bệnh án:</strong> Mã hóa dữ liệu định danh, che số CCCD công khai và kiểm soát truy nhập chặt chẽ.</span>
              </div>
            </div>
          </div>

          {/* Simulation disclaimer note */}
          <div className="relative z-10 pt-5 mt-6 border-t border-white/10 text-[11px] text-slate-300 space-y-2">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Building2 className="w-3.5 h-3.5 text-teal-300" />
                Số 118 Ngô Quyền, P. An Hải Bắc, Q. Sơn Trà, TP. Đà Nẵng
              </span>
              <span className="font-mono text-slate-400">v2026.1</span>
            </div>
            <div className="p-2.5 bg-white/5 rounded-lg border border-white/10 text-[10px] text-slate-300 leading-relaxed">
              <span className="font-semibold text-teal-300">Lưu ý mô phỏng:</span> Hệ thống vận hành mô phỏng theo chuẩn HIS/EMR & AI Orchestrator, chưa kết nối trực tiếp CSDL Quốc gia về dân cư VNeID/C06 hoặc cổng SMS OTP viễn thông.
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic Authentication Switcher & Forms */}
        <div className="lg:col-span-7 p-6 sm:p-8 md:p-10 flex flex-col justify-between bg-white overflow-y-auto max-h-[85vh] lg:max-h-none">
          <div>
            {/* Top Switcher: Login vs Register */}
            <div className="flex items-center justify-between mb-6 border-b border-slate-200 pb-4">
              <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => { setAuthMode('login'); setLoginError(''); }}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    authMode === 'login'
                      ? 'bg-white text-[#163A5F] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5" /> Đăng nhập
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthMode('register'); setRegError(''); }}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    authMode === 'register'
                      ? 'bg-white text-[#2878B5] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5" /> Đăng ký bệnh nhân
                </button>
              </div>

              {authMode === 'login' && (
                <button
                  type="button"
                  onClick={() => setShowPasswordChangeModal(true)}
                  className="text-[11px] text-[#2878B5] hover:text-[#163A5F] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <KeyRound className="w-3.5 h-3.5" /> Đổi mật khẩu
                </button>
              )}
            </div>

            {/* ========================================================= */}
            {/* VIEW 1: LOGIN MODE                                        */}
            {/* ========================================================= */}
            {authMode === 'login' && (
              <div>
                <div className="mb-5">
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight">Đăng nhập hệ thống</h2>
                  <p className="text-xs text-slate-500 mt-1">
                    Nhập tên tài khoản hoặc số CCCD để mở phiên làm việc y tế tương ứng
                  </p>
                </div>

                {/* Error Banner */}
                {loginError && (
                  <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2.5 animate-in fade-in">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                    <span className="font-medium">{loginError}</span>
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                      Tên đăng nhập hoặc Số CCCD (12 chữ số)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <input
                        type="text"
                        required
                        value={loginIdentifier}
                        onChange={(e) => setLoginIdentifier(e.target.value)}
                        placeholder="VD: admin, tiepnhan01, bacsi01 hoặc 048090000001..."
                        className="w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5] focus:border-[#2878B5] transition-all font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="block text-xs font-semibold text-slate-700">
                        Mật khẩu xác thực
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="text-[11px] text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
                      >
                        {showPassword ? (
                          <>
                            <EyeOff className="w-3.5 h-3.5" /> Ẩn
                          </>
                        ) : (
                          <>
                            <Eye className="w-3.5 h-3.5" /> Hiện
                          </>
                        )}
                      </button>
                    </div>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Lock className="w-4 h-4" />
                      </div>
                      <input
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Nhập mật khẩu..."
                        className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5] focus:border-[#2878B5] transition-all font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-slate-300 text-[#2878B5] focus:ring-[#2878B5]"
                      />
                      <span className="text-xs text-slate-600">Ghi nhớ đăng nhập trên thiết bị</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => { setShowForgotModal(true); setForgotResult(null); setForgotInput(''); }}
                      className="text-xs text-[#2878B5] hover:underline font-semibold cursor-pointer"
                    >
                      Quên mật khẩu?
                    </button>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoggingIn}
                    className="w-full py-2.5 bg-[#163A5F] hover:bg-[#12304A] text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 mt-2"
                  >
                    {isLoggingIn ? (
                      <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <LogIn className="w-4 h-4" />
                    )}
                    <span>Đăng nhập & Mở phiên làm việc</span>
                  </button>

                  <div className="pt-2 text-center">
                    <p className="text-xs text-slate-500">
                      Chưa có tài khoản bệnh nhân?{' '}
                      <button
                        type="button"
                        onClick={() => { setAuthMode('register'); setRegError(''); }}
                        className="text-[#2878B5] font-bold hover:underline cursor-pointer"
                      >
                        Đăng ký tài khoản ngay
                      </button>
                    </p>
                  </div>
                </form>

                {/* Quick Demo Credentials Panel */}
                <div className="mt-6 pt-5 border-t border-slate-100">
                  <div className="flex items-center justify-between mb-2.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-[#2878B5]" />
                      Tài khoản mẫu theo vai trò y tế:
                    </span>
                    <span className="text-[10px] text-slate-400">Bấm để điền nhanh</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {DEMO_CREDENTIALS.map((demo) => {
                      const isActive = loginIdentifier === demo.username || (demo.cccd && loginIdentifier === demo.cccd);
                      return (
                        <button
                          key={demo.username}
                          type="button"
                          onClick={() => handleFillDemo(demo)}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                            isActive
                              ? 'border-[#2878B5] bg-blue-50/60 shadow-xs ring-1 ring-[#2878B5]'
                              : 'border-slate-200 bg-slate-50/60 hover:bg-white hover:border-slate-300'
                          }`}
                        >
                          <div className="flex items-center gap-1.5 mb-1">
                            {getRoleIcon(demo.role)}
                            <span className="font-semibold text-xs text-slate-800 truncate">
                              {demo.label}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between">
                            <span className="text-slate-700 font-medium truncate">{demo.username}</span>
                            <span className="text-slate-400 truncate max-w-[65px]">{demo.password}</span>
                          </div>
                          {demo.cccd && (
                            <div className="text-[9px] text-[#2878B5] mt-1 font-mono">
                              CCCD: {demo.cccd}
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* ========================================================= */}
            {/* VIEW 2: PATIENT REGISTRATION MODE (4 GROUPS)              */}
            {/* ========================================================= */}
            {authMode === 'register' && (
              <div>
                <div className="mb-5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-teal-50 text-[#16A6A1] text-[10px] font-bold uppercase tracking-wider border border-teal-200">
                      Cổng Bệnh nhân
                    </span>
                    <span className="text-xs text-slate-400">· Tạo hồ sơ y tế điện tử</span>
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 tracking-tight mt-1">Đăng ký tài khoản bệnh nhân</h2>
                  <p className="text-xs text-slate-500">
                    Vui lòng điền thông tin định danh chính xác để liên kết hồ sơ khám ngoại trú
                  </p>
                </div>

                {/* Error Banner */}
                {regError && (
                  <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2.5 animate-in fade-in">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
                    <span className="font-medium">{regError}</span>
                  </div>
                )}

                <form onSubmit={handleRegisterSubmit} className="space-y-6">
                  {/* GROUP 1: THÔNG TIN ĐỊNH DANH */}
                  <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#163A5F] uppercase tracking-wider border-b border-slate-200 pb-2">
                      <CreditCard className="w-4 h-4 text-[#2878B5]" />
                      <span>Nhóm 1: Thông tin định danh</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Số CCCD (12 chữ số) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={12}
                          value={regForm.cccd}
                          onChange={(e) => handleCccdChange(e.target.value)}
                          placeholder="VD: 048099001234"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          Đã nhập: {regForm.cccd.length}/12 số
                        </span>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Họ và tên đầy đủ <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          value={regForm.fullName}
                          onChange={(e) => handleFullNameChange(e.target.value)}
                          placeholder="VD: Nguyễn Văn An"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          Tự động chuẩn hóa chữ hoa đầu từ
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Ngày sinh <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="date"
                          required
                          value={regForm.dateOfBirth}
                          onChange={(e) => setRegForm({ ...regForm, dateOfBirth: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        {calculatedAge !== null && (
                          <span className="text-[10px] text-teal-600 font-medium mt-0.5 block">
                            Tuổi: {calculatedAge} tuổi
                          </span>
                        )}
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Giới tính <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={regForm.gender}
                          onChange={(e) => setRegForm({ ...regForm, gender: e.target.value as any })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        >
                          <option value="Nam">Nam</option>
                          <option value="Nữ">Nữ</option>
                          <option value="Khác">Khác</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Quốc tịch
                        </label>
                        <input
                          type="text"
                          value={regForm.nationality}
                          onChange={(e) => setRegForm({ ...regForm, nationality: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                      </div>
                    </div>
                  </div>

                  {/* GROUP 2: THÔNG TIN LIÊN HỆ */}
                  <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#163A5F] uppercase tracking-wider border-b border-slate-200 pb-2">
                      <Phone className="w-4 h-4 text-[#2878B5]" />
                      <span>Nhóm 2: Thông tin liên hệ</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Số điện thoại (10 chữ số) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          maxLength={10}
                          value={regForm.phone}
                          onChange={(e) => setRegForm({ ...regForm, phone: e.target.value.replace(/\D/g, '').slice(0, 10) })}
                          placeholder="VD: 0905123456"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          Bắt đầu bằng số 0 (Định dạng di động VN)
                        </span>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-700 mb-1">
                          Email (Không bắt buộc)
                        </label>
                        <input
                          type="email"
                          value={regForm.email}
                          onChange={(e) => setRegForm({ ...regForm, email: e.target.value })}
                          placeholder="VD: benhnhan@gmail.com"
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          Dùng để nhận hóa đơn điện tử & kết quả
                        </span>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">
                        Địa chỉ thường trú / Nơi ở hiện tại
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2">
                        <input
                          type="text"
                          value={regForm.province}
                          onChange={(e) => setRegForm({ ...regForm, province: e.target.value })}
                          placeholder="Tỉnh/Thành phố..."
                          className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <input
                          type="text"
                          value={regForm.district}
                          onChange={(e) => setRegForm({ ...regForm, district: e.target.value })}
                          placeholder="Quận/Huyện..."
                          className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                        <input
                          type="text"
                          value={regForm.ward}
                          onChange={(e) => setRegForm({ ...regForm, ward: e.target.value })}
                          placeholder="Phường/Xã..."
                          className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                      </div>
                      <input
                        type="text"
                        value={regForm.street}
                        onChange={(e) => setRegForm({ ...regForm, street: e.target.value })}
                        placeholder="Số nhà, tên đường, tổ dân phố (Ví dụ: K120/15 Ngô Quyền)..."
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                      />
                    </div>
                  </div>

                  {/* GROUP 3: TÀI KHOẢN & BẢO MẬT */}
                  <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#163A5F] uppercase tracking-wider border-b border-slate-200 pb-2">
                      <Lock className="w-4 h-4 text-[#2878B5]" />
                      <span>Nhóm 3: Tài khoản & Bảo mật</span>
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-semibold text-slate-700">
                          Tên đăng nhập <span className="text-rose-500">*</span>
                        </label>
                        <label className="flex items-center gap-1.5 text-[11px] text-[#2878B5] cursor-pointer">
                          <input
                            type="checkbox"
                            checked={regForm.useCccdAsUsername}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              setRegForm(prev => ({
                                ...prev,
                                useCccdAsUsername: checked,
                                username: checked ? prev.cccd : prev.username
                              }));
                            }}
                            className="w-3.5 h-3.5 rounded text-[#2878B5]"
                          />
                          Sử dụng chính số CCCD làm tên đăng nhập
                        </label>
                      </div>
                      <input
                        type="text"
                        required
                        disabled={regForm.useCccdAsUsername}
                        value={regForm.useCccdAsUsername ? regForm.cccd : regForm.username}
                        onChange={(e) => setRegForm({ ...regForm, username: e.target.value.toLowerCase().replace(/\s/g, '') })}
                        placeholder={regForm.useCccdAsUsername ? 'Đang dùng số CCCD' : 'Nhập tên đăng nhập tùy chọn (VD: annguyen95)...'}
                        className={`w-full px-3 py-2 border rounded-lg text-xs font-mono ${
                          regForm.useCccdAsUsername
                            ? 'bg-slate-100 text-slate-500 border-slate-200'
                            : 'bg-white text-slate-900 border-slate-200 focus:ring-2 focus:ring-[#2878B5]'
                        }`}
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-semibold text-slate-700">
                            Mật khẩu <span className="text-rose-500">*</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => setShowRegPassword(!showRegPassword)}
                            className="text-[10px] text-slate-400 hover:text-slate-600"
                          >
                            {showRegPassword ? 'Ẩn' : 'Hiện'}
                          </button>
                        </div>
                        <input
                          type={showRegPassword ? 'text' : 'password'}
                          required
                          value={regForm.regPassword}
                          onChange={(e) => setRegForm({ ...regForm, regPassword: e.target.value })}
                          placeholder="Tối thiểu 8 ký tự (Hoa, thường, số)..."
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-semibold text-slate-700">
                            Xác nhận mật khẩu <span className="text-rose-500">*</span>
                          </label>
                          <button
                            type="button"
                            onClick={() => setShowRegConfirmPassword(!showRegConfirmPassword)}
                            className="text-[10px] text-slate-400 hover:text-slate-600"
                          >
                            {showRegConfirmPassword ? 'Ẩn' : 'Hiện'}
                          </button>
                        </div>
                        <input
                          type={showRegConfirmPassword ? 'text' : 'password'}
                          required
                          value={regForm.confirmPassword}
                          onChange={(e) => setRegForm({ ...regForm, confirmPassword: e.target.value })}
                          placeholder="Nhập lại mật khẩu..."
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                        />
                      </div>
                    </div>

                    {/* Password Strength Meter */}
                    <div className="p-3 bg-white rounded-lg border border-slate-200 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 font-medium">Độ mạnh mật khẩu:</span>
                        <span className={`font-bold ${passwordStrength.text}`}>
                          {passwordStrength.label}
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden flex gap-1">
                        <div className={`h-full flex-1 transition-all ${regForm.regPassword.length >= 8 ? passwordStrength.color : 'bg-slate-200'}`} />
                        <div className={`h-full flex-1 transition-all ${passwordStrength.score >= 2 ? passwordStrength.color : 'bg-slate-200'}`} />
                        <div className={`h-full flex-1 transition-all ${passwordStrength.score >= 3 ? passwordStrength.color : 'bg-slate-200'}`} />
                      </div>
                      <div className="grid grid-cols-3 gap-1 pt-1 text-[10px] text-slate-500">
                        <span className={`flex items-center gap-1 ${regForm.regPassword.length >= 8 ? 'text-emerald-600 font-medium' : ''}`}>
                          {regForm.regPassword.length >= 8 ? <Check className="w-3 h-3" /> : '○'} $\ge$ 8 ký tự
                        </span>
                        <span className={`flex items-center gap-1 ${/[A-Z]/.test(regForm.regPassword) && /[a-z]/.test(regForm.regPassword) ? 'text-emerald-600 font-medium' : ''}`}>
                          {/[A-Z]/.test(regForm.regPassword) && /[a-z]/.test(regForm.regPassword) ? <Check className="w-3 h-3" /> : '○'} Chữ hoa & thường
                        </span>
                        <span className={`flex items-center gap-1 ${/[0-9]/.test(regForm.regPassword) ? 'text-emerald-600 font-medium' : ''}`}>
                          {/[0-9]/.test(regForm.regPassword) ? <Check className="w-3 h-3" /> : '○'} Có chữ số
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* GROUP 4: XÁC NHẬN VÀ CAM KẾT */}
                  <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 space-y-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-[#163A5F] uppercase tracking-wider border-b border-slate-200 pb-2">
                      <FileCheck className="w-4 h-4 text-[#2878B5]" />
                      <span>Nhóm 4: Xác nhận và cam kết</span>
                    </div>

                    <div className="space-y-2">
                      <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-700 select-none">
                        <input
                          type="checkbox"
                          required
                          checked={regForm.accuracyConsent}
                          onChange={(e) => setRegForm({ ...regForm, accuracyConsent: e.target.checked })}
                          className="w-4 h-4 mt-0.5 rounded border-slate-300 text-[#2878B5] focus:ring-[#2878B5]"
                        />
                        <span>
                          Tôi cam đoan các thông tin định danh (CCCD), ngày sinh và số điện thoại khai báo trên là hoàn toàn chính xác và chịu trách nhiệm trước pháp luật.
                        </span>
                      </label>

                      <label className="flex items-start gap-2.5 cursor-pointer text-xs text-slate-700 select-none">
                        <input
                          type="checkbox"
                          required
                          checked={regForm.privacyConsent}
                          onChange={(e) => setRegForm({ ...regForm, privacyConsent: e.target.checked })}
                          className="w-4 h-4 mt-0.5 rounded border-slate-300 text-[#2878B5] focus:ring-[#2878B5]"
                        />
                        <span>
                          Tôi đồng ý với Quy định dịch vụ y tế và Chính sách bảo mật dữ liệu sức khỏe của Bệnh viện Đa khoa Sơn Trà.
                        </span>
                      </label>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => setAuthMode('login')}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer transition-colors"
                    >
                      ← Quay lại Đăng nhập
                    </button>

                    <button
                      type="submit"
                      disabled={isRegistering}
                      className="flex-1 py-2.5 bg-[#2878B5] hover:bg-[#163A5F] text-white font-semibold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
                    >
                      {isRegistering ? (
                        <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <UserPlus className="w-4 h-4" />
                      )}
                      <span>Hoàn tất đăng ký tài khoản bệnh nhân</span>
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>

          <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
            <span>© 2026 Bệnh viện Đa khoa Sơn Trà. Bảo lưu mọi quyền.</span>
            <span className="flex items-center gap-1 text-emerald-600 font-medium">
              <ShieldCheck className="w-3.5 h-3.5" /> Hệ thống bảo mật ISO/IEC 27001
            </span>
          </div>
        </div>
      </div>

      {/* MODAL: REGISTRATION SUCCESS */}
      {regSuccessData && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-4">
              <CheckCircle2 className="w-7 h-7" />
            </div>

            <div className="text-center mb-5">
              <h3 className="font-bold text-base text-slate-900">Đăng ký tài khoản thành công!</h3>
              <p className="text-xs text-slate-500 mt-1">
                Hồ sơ y tế điện tử của quý khách đã được tạo và đồng bộ với Cổng Bệnh nhân
              </p>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80 space-y-2 mb-5 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500">Mã bệnh nhân:</span>
                <span className="font-mono font-bold text-[#2878B5] text-sm">{regSuccessData.patientId}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500">Họ và tên:</span>
                <span className="font-bold text-slate-800">{regSuccessData.fullName}</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-200">
                <span className="text-slate-500">Tên đăng nhập:</span>
                <span className="font-mono font-medium text-slate-800">{regSuccessData.username}</span>
              </div>
              <div className="flex justify-between items-center py-1">
                <span className="text-slate-500">Quyền truy cập:</span>
                <span className="font-semibold text-emerald-600">Bệnh nhân (Patient Portal)</span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={handleLoginWithRegistered}
                className="w-full py-2.5 bg-[#163A5F] hover:bg-[#12304A] text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" /> Đăng nhập ngay vào Cổng Bệnh nhân
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setLoginIdentifier(regSuccessData.username);
                  setPassword(regForm.regPassword);
                  setRegSuccessData(null);
                }}
                className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                Chuyển về màn hình Đăng nhập
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: FORGOT PASSWORD */}
      {showForgotModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2878B5] flex items-center justify-center font-bold">
                  <HelpCircle className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Quên mật khẩu tài khoản</h3>
                  <p className="text-[11px] text-slate-500">Hỗ trợ tra cứu và cấp lại mật khẩu tạm thời</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {forgotResult && (
              <div className={`p-3 rounded-xl text-xs mb-4 flex items-start gap-2.5 ${
                forgotResult.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
              }`}>
                {forgotResult.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />}
                <div className="space-y-1">
                  <p className="leading-relaxed">{forgotResult.message}</p>
                  {forgotResult.tempPw && (
                    <div className="mt-2 pt-2 border-t border-emerald-200 flex items-center justify-between font-mono font-bold text-xs">
                      <span>Mật khẩu mới:</span>
                      <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded">{forgotResult.tempPw}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <form onSubmit={handleForgotLookup} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Nhập số CCCD, Tên đăng nhập hoặc Số điện thoại
                </label>
                <input
                  type="text"
                  required
                  value={forgotInput}
                  onChange={(e) => setForgotInput(e.target.value)}
                  placeholder="VD: 048090000001 hoặc 0905000001..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowForgotModal(false)}
                  className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
                >
                  Tra cứu & Cấp lại
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: CHANGE PASSWORD */}
      {showPasswordChangeModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2878B5] flex items-center justify-center font-bold">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Đổi mật khẩu tài khoản</h3>
                  <p className="text-[11px] text-slate-500">Cập nhật mật khẩu để bảo vệ tài khoản y tế</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => { setShowPasswordChangeModal(false); setChangeMsg(null); }}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-md text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {changeMsg && (
              <div className={`p-2.5 rounded-lg text-xs mb-3 flex items-center gap-2 ${
                changeMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
              }`}>
                {changeMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{changeMsg.text}</span>
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mật khẩu hiện tại</label>
                <input
                  type="password"
                  value={changeForm.oldPw}
                  onChange={(e) => setChangeForm({ ...changeForm, oldPw: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                  placeholder="Nhập mật khẩu hiện tại..."
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mật khẩu mới (tối thiểu 6 ký tự)</label>
                <input
                  type="password"
                  value={changeForm.newPw}
                  onChange={(e) => setChangeForm({ ...changeForm, newPw: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                  placeholder="Nhập mật khẩu mới..."
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Xác nhận mật khẩu mới</label>
                <input
                  type="password"
                  value={changeForm.confirmPw}
                  onChange={(e) => setChangeForm({ ...changeForm, confirmPw: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                  placeholder="Nhập lại mật khẩu mới..."
                />
              </div>
            </div>

            <div className="mt-5 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => { setShowPasswordChangeModal(false); setChangeMsg(null); }}
                className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={() => {
                  if (!changeForm.oldPw || !changeForm.newPw) {
                    setChangeMsg({ text: 'Vui lòng nhập đầy đủ các thông tin.', type: 'error' });
                    return;
                  }
                  if (changeForm.newPw.length < 6) {
                    setChangeMsg({ text: 'Mật khẩu mới phải có tối thiểu 6 ký tự.', type: 'error' });
                    return;
                  }
                  if (changeForm.newPw !== changeForm.confirmPw) {
                    setChangeMsg({ text: 'Mật khẩu xác nhận không khớp.', type: 'error' });
                    return;
                  }
                  const res = changePassword(changeForm.oldPw, changeForm.newPw);
                  if (!res.success) {
                    setChangeMsg({ text: res.message, type: 'error' });
                  } else {
                    setChangeMsg({ text: 'Đổi mật khẩu thành công! Bạn có thể sử dụng mật khẩu mới.', type: 'success' });
                    setTimeout(() => {
                      setShowPasswordChangeModal(false);
                      setChangeMsg(null);
                    }, 1200);
                  }
                }}
                className="px-4 py-2 rounded-lg bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
              >
                Lưu mật khẩu mới
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
