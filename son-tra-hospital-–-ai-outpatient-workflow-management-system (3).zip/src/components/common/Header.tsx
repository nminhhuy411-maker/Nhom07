import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { DEFAULT_ACCOUNTS } from '../../data/initialData';
import { 
  Building2, 
  Bell, 
  Clock, 
  Search, 
  UserCheck, 
  History, 
  FileText, 
  ChevronDown, 
  LogOut,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  User
} from 'lucide-react';

interface HeaderProps {
  onOpenNotifications: () => void;
  onOpenAuditLogs: () => void;
  onOpenUseCaseMatrix: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenNotifications,
  onOpenAuditLogs,
  onOpenUseCaseMatrix,
}) => {
  const { 
    activeAccount, 
    switchAccount, 
    accounts,
    patients, 
    activePatientId, 
    setActivePatientId, 
    notifications, 
    config, 
    adjustSimulatedClock, 
    getSimulatedCurrentTime,
    logout
  } = useHospital();

  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);
  const [patientSearch, setPatientSearch] = useState('');
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  const currentTime = getSimulatedCurrentTime();
  const timeFormatted = currentTime.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const dateFormatted = currentTime.toLocaleDateString('vi-VN');

  const unreadCount = notifications.filter(
    n => !n.isRead && (n.targetRole === activeAccount.role || n.targetRole === 'all')
  ).length;

  const filteredPatients = patients.filter(p => 
    p.fullName.toLowerCase().includes(patientSearch.toLowerCase()) ||
    p.cccd.includes(patientSearch) ||
    p.phone.includes(patientSearch) ||
    p.id.toLowerCase().includes(patientSearch.toLowerCase())
  ).slice(0, 5);

  const activePatient = patients.find(p => p.id === activePatientId);

  const getRoleAbbr = (role: string) => {
    switch (role) {
      case 'doctor': return 'BS';
      case 'reception': return 'TN';
      case 'paraclinical': return 'CLS';
      case 'cashier': return 'TC';
      case 'pharmacy': return 'DS';
      case 'admin': return 'QT';
      default: return 'BN';
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200/80 px-4 lg:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs">
      {/* Zone 1: Hospital Brand & Current Patient Context */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#163A5F] flex items-center justify-center text-white shadow-xs font-bold text-base tracking-wide">
            ST
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-[#163A5F] tracking-tight text-sm uppercase leading-none">
                BỆNH VIỆN ĐA KHOA SƠN TRÀ
              </h1>
              <span className="text-[10px] bg-teal-50 text-[#16A6A1] font-semibold px-2 py-0.5 rounded-full border border-teal-200">
                Điều phối AI
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-normal mt-0.5">
              Hệ thống quản lý quy trình khám bệnh ngoại trú
            </p>
          </div>
        </div>

        {/* Active Patient Context Card */}
        {activePatient && (
          <div className="hidden xl:flex items-center gap-2.5 px-3 py-1.5 bg-slate-50 border border-slate-200/80 rounded-xl text-xs">
            <span className="text-slate-400">Bệnh nhân:</span>
            <span className="font-semibold text-slate-800">{activePatient.fullName}</span>
            <span className="text-slate-500 font-mono text-[11px]">
              ({activePatient.id} · BHYT: {Math.round(activePatient.bhytRate * 100)}%)
            </span>
          </div>
        )}
      </div>

      {/* Zone 2: Patient Search & Simulated Clock */}
      <div className="flex items-center gap-3">
        {/* Patient Quick Finder (Hidden for Patient role) */}
        {activeAccount.role !== 'patient' ? (
          <div className="relative hidden md:block w-64 lg:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm bệnh nhân (CCCD / SĐT / Tên)..."
              value={patientSearch}
              onChange={e => {
                setPatientSearch(e.target.value);
                setShowSearchDropdown(true);
              }}
              onFocus={() => setShowSearchDropdown(true)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 focus:border-[#2878B5] rounded-xl text-xs transition-colors focus:outline-hidden focus:bg-white"
            />
            {showSearchDropdown && patientSearch && (
              <div className="absolute left-0 top-full mt-1.5 w-full bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden divide-y divide-slate-100">
                {filteredPatients.length === 0 ? (
                  <div className="p-3 text-xs text-slate-400 text-center">Không tìm thấy bệnh nhân</div>
                ) : (
                  filteredPatients.map(p => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setActivePatientId(p.id);
                        setShowSearchDropdown(false);
                        setPatientSearch('');
                      }}
                      className="w-full text-left p-2.5 hover:bg-blue-50/70 transition-colors flex items-center justify-between text-xs cursor-pointer"
                    >
                      <div>
                        <p className="font-semibold text-slate-800">{p.fullName}</p>
                        <p className="text-[11px] text-slate-500 font-mono">CCCD: {p.cccd} · SĐT: {p.phone}</p>
                      </div>
                      <span className="text-[10px] font-mono font-medium bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                        {p.id}
                      </span>
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 border border-blue-200 rounded-xl text-xs text-blue-800 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Hồ sơ y tế bảo mật cá nhân</span>
          </div>
        )}

        {/* Simulated Clock Widget with quick advance */}
        <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
          <Clock className="w-3.5 h-3.5 text-[#2878B5]" />
          <div className="flex flex-col">
            <span className="font-mono font-bold text-slate-900 leading-none tabular-nums text-xs">
              {timeFormatted}
            </span>
            <span className="text-[10px] text-slate-500 font-mono leading-none mt-0.5">
              {dateFormatted} {config.simulatedClockOffsetMinutes ? `(+${config.simulatedClockOffsetMinutes}p)` : ''}
            </span>
          </div>

          {/* Quick warp controls */}
          <div className="flex items-center gap-1 ml-1 pl-2 border-l border-slate-200">
            <button
              onClick={() => adjustSimulatedClock(15)}
              title="Tua nhanh +15 phút"
              className="px-1.5 py-0.5 bg-white hover:bg-blue-50 text-[10px] font-mono font-semibold text-slate-700 hover:text-blue-700 rounded-md border border-slate-200 transition-colors cursor-pointer"
            >
              +15p
            </button>
            <button
              onClick={() => adjustSimulatedClock(480)}
              title="Tua nhanh +8 giờ (kiểm tra cận lâm sàng quá hạn)"
              className="px-1.5 py-0.5 bg-white hover:bg-amber-50 text-[10px] font-mono font-semibold text-amber-700 rounded-md border border-slate-200 transition-colors cursor-pointer"
            >
              +8h
            </button>
            {config.simulatedClockOffsetMinutes !== 0 && (
              <button
                onClick={() => adjustSimulatedClock(-config.simulatedClockOffsetMinutes)}
                title="Khôi phục giờ thực tế"
                className="p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Zone 3: System Utilities & Active Profile */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Workflow Matrix */}
        <button
          onClick={onOpenUseCaseMatrix}
          title="Xem sơ đồ đối chiếu quy trình nghiệp vụ"
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-xl border border-slate-200 transition-colors cursor-pointer"
        >
          <FileText className="w-3.5 h-3.5 text-[#2878B5]" />
          <span>Sơ đồ quy trình</span>
        </button>

        {/* Audit Log */}
        <button
          onClick={onOpenAuditLogs}
          title="Xem nhật ký giám sát hoạt động điều phối"
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium rounded-xl border border-slate-200 transition-colors cursor-pointer"
        >
          <History className="w-3.5 h-3.5 text-slate-500" />
          <span>Nhật ký</span>
        </button>

        {/* Notification Bell */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          title="Thông báo hệ thống"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {/* User Account / Role Menu */}
        <div className="relative">
          <button
            onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
            className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-xl border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 transition-colors text-left cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#2878B5] font-bold flex items-center justify-center text-xs">
              {getRoleAbbr(activeAccount.role)}
            </div>
            <div className="hidden md:block">
              <p className="text-xs font-bold text-slate-800 leading-tight truncate max-w-[130px]">
                {activeAccount.name}
              </p>
              <p className="text-[10px] text-slate-500 leading-tight">
                {activeAccount.title}
              </p>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {isRoleDropdownOpen && (
            <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 p-2 divide-y divide-slate-100">
              <div className="px-3 py-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  Đang đăng nhập:
                </span>
                <p className="text-xs font-bold text-[#163A5F]">{activeAccount.name}</p>
                <p className="text-[11px] text-slate-500">{activeAccount.department || activeAccount.title}</p>
              </div>

              {/* Quick switch between available accounts */}
              <div className="py-1.5 space-y-0.5 max-h-48 overflow-y-auto">
                <span className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase block">
                  Chuyển nhanh tài khoản:
                </span>
                {(accounts || DEFAULT_ACCOUNTS).map(acc => (
                  <button
                    key={acc.id}
                    onClick={() => {
                      switchAccount(acc);
                      setIsRoleDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors cursor-pointer ${
                      activeAccount.id === acc.id ? 'bg-blue-50 text-[#2878B5] font-bold' : 'text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div>
                      <p className="font-semibold leading-tight">{acc.name}</p>
                      <p className="text-[10px] text-slate-400 leading-tight mt-0.5">{acc.title} {acc.cccd ? `(${acc.cccd.slice(0, 6)}******)` : ''}</p>
                    </div>
                    {activeAccount.id === acc.id && (
                      <span className="w-2 h-2 rounded-full bg-[#2878B5]" />
                    )}
                  </button>
                ))}
              </div>

              {/* Logout Action */}
              <div className="pt-2">
                <button
                  onClick={() => {
                    setIsRoleDropdownOpen(false);
                    logout();
                  }}
                  className="w-full text-left px-3 py-2 rounded-xl text-xs text-red-600 hover:bg-red-50 font-semibold flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <LogOut className="w-3.5 h-3.5" /> Đăng xuất khỏi hệ thống
                  </span>
                  <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">
                    Kết thúc phiên
                  </span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
