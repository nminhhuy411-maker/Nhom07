import React, { useState, useEffect } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { STANDARD_PRICE_LIST } from '../../data/initialData';
import { WorkflowProgressTracker } from '../common/WorkflowProgressTracker';
import { LabServiceType, Visit, Patient, ClinicalOrder } from '../../types';
import { 
  Stethoscope, 
  User, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  FilePlus2, 
  Send, 
  ChevronRight, 
  FlaskConical, 
  X, 
  UserX, 
  PhoneCall,
  Sparkles,
  ClipboardList,
  AlertTriangle,
  ArrowRight,
  Receipt,
  Pill,
  Loader2,
  Zap
} from 'lucide-react';

export const DoctorModule: React.FC = () => {
  const { 
    visits, 
    patients, 
    symptomRecords, 
    labOrders, 
    queueItems, 
    callNextPatient, 
    confirmPatientPresent, 
    markPatientMissed, 
    saveClinicalNotes, 
    createLabOrders, 
    completeDiagnosis,
    quickCompleteLabOrder,
    activeAccount 
  } = useHospital();

  const [activeDept, setActiveDept] = useState('Tiêu hóa');
  const [selectedVisitId, setSelectedVisitId] = useState<string | null>(null);

  // Clinical Consultation Form
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [selectedServices, setSelectedServices] = useState<{ type: LabServiceType; name: string; room: string; price: number }[]>([]);
  const [diagnosisText, setDiagnosisText] = useState('');
  const [prescriptionText, setPrescriptionText] = useState('');
  const [needFollowUp, setNeedFollowUp] = useState(false);
  const [followUpDate, setFollowUpDate] = useState('15/11/2026');
  const [actionError, setActionError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [toastNotification, setToastNotification] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);
  const [conclusionSuccessModal, setConclusionSuccessModal] = useState<{
    patientName: string;
    patientId: string;
    visitId: string;
    diagnosis: string;
    prescription: string;
    message: string;
  } | null>(null);

  // Auto-dismiss toast
  useEffect(() => {
    if (toastNotification) {
      const timer = setTimeout(() => setToastNotification(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [toastNotification]);

  // Call timer simulation (3 minutes countdown)
  const [callTimerSeconds, setCallTimerSeconds] = useState<number | null>(null);

  // Available services for ordering
  const availableServices = [
    { type: 'lab_test' as LabServiceType, name: STANDARD_PRICE_LIST.bloodTest.name, room: 'Phòng Xét nghiệm Huyết học & Sinh hóa - Tầng 2', price: STANDARD_PRICE_LIST.bloodTest.price },
    { type: 'xray' as LabServiceType, name: STANDARD_PRICE_LIST.xray.name, room: 'Phòng Chụp X-Quang KTS 01 - Khu CĐHA', price: STANDARD_PRICE_LIST.xray.price },
    { type: 'ultrasound' as LabServiceType, name: STANDARD_PRICE_LIST.ultrasound.name, room: 'Phòng Siêu âm 02 - Tầng 1', price: STANDARD_PRICE_LIST.ultrasound.price },
    { type: 'ultrasound' as LabServiceType, name: STANDARD_PRICE_LIST.cardiacEcho.name, room: 'Phòng Siêu âm Tim Doppler - Tầng 2', price: STANDARD_PRICE_LIST.cardiacEcho.price },
  ];

  // Current room title
  const currentRoom = activeDept === 'Tiêu hóa' ? 'Phòng 103 - Nội Tiêu hóa' :
                      activeDept === 'Tim mạch' ? 'Phòng 201 - Nội Tim mạch' :
                      activeDept === 'Hô hấp' ? 'Phòng 102 - Nội Hô hấp' : 'Phòng 101 - Khám Tổng quát';

  // Queue in this department
  const deptQueue = queueItems.filter(q => q.department === activeDept);
  const waitingPatients = deptQueue.filter(q => q.status === 'waiting');
  const callingPatient = deptQueue.find(q => q.status === 'calling');
  const inConsultationPatient = deptQueue.find(q => q.status === 'in_consultation');

  // Currently active visit being examined
  const currentActiveVisit = inConsultationPatient ? visits.find(v => v.id === inConsultationPatient.visitId) : (selectedVisitId ? visits.find(v => v.id === selectedVisitId) : null);
  const currentPatient = currentActiveVisit ? patients.find(p => p.id === currentActiveVisit.patientId) : null;
  const currentSymptoms = currentActiveVisit ? symptomRecords.find(s => s.visitId === currentActiveVisit.id) : null;
  const currentOrders = currentActiveVisit ? labOrders.filter(o => o.visitId === currentActiveVisit.id) : [];

  // Sync notes when visit changes
  useEffect(() => {
    if (currentActiveVisit) {
      setClinicalNotes(currentActiveVisit.clinicalNotes || '');
      setDiagnosisText(currentActiveVisit.finalDiagnosis || '');
      setPrescriptionText(currentActiveVisit.prescriptionNotes || '');
    }
  }, [currentActiveVisit?.id]);

  // Call timer countdown
  useEffect(() => {
    let interval: any;
    if (callingPatient) {
      if (callTimerSeconds === null) setCallTimerSeconds(180); // 3 minutes
      interval = setInterval(() => {
        setCallTimerSeconds(prev => {
          if (prev !== null && prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev !== null ? prev - 1 : null;
        });
      }, 1000);
    } else {
      setCallTimerSeconds(null);
    }
    return () => clearInterval(interval);
  }, [callingPatient?.id]);

  const handleCallNext = () => {
    setActionError('');
    const called = callNextPatient(activeDept, currentRoom);
    if (!called) {
      setToastNotification({
        type: 'info',
        text: `Hiện không có bệnh nhân nào đang chờ trong hàng đợi khoa ${activeDept}.`
      });
    } else {
      setCallTimerSeconds(180);
    }
  };

  const handleConfirmPresent = () => {
    if (!callingPatient) return;
    confirmPatientPresent(callingPatient.visitId);
    setSelectedVisitId(callingPatient.visitId);
  };

  const handleMarkMissed = () => {
    if (!callingPatient) return;
    markPatientMissed(callingPatient.visitId);
  };

  const handleToggleService = (svc: typeof availableServices[0]) => {
    if (selectedServices.some(s => s.name === svc.name)) {
      setSelectedServices(selectedServices.filter(s => s.name !== svc.name));
    } else {
      setSelectedServices([...selectedServices, svc]);
    }
  };

  const handleSendLabOrders = () => {
    if (!currentActiveVisit) return;
    if (selectedServices.length === 0) {
      setActionError('Vui lòng chọn ít nhất 01 dịch vụ cận lâm sàng để tạo phiếu chỉ định (Inclusive Gateway).');
      return;
    }
    // Save clinical notes first
    saveClinicalNotes(currentActiveVisit.id, clinicalNotes);
    createLabOrders(currentActiveVisit.id, selectedServices);
    const count = selectedServices.length;
    setSelectedServices([]);
    setToastNotification({
      type: 'success',
      text: `Đã gửi thành công ${count} chỉ định điện tử đến Bộ phận Cận lâm sàng.`
    });
  };

  const handleCompleteDiagnosis = () => {
    setActionError('');
    if (!currentActiveVisit) {
      setActionError('Không tìm thấy ca khám đang hoạt động để kết luận.');
      return;
    }
    if (!diagnosisText.trim()) {
      setActionError('Vui lòng nhập chẩn đoán xác định bệnh (ICD-10) trước khi kết luận.');
      return;
    }

    setIsSubmitting(true);
    try {
      saveClinicalNotes(currentActiveVisit.id, clinicalNotes);
      const result = completeDiagnosis(
        currentActiveVisit.id, 
        diagnosisText, 
        prescriptionText, 
        needFollowUp, 
        needFollowUp ? followUpDate : undefined
      );

      if (!result.success) {
        setActionError(result.message);
      } else {
        // Show success modal
        setConclusionSuccessModal({
          patientName: currentPatient?.fullName || 'Bệnh nhân',
          patientId: currentPatient?.id || currentActiveVisit.patientId,
          visitId: currentActiveVisit.id,
          diagnosis: diagnosisText,
          prescription: prescriptionText,
          message: result.message
        });

        // Clear consultation inputs & selection
        setDiagnosisText('');
        setPrescriptionText('');
        setClinicalNotes('');
        setSelectedServices([]);
        setSelectedVisitId(null);
      }
    } catch (err: any) {
      setActionError(err?.message || 'Có lỗi phát sinh khi xử lý kết luận chuyên môn.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Department Switcher */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#163A5F] bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-md">
              Khoa Khám & Điều Trị Ngoại Trú
            </span>
            <span className="text-xs text-slate-400">· {currentRoom}</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Phòng Khám Chuyên Khoa & Chỉ Định Cận Lâm Sàng
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Điều phối gọi số khám, khám lâm sàng, chỉ định xét nghiệm/chẩn đoán hình ảnh và kết luận đơn thuốc
          </p>
        </div>

        {/* Department Switcher */}
        <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-400 font-semibold">Khoa khám:</span>
          <select
            value={activeDept}
            onChange={e => {
              setActiveDept(e.target.value);
              setSelectedVisitId(null);
            }}
            className="text-xs font-bold text-slate-800 bg-transparent focus:outline-hidden cursor-pointer"
          >
            <option value="Tiêu hóa">Khoa Tiêu hóa (Phòng 103)</option>
            <option value="Tim mạch">Khoa Tim mạch (Phòng 201)</option>
            <option value="Hô hấp">Khoa Hô hấp (Phòng 102)</option>
            <option value="Nội tổng quát">Khoa Khám Tổng quát (Phòng 101)</option>
          </select>
        </div>
      </div>

      {actionError && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{actionError}</span>
          </div>
          <button onClick={() => setActionError('')}><X className="w-4 h-4" /></button>
        </div>
      )}

      {/* SECTION 1: QUEUE CONTROLS & CALLING BANNER */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Next Call Trigger */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Hàng đợi {activeDept}</span>
              <span className="text-xs font-bold font-mono text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                Chờ: {waitingPatients.length} BN
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Tự động ưu tiên ca khẩn cấp P1 lên trước, sau đó tới P2 và P3 theo giờ check-in.
            </p>
          </div>

          <button
            onClick={handleCallNext}
            disabled={waitingPatients.length === 0 || !!callingPatient}
            className="mt-4 w-full py-2.5 bg-[#163A5F] hover:bg-[#12304A] disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center justify-center gap-2 cursor-pointer"
          >
            <PhoneCall className="w-4 h-4" /> Gọi Số Thứ Tự Tiếp Theo
          </button>
        </div>

        {/* Current Calling Status (3-min timer) */}
        <div className="md:col-span-2 bg-slate-900 text-white rounded-2xl p-4 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping" />
              <span className="text-xs font-extrabold uppercase text-rose-400 tracking-wider">
                Trạng thái gọi số vào phòng khám (G6)
              </span>
            </div>
            {callingPatient && callTimerSeconds !== null && (
              <span className="font-mono text-xs font-bold bg-rose-950 text-rose-300 border border-rose-800 px-2.5 py-0.5 rounded">
                Hạn có mặt: {Math.floor(callTimerSeconds / 60)}:{(callTimerSeconds % 60).toString().padStart(2, '0')}
              </span>
            )}
          </div>

          {callingPatient ? (
            <div className="my-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-baseline gap-3">
                  <span className="text-3xl font-black font-mono text-teal-400">#{callingPatient.queueNumber}</span>
                  <span className="text-base font-bold text-white">{callingPatient.patientName}</span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Đã thông báo ra loa sảnh chờ. Đang đợi bệnh nhân bước vào phòng khám...
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleConfirmPresent}
                  className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" /> Có mặt (Vào khám)
                </button>
                <button
                  onClick={handleMarkMissed}
                  className="px-3.5 py-2 bg-rose-600/80 hover:bg-rose-600 text-white text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <UserX className="w-4 h-4" /> Vắng mặt (Bỏ lượt)
                </button>
              </div>
            </div>
          ) : (
            <div className="py-4 text-xs text-slate-400">
              {inConsultationPatient ? (
                <div className="flex items-center gap-2 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Đang khám bệnh nhân <strong>{inConsultationPatient.patientName}</strong> (STT #{inConsultationPatient.queueNumber})</span>
                </div>
              ) : (
                'Chưa có lượt gọi nào đang mở. Nhấn "Gọi số tiếp theo" để gọi bệnh nhân kế tiếp.'
              )}
            </div>
          )}
        </div>
      </div>

      {/* SECTION 2: PATIENT MEDICAL RECORD & CLINICAL CONSULTATION */}
      {currentPatient && currentActiveVisit ? (
        <div className="space-y-5">
          <WorkflowProgressTracker visit={currentActiveVisit} />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Patient Profile & History */}
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-blue-600" />
                    <h4 className="font-bold text-slate-900 text-sm">Hồ Sơ Bệnh Nhân</h4>
                  </div>
                  <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    {currentPatient.id}
                  </span>
                </div>

                <div className="space-y-2 text-xs">
                  <div>
                    <span className="text-slate-400">Họ và tên:</span>
                    <p className="font-bold text-slate-900 text-sm">{currentPatient.fullName}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-slate-400">Năm sinh / Tuổi:</span>
                      <p className="font-semibold text-slate-800">{currentPatient.birthYear} ({new Date().getFullYear() - currentPatient.birthYear}t)</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Giới tính:</span>
                      <p className="font-semibold text-slate-800">{currentPatient.gender}</p>
                    </div>
                  </div>
                  <div>
                    <span className="text-slate-400">BHYT:</span>
                    <p className="font-mono font-semibold text-teal-700">{currentPatient.bhytCode} (Hưởng {Math.round(currentPatient.bhytRate * 100)}%)</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Tiền sử dị ứng / mãn tính:</span>
                    <p className="font-medium text-slate-800">{currentPatient.medicalHistory.join(', ') || 'Không ghi nhận'}</p>
                  </div>
                </div>

                {/* Patient Declared Symptoms */}
                <div className="pt-3 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                    Triệu chứng bệnh nhân khai:
                  </span>
                  <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700 italic border border-slate-200/60">
                    "{currentSymptoms?.rawText || 'Đau bụng, buồn nôn'}"
                  </div>
                </div>
              </div>

              {/* Consultation Notes Input */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                  <ClipboardList className="w-4 h-4 text-slate-600" /> Ghi Nhận Khám Lâm Sàng
                </h4>
                <textarea
                  rows={4}
                  placeholder="Nhập dấu hiệu sinh tồn (mạch, huyết áp, nhiệt độ), triệu chứng thực thể phát hiện khi thăm khám..."
                  value={clinicalNotes}
                  onChange={e => setClinicalNotes(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
                <button
                  type="button"
                  onClick={() => saveClinicalNotes(currentActiveVisit.id, clinicalNotes)}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                >
                  Lưu nháp ghi nhận
                </button>
              </div>
            </div>

            {/* Right 2 Columns: Lab Ordering & Results Review */}
            <div className="lg:col-span-2 space-y-5">
              {/* SUBSECTION A: PARACLINICAL ORDERS */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <FlaskConical className="w-5 h-5 text-teal-600" />
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-sm">
                        Chỉ Định Dịch Vụ Cận Lâm Sàng & CĐHA
                      </h4>
                      <p className="text-[11px] text-slate-400">Bác sĩ có thể chỉ định một hoặc đồng thời nhiều xét nghiệm và chẩn đoán hình ảnh</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {availableServices.map((svc, idx) => {
                    const isSelected = selectedServices.some(s => s.name === svc.name);
                    return (
                      <div
                        key={idx}
                        onClick={() => handleToggleService(svc)}
                        className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-start gap-3 ${
                          isSelected 
                            ? 'bg-teal-50 border-teal-400 ring-1 ring-teal-300 shadow-2xs' 
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => {}}
                          className="mt-0.5 text-teal-600 rounded"
                        />
                        <div className="flex-1 min-w-0 text-xs">
                          <p className="font-bold text-slate-800">{svc.name}</p>
                          <p className="text-[11px] text-slate-400 truncate mt-0.5">{svc.room}</p>
                          <span className="font-mono font-semibold text-teal-700 text-[11px] mt-1 block">
                            {svc.price.toLocaleString('vi-VN')} VNĐ
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-xs text-slate-500">
                    Đã chọn: <strong>{selectedServices.length}</strong> dịch vụ
                  </span>
                  <button
                    onClick={handleSendLabOrders}
                    disabled={selectedServices.length === 0}
                    className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" /> Gửi Chỉ Định Cận Lâm Sàng
                  </button>
                </div>
              </div>

              {/* SUBSECTION B: LAB RESULTS VIEWER & CONCLUSION */}
              <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <ClipboardList className="w-5 h-5 text-blue-600" />
                    <div>
                      <h4 className="font-extrabold text-slate-900 text-sm">
                        Kết Quả Cận Lâm Sàng & Kết Luận Chuyên Môn
                      </h4>
                      <p className="text-[11px] text-slate-400">Xem kết quả chi tiết từng dịch vụ và đưa ra chẩn đoán xác định</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono text-slate-500">
                    Chỉ định của BN: {currentOrders.length}
                  </span>
                </div>

                {currentOrders.length === 0 ? (
                  <div className="py-6 text-center text-slate-400 text-xs">
                    Bệnh nhân này chưa có chỉ định cận lâm sàng nào. Bác sĩ có thể chỉ định dịch vụ ở trên hoặc đưa ra kết luận điều trị trực tiếp.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {currentOrders.map(order => (
                      <div key={order.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <div>
                            <span className="font-bold text-slate-900">{order.serviceName}</span>
                            <span className="text-[11px] text-slate-400 font-mono ml-2">({order.id})</span>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            order.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                            order.status === 'invalid' ? 'bg-rose-100 text-rose-800' :
                            order.status === 'delayed' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                          }`}>
                            {order.status === 'completed' ? 'Đã có kết quả hợp lệ' :
                             order.status === 'invalid' ? 'Không hợp lệ (Đang làm lại)' :
                             order.status === 'delayed' ? 'Sự cố không xử lý được (8h)' : `Đang xử lý (~${order.deadlineMinutes || 5}p)`}
                          </span>
                        </div>

                        {order.result ? (
                          <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-2">
                            <p className="text-slate-800 font-medium">
                              <strong>Tóm tắt:</strong> {order.result.summary}
                            </p>
                            {order.result.details.length > 0 && (
                              <div className="overflow-x-auto">
                                <table className="w-full text-left text-[11px] font-mono">
                                  <thead>
                                    <tr className="text-slate-400 border-b border-slate-100">
                                      <th className="py-1">Chỉ số</th>
                                      <th className="py-1">Giá trị</th>
                                      <th className="py-1">Tham chiếu</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {order.result.details.map((d, i) => (
                                      <tr key={i} className={d.isAbnormal ? 'text-rose-600 font-bold' : 'text-slate-700'}>
                                        <td className="py-1 font-sans">{d.param}</td>
                                        <td className="py-1">{d.value} {d.unit}</td>
                                        <td className="py-1 text-slate-400">{d.referenceRange}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                            <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100">
                              <span>Thực hiện: {order.result.performedBy}</span>
                              <span>Duyệt bởi: {order.result.validatedBy || 'KTV'}</span>
                            </div>
                          </div>
                        ) : order.isDelayed || order.status === 'delayed' || order.isUnprocessable ? (
                          <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-800 space-y-2">
                            <div className="flex items-center gap-1.5 font-bold">
                              <AlertTriangle className="w-4 h-4 text-rose-600" />
                              <span>Sự cố thiết bị: Chuyển sang quy trình xử lý 8 tiếng</span>
                            </div>
                            <p className="text-[11px] text-rose-700 font-sans">
                              Khoa Cận lâm sàng đang khắc phục sự cố. Hệ thống sẽ thông báo khi có kết quả.
                            </p>
                          </div>
                        ) : (
                          <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse shrink-0" />
                              <span>
                                Phiếu đang được xử lý tại <strong>{order.roomName}</strong> (~{order.deadlineMinutes || 5} phút).
                              </span>
                            </div>
                            <button
                              onClick={() => quickCompleteLabOrder(order.id)}
                              className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold text-[11px] transition-colors shadow-2xs flex items-center gap-1 self-start sm:self-auto cursor-pointer"
                              title="Sinh kết quả cận lâm sàng ngay lập tức cho demo"
                            >
                              <Zap className="w-3.5 h-3.5" /> Trả nhanh kết quả
                            </button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* Final Diagnosis & Prescription Form */}
                <div className="pt-4 border-t border-slate-100 space-y-3 text-xs">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Chẩn đoán xác định bệnh (ICD-10) *
                    </label>
                    <input
                      type="text"
                      placeholder="Ví dụ: Viêm dạ dày tá tràng cấp tính do Hp - K29.0"
                      value={diagnosisText}
                      onChange={e => setDiagnosisText(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      Hướng dẫn điều trị, ghi chú đơn thuốc & chế độ ăn uống
                    </label>
                    <textarea
                      rows={2}
                      placeholder="Uống thuốc trước ăn 30 phút. Tránh đồ cay nóng, cà phê, rượu bia..."
                      value={prescriptionText}
                      onChange={e => setPrescriptionText(e.target.value)}
                      className="w-full p-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-center gap-4 pt-1">
                    <label className="flex items-center gap-2 cursor-pointer font-medium text-slate-700">
                      <input
                        type="checkbox"
                        checked={needFollowUp}
                        onChange={e => setNeedFollowUp(e.target.checked)}
                        className="text-blue-600 rounded"
                      />
                      <span>Yêu cầu tái khám</span>
                    </label>
                    {needFollowUp && (
                      <input
                        type="text"
                        value={followUpDate}
                        onChange={e => setFollowUpDate(e.target.value)}
                        className="px-2.5 py-1 rounded-lg border border-slate-300 text-xs font-mono"
                        placeholder="DD/MM/YYYY"
                      />
                    )}
                  </div>

                  {/* INLINE ERROR DISPLAY RIGHT AT ACTION POINT */}
                  {actionError && (
                    <div className="p-3.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-medium flex items-start justify-between gap-3 shadow-xs">
                      <div className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                        <div>
                          <p className="font-bold">Chưa thể kết luận chuyên môn:</p>
                          <p className="text-[11px] text-rose-700 mt-0.5">{actionError}</p>
                        </div>
                      </div>
                      <button 
                        onClick={() => setActionError('')}
                        className="text-rose-500 hover:text-rose-700 shrink-0 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  <div className="pt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <p className="text-[11px] text-slate-400">
                      * Nhấn kết luận sẽ tự động chốt viện phí, chuyển sang <strong>Quầy thu ngân</strong> và đơn thuốc sang <strong>Nhà thuốc</strong>.
                    </p>
                    <button
                      onClick={handleCompleteDiagnosis}
                      disabled={isSubmitting}
                      className="px-6 py-2.5 bg-[#163A5F] hover:bg-[#12304A] disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer shrink-0"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" /> Đang Xử Lý...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Kết Luận Chuyên Môn & Chuyển Thanh Toán
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-400 text-xs shadow-xs">
          <Stethoscope className="w-10 h-10 mx-auto text-slate-300 mb-2" />
          <p className="font-bold text-slate-700 text-sm">Hiện chưa có bệnh nhân nào trong phòng khám</p>
          <p className="mt-1">Nhấn <strong>"Gọi Số Tiếp Theo"</strong> ở trên để gọi bệnh nhân từ hàng đợi vào khám.</p>
        </div>
      )}

      {/* FLOATING TOAST NOTIFICATION */}
      {toastNotification && (
        <div className="fixed bottom-6 right-6 z-50 animate-bounce-in">
          <div className={`p-4 rounded-xl shadow-lg border text-xs font-medium flex items-center gap-3 ${
            toastNotification.type === 'success' ? 'bg-emerald-600 text-white border-emerald-700' :
            toastNotification.type === 'error' ? 'bg-rose-600 text-white border-rose-700' :
            'bg-slate-900 text-white border-slate-800'
          }`}>
            {toastNotification.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />}
            {toastNotification.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-200 shrink-0" />}
            {toastNotification.type === 'info' && <Sparkles className="w-4 h-4 text-blue-300 shrink-0" />}
            <span>{toastNotification.text}</span>
            <button onClick={() => setToastNotification(null)} className="ml-2 opacity-80 hover:opacity-100 cursor-pointer">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* CONCLUSION SUCCESS MODAL */}
      {conclusionSuccessModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900">
                  Kết Luận Chuyên Môn Thành Công!
                </h3>
                <p className="text-xs text-slate-500">
                  Hồ sơ và viện phí đã được điều phối tự động sang các bộ phận liên quan
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Bệnh nhân:</span>
                <span className="font-bold text-slate-800">
                  {conclusionSuccessModal.patientName} ({conclusionSuccessModal.patientId})
                </span>
              </div>
              <div className="flex justify-between border-b border-slate-200 pb-2">
                <span className="text-slate-500">Chẩn đoán (ICD-10):</span>
                <span className="font-bold text-blue-700 text-right">
                  {conclusionSuccessModal.diagnosis}
                </span>
              </div>
              {conclusionSuccessModal.prescription && (
                <div className="flex justify-between pb-1">
                  <span className="text-slate-500">Đơn thuốc/Ghi chú:</span>
                  <span className="font-medium text-slate-700 text-right max-w-[240px] truncate">
                    {conclusionSuccessModal.prescription}
                  </span>
                </div>
              )}
            </div>

            {/* Workflow Pipeline Status */}
            <div className="space-y-2 text-xs">
              <p className="font-bold text-slate-700">Trạng thái điều phối quy trình tự động:</p>
              <div className="space-y-1.5 pl-2">
                <div className="flex items-center gap-2 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span><strong>Quầy thu ngân:</strong> Đã tạo hóa đơn viện phí tự động tính BHYT.</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span><strong>Nhà thuốc ngoại trú:</strong> Đã gửi đơn thuốc điện tử sẵn sàng xuất kho.</span>
                </div>
                <div className="flex items-center gap-2 text-emerald-700">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                  <span><strong>Hàng đợi phòng khám:</strong> Đã giải phóng phòng để đón bệnh nhân tiếp theo.</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => setConclusionSuccessModal(null)}
                className="w-full py-2.5 px-4 bg-[#163A5F] hover:bg-[#12304A] text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Stethoscope className="w-4 h-4" /> Khám Ca Tiếp Theo
              </button>
              <button
                onClick={() => {
                  setConclusionSuccessModal(null);
                  window.location.hash = '#cashier';
                }}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Receipt className="w-4 h-4" /> Sang Quầy Thu Ngân <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
