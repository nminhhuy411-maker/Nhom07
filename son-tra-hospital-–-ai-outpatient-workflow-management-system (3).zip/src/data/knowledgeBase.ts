import { KnowledgeBaseDocument, PriorityLevel } from '../types';

export interface DepartmentKnowledge {
  code: string;
  name: string;
  room: string;
  scope: string;
  handledConditions: string[];
  primaryKeywords: string[];
  secondaryKeywords: string[];
  dangerKeywords: string[];
}

export interface SymptomKnowledge {
  id: string;
  symptomName: string;
  category: 'tim_mach' | 'tieu_hoa' | 'ho_hap' | 'than_kinh' | 'tai_mui_hong' | 'da_lieu' | 'co_xuong_khop' | 'toan_than';
  typicalDepartments: string[];
  urgencyLevel: PriorityLevel;
  isRedFlag: boolean;
  commonAliases: string[];
  commonTypos: string[];
  clarificationQuestions: string[];
}

export interface RedFlagRule {
  id: string;
  name: string;
  category: 'tim_mach' | 'ho_hap' | 'dot_quy' | 'xuat_huyet' | 'y_thuc' | 'chan_thuong' | 'ngoai_khoa';
  triggers: string[];
  warningMessage: string;
  immediateAction: string;
}

export const INITIAL_DEPARTMENTS_KB: DepartmentKnowledge[] = [
  {
    code: 'K-TM',
    name: 'Tim mạch',
    room: 'Phòng 201 - Nội Tim mạch',
    scope: 'Khám, chẩn đoán và điều trị ngoại trú các bệnh lý tim và mạch máu.',
    handledConditions: ['Tăng huyết áp', 'Thiếu máu cơ tim', 'Rối loạn nhịp tim', 'Suy tim mạn', 'Bệnh mạch vành'],
    primaryKeywords: ['tim', 'huyết áp', 'hồi hộp', 'đánh trống ngực', 'mạch nhanh', 'nhói ngực', 'phù chân', 'tăng huyết áp'],
    secondaryKeywords: ['chóng mặt khi đứng', 'mệt khi gắng sức', 'nặng ngực'],
    dangerKeywords: ['đau thắt ngực', 'đau ngực dữ dội', 'đau lan vai trái', 'vã mồ hôi khó thở', 'ngất do tim'],
  },
  {
    code: 'K-TH',
    name: 'Tiêu hóa',
    room: 'Phòng 103 - Nội Tiêu hóa',
    scope: 'Khám và điều trị các bệnh lý ống tiêu hóa (dạ dày, thực quản, ruột) và gan mật tụy.',
    handledConditions: ['Viêm loét dạ dày tá tràng', 'Trào ngược dạ dày thực quản (GERD)', 'Viêm đại tràng', 'Rối loạn tiêu hóa', 'Gan nhiễm mỡ'],
    primaryKeywords: ['bụng', 'dạ dày', 'thượng vị', 'buồn nôn', 'nôn', 'tiêu chảy', 'ợ chua', 'ợ hơi', 'táo bón', 'đầy bụng', 'khó tiêu', 'đau bụng'],
    secondaryKeywords: ['chán ăn', 'sút cân', 'đắng miệng', 'sình bụng'],
    dangerKeywords: ['nôn ra máu', 'đi ngoài phân đen', 'đau bụng dữ dội', 'bụng cứng như gỗ', 'vàng da cấp tính'],
  },
  {
    code: 'K-HH',
    name: 'Hô hấp',
    room: 'Phòng 102 - Nội Hô hấp',
    scope: 'Khám và điều trị bệnh lý đường hô hấp trên và dưới.',
    handledConditions: ['Viêm phế quản', 'Hen phế quản', 'COPD', 'Viêm thanh quản', 'Viêm phổi cộng đồng nhẹ'],
    primaryKeywords: ['ho', 'sốt', 'đờm', 'khạc đờm', 'phổi', 'ngạt mũi', 'viêm họng', 'khàn tiếng', 'thở rít', 'viêm phế quản'],
    secondaryKeywords: ['ho khan', 'ho có đờm', 'ngứa cổ', 'rát họng'],
    dangerKeywords: ['khó thở dữ dội', 'tím tái', 'ho ra máu', 'thở co kéo', 'rút lõm lồng ngực'],
  },
  {
    code: 'K-TK',
    name: 'Thần kinh',
    room: 'Phòng 204 - Nội Thần kinh',
    scope: 'Khám và điều trị các rối loạn hệ thần kinh trung ương và ngoại vi.',
    handledConditions: ['Đau đầu Migraine', 'Rối loạn tiền đình', 'Mất ngủ kéo dài', 'Đau dây thần kinh tọa', 'Parkinson nhẹ'],
    primaryKeywords: ['đầu', 'đau đầu', 'chóng mặt', 'hoa mắt', 'mất ngủ', 'tê bì', 'đau nửa đầu', 'tiền đình', 'run tay chân', 'choáng váng'],
    secondaryKeywords: ['căng thẳng', 'đau sau gáy', 'bốc hỏa', 'giảm trí nhớ'],
    dangerKeywords: ['đột quỵ', 'méo miệng', 'yếu liệt nửa người', 'nói khó đột ngột', 'co giật', 'ngất', 'hôn mê'],
  },
  {
    code: 'K-TMH',
    name: 'Tai mũi họng',
    room: 'Phòng 105 - Tai Mũi Họng',
    scope: 'Khám chuyên khoa tai, mũi, họng và thanh quản.',
    handledConditions: ['Viêm xoang cấp/mạn', 'Viêm amidan', 'Viêm tai giữa', 'Viêm mũi dị ứng'],
    primaryKeywords: ['tai', 'mũi', 'họng', 'ù tai', 'chảy mủ tai', 'viêm xoang', 'ngạt mũi', 'chảy máu cam', 'amidan', 'đau tai', 'nghe kém'],
    secondaryKeywords: ['hắt hơi', 'chảy nước mũi', 'nuốt đau', 'vướng họng'],
    dangerKeywords: ['chảy máu mũi ồ ạt', 'dị vật đường thở', 'khó nuốt nghẹn hoàn toàn', 'khàn tiếng mất tiếng cấp'],
  },
  {
    code: 'K-DL',
    name: 'Da liễu',
    room: 'Phòng 106 - Da liễu',
    scope: 'Khám và điều trị các bệnh da, lông, tóc, móng và dị ứng ngoài da.',
    handledConditions: ['Mề đay cấp/mạn', 'Viêm da cơ địa', 'Viêm da dị ứng', 'Nấm da', 'Mụn trứng cá'],
    primaryKeywords: ['da', 'ngứa', 'mẩn đỏ', 'dị ứng', 'mề đay', 'mụn', 'vảy nến', 'nấm da', 'bọng nước', 'phát ban', 'sẩn ngứa'],
    secondaryKeywords: ['khô da', 'bong vảy', 'nổi sần', 'rát da'],
    dangerKeywords: ['dị ứng thuốc toàn thân', 'hội chứng Stevens-Johnson', 'bọng nước trợt loét toàn thân', 'phù mạch kèm khó thở'],
  },
  {
    code: 'K-TQ',
    name: 'Nội tổng quát',
    room: 'Phòng 101 - Khám Tổng quát',
    scope: 'Khám sàng lọc, đánh giá sức khỏe tổng quát hoặc các triệu chứng chưa rõ khu trú.',
    handledConditions: ['Khám sức khỏe tổng quát', 'Hội chứng mệt mỏi mạn tính', 'Sụt cân chưa rõ nguyên nhân', 'Thiếu máu'],
    primaryKeywords: ['khám sức khỏe', 'sút cân', 'mệt', 'uể oải', 'chán ăn', 'khám tổng quát', 'yếu sức'],
    secondaryKeywords: ['suy nhược', 'mệt mỏi', 'người không khỏe'],
    dangerKeywords: ['suy kiệt cấp', 'sốt cao co giật', 'hạ đường huyết hôn mê'],
  },
];

export const INITIAL_RED_FLAGS: RedFlagRule[] = [
  {
    id: 'RF-01',
    name: 'Hội chứng mạch vành cấp / Nhồi máu cơ tim',
    category: 'tim_mach',
    triggers: ['đau ngực', 'tức ngực', 'đau thắt ngực', 'đau sau xương ức', 'đau đè nghẹt ngực', 'dau nguc', 'tuc nguc', 'nang nguc du doi'],
    warningMessage: 'DẤU HIỆU CẢNH BÁO NGUY HIỂM TIM MẠCH: Triệu chứng đau tức/thắt ngực có nguy cơ cao là thiếu máu cơ tim hoặc nhồi máu cơ tim cấp.',
    immediateAction: 'Kích hoạt tiếp nhận khẩn cấp (Ưu tiên 1). Hướng dẫn bệnh nhân ngồi nghỉ tại chỗ và liên hệ điều dưỡng cấp cứu ngay lập tức.',
  },
  {
    id: 'RF-02',
    name: 'Suy hô hấp cấp / Tắc nghẽn đường thở',
    category: 'ho_hap',
    triggers: ['khó thở', 'khó thở dữ dội', 'thở hụt hơi', 'thở rít', 'tím tái', 'kho tho', 'ngop tho'],
    warningMessage: 'DẤU HIỆU CẢNH BÁO SUY HÔ HẤP: Bệnh nhân có dấu hiệu khó thở cấp tính, nguy cơ thiếu oxy mô.',
    immediateAction: 'Chuyển thẳng phòng cấp cứu hô hấp. Chuẩn bị nguồn oxy và bác sĩ đánh giá khẩn.',
  },
  {
    id: 'RF-03',
    name: 'Dấu hiệu Đột quỵ não cấp (FAST)',
    category: 'dot_quy',
    triggers: ['méo miệng', 'liệt', 'yếu nửa người', 'nói ngọng đột ngột', 'nói khó', 'tay rơi', 'meo mieng', 'yeu liet'],
    warningMessage: 'CẢNH BÁO ĐỘT QUỴ NÃO CẤP (FAST): Dấu hiệu yếu liệt nửa người, méo miệng hoặc nói khó đột ngột là triệu chứng tai biến mạch máu não.',
    immediateAction: 'Kích hoạt luồng "Báo động Đỏ Đột Quỵ". Bệnh nhân cần được chụp CT/MRI sọ não trong giờ vàng.',
  },
  {
    id: 'RF-04',
    name: 'Xuất huyết tiêu hóa hoặc chấn thương chảy máu nhiều',
    category: 'xuat_huyet',
    triggers: ['nôn ra máu', 'đi ngoài phân đen', 'chảy máu nhiều', 'chảy máu không cầm', 'non ra mau', 'chay mau o at'],
    warningMessage: 'CẢNH BÁO XUẤT HUYẾT NGUY HIỂM: Dấu hiệu mất máu ồ ạt, nguy cơ tụt huyết áp và sốc mất máu.',
    immediateAction: 'Ưu tiên 1 - Tiếp nhận phòng cấp cứu, thiết lập đường truyền tĩnh mạch và kiểm tra huyết động.',
  },
  {
    id: 'RF-05',
    name: 'Mất ý thức / Co giật / Hôn mê',
    category: 'y_thuc',
    triggers: ['ngất', 'bất tỉnh', 'co giật', 'hôn mê', 'mất ý thức', 'ngat xiur', 'co giat keo dai'],
    warningMessage: 'CẢNH BÁO RỐI LOẠN Ý THỨC: Bệnh nhân bị mất ý thức, ngất hoặc co giật.',
    immediateAction: 'Ưu tiên 1 - Hỗ trợ tư thế nằm nghiêng an toàn, gọi ngay nhân viên y tế hỗ trợ tức thì.',
  },
  {
    id: 'RF-06',
    name: 'Bụng ngoại khoa cấp cứu',
    category: 'ngoai_khoa',
    triggers: ['đau bụng dữ dội', 'bụng cứng như gỗ', 'đau quằn quại', 'dau bung du doi', 'dau bung quan'],
    warningMessage: 'CẢNH BÁO BỤNG NGOẠI KHOA: Cơn đau bụng dữ dội có thể do viêm ruột thừa vỡ, thủng tạng rỗng hoặc viêm tụy cấp.',
    immediateAction: 'Đưa vào khám cấp cứu ngay, không cho ăn uống, bác sĩ ngoại khoa thăm khám.',
  },
];

export const INITIAL_SYMPTOMS_KB: SymptomKnowledge[] = [
  {
    id: 'SYM-KB-01',
    symptomName: 'Đau bụng vùng thượng vị',
    category: 'tieu_hoa',
    typicalDepartments: ['Tiêu hóa'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['đau trên rốn', 'đau dạ dày', 'xót ruột', 'cồn cào', 'đau bao tử', 'xot ruot con cao'],
    commonTypos: ['dau bung', 'dau da day', 'dau thuong vi', 'xot ruot'],
    clarificationQuestions: [
      'Bác bị đau trước hay sau khi ăn, đau âm ỉ hay từng cơn?',
      'Bác có bị ợ chua, ợ nóng hay buồn nôn đi kèm không?'
    ],
  },
  {
    id: 'SYM-KB-02',
    symptomName: 'Đau thắt ngực trái',
    category: 'tim_mach',
    typicalDepartments: ['Tim mạch'],
    urgencyLevel: 1,
    isRedFlag: true,
    commonAliases: ['tức ngực', 'nặng ngực', 'đè ép ngực', 'đau nhói ngực trái', 'dau nguc trai'],
    commonTypos: ['dau nguc', 'tuc nguc', 'nhoi nguc', 'nang nguc'],
    clarificationQuestions: [
      'Cơn đau ngực có lan lên vai trái, cổ hay cánh tay không?',
      'Bác có cảm giác khó thở hoặc vã mồ hôi lạnh đi kèm không?'
    ],
  },
  {
    id: 'SYM-KB-03',
    symptomName: 'Đau đầu / Chóng mặt',
    category: 'than_kinh',
    typicalDepartments: ['Thần kinh'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['nhức đầu', 'hoa mắt', 'choáng váng', 'đau nửa đầu', 'nhuc dau qua', 'quay cuong'],
    commonTypos: ['dau dau', 'nhuc dau', 'chong mat', 'hoa mat'],
    clarificationQuestions: [
      'Bác bị đau nửa đầu hay đau cả đầu, đau âm ỉ hay giật theo nhịp mạch?',
      'Bác có bị tê bì tay chân hay nhìn mờ đi kèm không?'
    ],
  },
  {
    id: 'SYM-KB-04',
    symptomName: 'Ho kéo dài / Khạc đờm',
    category: 'ho_hap',
    typicalDepartments: ['Hô hấp'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['ho khan', 'ho đờm', 'ngứa rát họng ho', 'ho liên tục', 'khac dom'],
    commonTypos: ['ho khan', 'ho co dom', 'viem hong ho'],
    clarificationQuestions: [
      'Bác ho khan hay có đờm, đờm màu trắng trong hay màu vàng/xanh?',
      'Bác bị ho bao nhiêu ngày rồi, có kèm theo sốt không?'
    ],
  },
  {
    id: 'SYM-KB-05',
    symptomName: 'Mệt mỏi toàn thân / Uể oải',
    category: 'toan_than',
    typicalDepartments: ['Nội tổng quát'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['người yếu', 'mệt mệt', 'uể oải', 'chán ăn', 'mất sức', 'khong duoc khoe'],
    commonTypos: ['met moi', 'met met', 'ue oai'],
    clarificationQuestions: [
      'Cảm giác mệt mỏi xuất hiện từ khi nào, bác có bị sút cân hay sốt về chiều không?',
      'Bác có thấy đau nhức ở bộ phận nào cụ thể (bụng, ngực, đầu) không?'
    ],
  },
  {
    id: 'SYM-KB-06',
    symptomName: 'Mẩn ngứa ngoài da / Mề đay',
    category: 'da_lieu',
    typicalDepartments: ['Da liễu'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['nổi sẩn', 'phát ban đỏ', 'ngứa ngáy', 'dị ứng thức ăn nổi mề đay'],
    commonTypos: ['ngua da', 'man ngua', 'me day', 'di ung da'],
    clarificationQuestions: [
      'Vùng mẩn ngứa xuất hiện ở đâu trên cơ thể (tay chân, lưng hay toàn thân)?',
      'Bác có ăn đồ lạ hoặc uống thuốc gì gần đây không? Có khó thở hay sưng môi không?'
    ],
  },
  {
    id: 'SYM-KB-07',
    symptomName: 'Đau nhức tai / Chảy mủ tai',
    category: 'tai_mui_hong',
    typicalDepartments: ['Tai mũi họng'],
    urgencyLevel: 3,
    isRedFlag: false,
    commonAliases: ['ù tai', 'nghe kém', 'chảy nước tai', 'viêm tai'],
    commonTypos: ['dau tai', 'u tai', 'chay mu tai'],
    clarificationQuestions: [
      'Bác bị đau ở tai trái hay tai phải, có dịch mủ chảy ra không?',
      'Bác có bị ngạt mũi hay đau họng đi kèm không?'
    ],
  },
];

export const INITIAL_KB_DOCUMENTS: KnowledgeBaseDocument[] = [
  {
    id: 'KB-DOC-01',
    category: 'department',
    title: 'Danh mục 7 Chuyên khoa Khám bệnh Ngoại trú BV Sơn Trà',
    code: 'DOC-DEPT-2026',
    content: 'Bệnh viện Đa khoa Sơn Trà triển khai 7 chuyên khoa ngoại trú phục vụ tiếp nhận: Tim mạch (P.201), Tiêu hóa (P.103), Hô hấp (P.102), Thần kinh (P.204), Tai Mũi Họng (P.105), Da liễu (P.106), Nội tổng quát (P.101).',
    version: '1.2',
    approvedBy: 'Hội đồng Khoa học Bệnh viện Sơn Trà',
    updatedAt: '01/11/2026',
  },
  {
    id: 'KB-DOC-02',
    category: 'red_flag',
    title: 'Danh mục Dấu hiệu Cảnh báo Nguy hiểm (Red Flags Triage)',
    code: 'DOC-REDFLAG-2026',
    content: 'Quy định các dấu hiệu cảnh báo khẩn cấp: Đau thắt ngực trái/sau xương ức, Khó thở cấp tính, Dấu hiệu đột quỵ FAST (méo miệng, liệt nửa người, nói khó), Nôn ra máu/đi ngoài phân đen, Mất ý thức/ngất, Đau bụng dữ dội đề kháng. Bắt buộc gắn cờ Ưu tiên 1 và không được ghi đè bởi triệu chứng thông thường.',
    version: '2.0',
    approvedBy: 'Trưởng khoa Cấp cứu & Ban Giám đốc BV Sơn Trà',
    updatedAt: '01/11/2026',
  },
  {
    id: 'KB-DOC-03',
    category: 'triage_rule',
    title: 'Quy tắc Xác định 3 Mức độ Ưu tiên Tiếp nhận (BR03)',
    code: 'DOC-PRIORITY-2026',
    content: 'Mức 1: Cần đánh giá cấp cứu ngay (Red flag, đau thắt ngực, suy hô hấp). Mức 2: Cần được đánh giá sớm (Bệnh nhân đau vừa đến nặng, hoặc áp dụng quy tắc BR03: người từ 65 tuổi trở lên hoặc trẻ dưới 6 tuổi tự động tăng 1 bậc ưu tiên). Mức 3: Khám theo quy trình thông thường.',
    version: '1.1',
    approvedBy: 'Phòng Quản lý Chất lượng BV Sơn Trà',
    updatedAt: '01/11/2026',
  },
  {
    id: 'KB-DOC-04',
    category: 'workflow',
    title: 'Quy trình Tiếp nhận Bệnh nhân & Cấp mã QR (UC.02, UC.05, UC.06)',
    code: 'DOC-WORKFLOW-RECEPTION',
    content: 'Quy trình tiếp nhận: Bệnh nhân nhận diện qua CCCD/SĐT -> Khai báo triệu chứng -> AI tổng hợp & đề xuất -> Lễ tân duyệt -> Cấp khung giờ 15 phút (BR06) & mã QR -> Check-in tại bệnh viện: Đúng giờ (-30p đến +15p) vào hàng đợi bình thường, trễ quá 15p lùi lượt (BR07). Mã QR chỉ dùng 1 lần (BR08).',
    version: '1.0',
    approvedBy: 'Phòng Kế hoạch Tổng hợp',
    updatedAt: '01/11/2026',
  },
  {
    id: 'KB-DOC-05',
    category: 'workflow',
    title: 'Quy trình Cận lâm sàng Inclusive Gateway & Timer 8 Giờ (BPMN Subprocess)',
    code: 'DOC-WORKFLOW-CLS',
    content: 'Chỉ định cận lâm sàng gồm Xét nghiệm, X-Quang, Siêu âm được thực hiện độc lập (Inclusive Gateway). Mỗi phiếu có mã riêng và hạn 8 giờ. Nếu kết quả không hợp lệ (G8), chỉ yêu cầu làm lại phiếu bị lỗi. Nếu quá hạn 8 giờ (G10), chuyển trạng thái chậm trễ, KTV ghi nguyên nhân và chọn tiếp tục hoặc hủy phiếu.',
    version: '1.3',
    approvedBy: 'Trưởng khoa Cận lâm sàng & CĐHA',
    updatedAt: '01/11/2026',
  },
  {
    id: 'KB-DOC-06',
    category: 'rbac',
    title: 'Ma trận Phân quyền 5 Nhóm Người dùng (RBAC Policy)',
    code: 'DOC-RBAC-2026',
    content: 'Bệnh nhân: Khai triệu chứng, xem QR, theo dõi hàng đợi, hủy lịch, xem hóa đơn. Lễ tân: Duyệt phân luồng, đánh giá ca khẩn, cấp lịch, hỗ trợ check-in. Bác sĩ: Khám lâm sàng, gọi số, chỉ định CLS, xem kết quả, kết luận. KTV Cận lâm sàng: Nhận phiếu, nhập kết quả, kiểm tra hợp lệ, xử lý quá hạn. Thu ngân: Tính viện phí, khấu trừ BHYT, xuất hóa đơn. Admin: Quản trị cấu hình, đồng hồ giả lập, nạp dữ liệu và đánh giá AI.',
    version: '1.0',
    approvedBy: 'Phòng Công nghệ Thông tin',
    updatedAt: '01/11/2026',
  },
];
