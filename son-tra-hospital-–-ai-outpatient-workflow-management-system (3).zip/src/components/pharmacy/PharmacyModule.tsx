import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { PrescriptionOrder } from '../../types';
import { 
  Pill, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  PackageCheck, 
  Printer, 
  User, 
  Calendar, 
  Stethoscope, 
  FileText,
  ChevronRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';

export const PharmacyModule: React.FC = () => {
  const { prescriptions, updatePrescriptionStatus, activeAccount } = useHospital();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'preparing' | 'ready' | 'dispensed'>('all');
  const [selectedRx, setSelectedRx] = useState<PrescriptionOrder | null>(null);
  const [dispenseNote, setDispenseNote] = useState('');
  const [showPrintSuccess, setShowPrintSuccess] = useState(false);

  // Filtered prescriptions
  const filteredList = prescriptions.filter(rx => {
    const matchSearch = 
      rx.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rx.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rx.diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = statusFilter === 'all' || rx.status === statusFilter;
    return matchSearch && matchStatus;
  });

  // Metrics
  const totalCount = prescriptions.length;
  const preparingCount = prescriptions.filter(r => r.status === 'preparing').length;
  const readyCount = prescriptions.filter(r => r.status === 'ready').length;
  const dispensedCount = prescriptions.filter(r => r.status === 'dispensed').length;

  const handleUpdateStatus = (id: string, newStatus: PrescriptionOrder['status']) => {
    updatePrescriptionStatus(id, newStatus, dispenseNote || undefined);
    if (selectedRx && selectedRx.id === id) {
      setSelectedRx(prev => prev ? { ...prev, status: newStatus } : null);
    }
    setDispenseNote('');
  };

  const handlePrint = () => {
    setShowPrintSuccess(true);
    setTimeout(() => setShowPrintSuccess(false), 2000);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner / Header */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#16A6A1] mb-1">
            <Pill className="w-4 h-4" /> Khoa Dược & Nhà thuốc Ngoại trú
          </div>
          <h1 className="text-xl font-bold text-[#163A5F] tracking-tight">
            Quản lý cấp phát thuốc theo đơn điện tử
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Tiếp nhận đơn ngoại trú từ phòng khám, kiểm tra tồn kho và cấp phát thuốc có hướng dẫn sử dụng
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs">
            <span className="text-slate-500 block text-[10px]">Dược sĩ phụ trách</span>
            <span className="font-semibold text-slate-800">{activeAccount.name}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
            <span>Tổng đơn hôm nay</span>
            <FileText className="w-4 h-4 text-[#2878B5]" />
          </div>
          <div className="text-2xl font-bold text-slate-900">{totalCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">Đơn bác sĩ đã kê</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-amber-600 mb-2">
            <span>Đang chuẩn bị</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold text-amber-600">{preparingCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">Đang nhặt thuốc & chia liều</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-blue-600 mb-2">
            <span>Sẵn sàng giao</span>
            <PackageCheck className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold text-blue-600">{readyCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">Chờ bệnh nhân tại quầy</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-xs text-emerald-600 mb-2">
            <span>Đã hoàn tất phát</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold text-emerald-600">{dispensedCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">Đã hướng dẫn & giao tận tay</div>
        </div>
      </div>

      {/* Filter and Table Container */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Search & Tabs Toolbar */}
        <div className="p-4 border-b border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="relative min-w-[280px]">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm mã đơn, tên bệnh nhân, chẩn đoán..."
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-[#2878B5] focus:bg-white"
              />
            </div>
          </div>

          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                statusFilter === 'all' ? 'bg-white text-[#163A5F] shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({totalCount})
            </button>
            <button
              onClick={() => setStatusFilter('preparing')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                statusFilter === 'preparing' ? 'bg-white text-amber-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Đang chuẩn bị ({preparingCount})
            </button>
            <button
              onClick={() => setStatusFilter('ready')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                statusFilter === 'ready' ? 'bg-white text-blue-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sẵn sàng ({readyCount})
            </button>
            <button
              onClick={() => setStatusFilter('dispensed')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                statusFilter === 'dispensed' ? 'bg-white text-emerald-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Đã phát ({dispensedCount})
            </button>
          </div>
        </div>

        {/* Orders Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4 font-semibold">Mã đơn thuốc</th>
                <th className="py-3 px-4 font-semibold">Bệnh nhân</th>
                <th className="py-3 px-4 font-semibold">Bác sĩ kê đơn</th>
                <th className="py-3 px-4 font-semibold">Chẩn đoán chuyên khoa</th>
                <th className="py-3 px-4 font-semibold text-center">Số loại thuốc</th>
                <th className="py-3 px-4 font-semibold">Trạng thái</th>
                <th className="py-3 px-4 font-semibold text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Không tìm thấy đơn thuốc nào phù hợp với bộ lọc.
                  </td>
                </tr>
              ) : (
                filteredList.map((rx) => {
                  return (
                    <tr 
                      key={rx.id} 
                      className="hover:bg-blue-50/40 transition-colors cursor-pointer"
                      onClick={() => setSelectedRx(rx)}
                    >
                      <td className="py-3.5 px-4 font-mono font-medium text-[#163A5F]">
                        {rx.id}
                        <span className="block text-[10px] text-slate-400 font-sans mt-0.5">{rx.createdAt}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{rx.patientName}</div>
                        <span className="text-[10px] text-slate-500 font-mono">Mã BN: {rx.patientId}</span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="text-slate-800 font-medium">{rx.doctorName}</div>
                        <div className="text-[10px] text-slate-400">{rx.department}</div>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs truncate text-slate-700">
                        {rx.diagnosis}
                      </td>
                      <td className="py-3.5 px-4 text-center font-semibold text-slate-700">
                        {rx.items.length} món
                      </td>
                      <td className="py-3.5 px-4">
                        {rx.status === 'preparing' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200">
                            <Clock className="w-3 h-3" /> Đang chuẩn bị
                          </span>
                        )}
                        {rx.status === 'ready' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
                            <PackageCheck className="w-3 h-3" /> Sẵn sàng giao
                          </span>
                        )}
                        {rx.status === 'dispensed' && (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" /> Đã phát thuốc
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedRx(rx);
                          }}
                          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-[#2878B5] hover:text-white text-slate-700 font-medium transition-colors cursor-pointer text-xs inline-flex items-center gap-1"
                        >
                          Chi tiết <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Prescription Detail Modal */}
      {selectedRx && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-3xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-100 text-[#2878B5] flex items-center justify-center">
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-[#163A5F]">
                      Chi tiết đơn thuốc {selectedRx.id}
                    </h3>
                    <span className="text-xs px-2 py-0.5 rounded-md font-mono bg-slate-200 text-slate-700">
                      {selectedRx.status === 'dispensed' ? 'Đã phát' : selectedRx.status === 'ready' ? 'Sẵn sàng' : 'Đang chuẩn bị'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    Bệnh nhân: <strong className="text-slate-800">{selectedRx.patientName}</strong> ({selectedRx.patientId}) · Kê bởi: {selectedRx.doctorName}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedRx(null)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 flex-1">
              {showPrintSuccess && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Đã gửi lệnh in toa thuốc và hướng dẫn sử dụng ra máy in quầy dược!</span>
                </div>
              )}

              {/* Diagnosis box */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">Chẩn đoán điều trị:</span>
                <p className="font-semibold text-slate-800 text-sm">{selectedRx.diagnosis}</p>
                <div className="mt-2 text-slate-500 flex items-center gap-4 text-[11px]">
                  <span>Thời gian kê: {selectedRx.createdAt}</span>
                  {selectedRx.dispensedAt && (
                    <span className="text-emerald-600 font-medium">
                      Thời gian phát: {selectedRx.dispensedAt} ({selectedRx.dispensedBy})
                    </span>
                  )}
                </div>
              </div>

              {/* Drug items list */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                  Danh mục thuốc chỉ định ({selectedRx.items.length} mặt hàng)
                </h4>
                <div className="space-y-3">
                  {selectedRx.items.map((item, idx) => (
                    <div 
                      key={item.id} 
                      className="p-3.5 rounded-xl border border-slate-200 hover:border-slate-300 transition-colors bg-white flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-slate-100 text-slate-600 font-bold text-[10px] flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <span className="font-bold text-sm text-[#163A5F]">{item.drugName}</span>
                          <span className="text-[11px] text-slate-400">({item.activeIngredient})</span>
                        </div>
                        <p className="text-xs text-slate-600 pl-7">
                          <span className="font-semibold text-slate-700">Liều dùng:</span> {item.dosage}
                        </p>
                        {item.note && (
                          <p className="text-[11px] text-amber-700 pl-7 italic">
                            * Lưu ý: {item.note}
                          </p>
                        )}
                      </div>

                      <div className="flex items-center gap-6 pl-7 md:pl-0 shrink-0">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">Số lượng</span>
                          <span className="font-bold text-base text-slate-900">
                            {item.quantity} <span className="text-xs font-normal text-slate-500">{item.unit}</span>
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">Tồn khả dụng</span>
                          <span className={`text-xs font-semibold ${(item.availableStock ?? item.stockAvailable ?? 0) > 20 ? 'text-emerald-600' : 'text-red-600'}`}>
                            {item.availableStock ?? item.stockAvailable ?? 0} {item.unit}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Note / instruction */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Ghi chú cấp phát hoặc dặn dò bệnh nhân:
                </label>
                <textarea
                  rows={2}
                  value={dispenseNote}
                  onChange={(e) => setDispenseNote(e.target.value)}
                  placeholder="Nhập hướng dẫn uống thuốc, lưu ý bảo quản hoặc dị ứng nếu có..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                />
              </div>
            </div>

            {/* Modal Footer / Actions */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handlePrint}
                className="px-4 py-2 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-slate-500" /> In toa thuốc hướng dẫn
              </button>

              <div className="flex items-center gap-2">
                {selectedRx.status === 'preparing' && (
                  <button
                    type="button"
                    onClick={() => handleUpdateStatus(selectedRx.id, 'ready')}
                    className="px-4 py-2 rounded-xl bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
                  >
                    Hoàn tất nhặt thuốc (Sẵn sàng phát)
                  </button>
                )}

                {selectedRx.status === 'ready' && (
                  <button
                    type="button"
                    onClick={() => handleUpdateStatus(selectedRx.id, 'dispensed')}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors flex items-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Xác nhận đã phát cho bệnh nhân
                  </button>
                )}

                {selectedRx.status === 'dispensed' && (
                  <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Đơn đã phát thành công
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
