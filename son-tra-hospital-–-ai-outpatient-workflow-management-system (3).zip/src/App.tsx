import React, { useState, useEffect } from 'react';
import { HospitalProvider, useHospital } from './context/HospitalContext';
import { Header } from './components/common/Header';
import { Sidebar, NavTab } from './components/common/Sidebar';
import { NotificationDrawer } from './components/common/NotificationDrawer';
import { AuditLogModal } from './components/common/AuditLogModal';
import { UseCaseMatrixModal } from './components/common/UseCaseMatrixModal';
import { Forbidden403Screen } from './components/common/Forbidden403Screen';
import { LoginScreen } from './components/auth/LoginScreen';

import { PatientModule } from './components/patient/PatientModule';
import { ReceptionModule } from './components/reception/ReceptionModule';
import { QueueDisplayModule } from './components/queue/QueueDisplayModule';
import { DoctorModule } from './components/doctor/DoctorModule';
import { ParaclinicalModule } from './components/paraclinical/ParaclinicalModule';
import { CashierModule } from './components/cashier/CashierModule';
import { PharmacyModule } from './components/pharmacy/PharmacyModule';
import { AdminDashboard } from './components/admin/AdminDashboard';

const VALID_TABS: NavTab[] = ['patient', 'reception', 'queue', 'doctor', 'paraclinical', 'pharmacy', 'cashier', 'admin'];

const ROLE_ALLOWED_TABS: Record<string, NavTab[]> = {
  admin: ['patient', 'reception', 'queue', 'doctor', 'paraclinical', 'pharmacy', 'cashier', 'admin'],
  patient: ['patient', 'queue'],
  reception: ['reception', 'queue', 'patient'],
  doctor: ['doctor', 'queue', 'paraclinical', 'pharmacy', 'patient'],
  paraclinical: ['paraclinical', 'queue'],
  pharmacy: ['pharmacy', 'doctor'],
  cashier: ['cashier', 'queue'],
};

const MainLayout: React.FC = () => {
  const { isAuthenticated, activeAccount, checkPermission } = useHospital();

  // URL Hash Sync for TC_RBAC_10 (Direct URL navigation guard)
  const getInitialTab = (): NavTab => {
    const hash = window.location.hash.replace('#', '') as NavTab;
    if (VALID_TABS.includes(hash)) {
      return hash;
    }
    if (activeAccount.role === 'admin') return 'admin';
    if (activeAccount.role === 'doctor') return 'doctor';
    if (activeAccount.role === 'reception') return 'reception';
    if (activeAccount.role === 'paraclinical') return 'paraclinical';
    if (activeAccount.role === 'cashier') return 'cashier';
    if (activeAccount.role === 'pharmacy') return 'pharmacy';
    return 'patient';
  };

  const [currentTab, setCurrentTab] = useState<NavTab>(getInitialTab);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isAuditLogOpen, setIsAuditLogOpen] = useState(false);
  const [isUseCaseMatrixOpen, setIsUseCaseMatrixOpen] = useState(false);

  // Sync state -> URL Hash
  const handleSelectTab = (tab: NavTab) => {
    setCurrentTab(tab);
    window.location.hash = `#${tab}`;
  };

  // Listen to browser back/forward or direct address bar typing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '') as NavTab;
      if (VALID_TABS.includes(hash)) {
        setCurrentTab(hash);
      }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Sync initial hash on mount if none
  useEffect(() => {
    if (!window.location.hash) {
      window.location.hash = `#${currentTab}`;
    }
  }, [currentTab]);

  // Session Management (Logout must end session and show Login)
  if (!isAuthenticated) {
    return <LoginScreen />;
  }

  // RouteGuard check: Verify active account's permitted tabs
  const allowed = ROLE_ALLOWED_TABS[activeAccount.role] || ['patient'];
  const isUnauthorized = !allowed.includes(currentTab);

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col antialiased">
      {/* Top Header */}
      <Header
        onOpenNotifications={() => setIsNotificationOpen(true)}
        onOpenAuditLogs={() => setIsAuditLogOpen(true)}
        onOpenUseCaseMatrix={() => setIsUseCaseMatrixOpen(true)}
      />

      {/* Main Container with Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={handleSelectTab}
        />

        {/* Dynamic Viewport with RouteGuard */}
        <main className="flex-1 overflow-y-auto min-w-0 bg-[#F5F7FA] pb-16">
          {isUnauthorized ? (
            <Forbidden403Screen 
              attemptedTab={currentTab} 
              onNavigateHome={() => handleSelectTab((allowed[0] || 'patient') as NavTab)} 
            />
          ) : (
            <>
              {currentTab === 'patient' && <PatientModule />}
              {currentTab === 'reception' && <ReceptionModule />}
              {currentTab === 'queue' && <QueueDisplayModule />}
              {currentTab === 'doctor' && <DoctorModule />}
              {currentTab === 'paraclinical' && <ParaclinicalModule />}
              {currentTab === 'pharmacy' && <PharmacyModule />}
              {currentTab === 'cashier' && <CashierModule />}
              {currentTab === 'admin' && (
                <AdminDashboard onNavigateToTab={handleSelectTab} />
              )}
            </>
          )}
        </main>
      </div>

      {/* Modals & Drawers */}
      <NotificationDrawer
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
      />

      <AuditLogModal
        isOpen={isAuditLogOpen}
        onClose={() => setIsAuditLogOpen(false)}
      />

      <UseCaseMatrixModal
        isOpen={isUseCaseMatrixOpen}
        onClose={() => setIsUseCaseMatrixOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <HospitalProvider>
      <MainLayout />
    </HospitalProvider>
  );
}
