import React, { useState } from 'react';
import { X, CheckCircle, FileText, AlertCircle, Sparkles, Filter } from 'lucide-react';

interface UseCaseMatrixModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UseCaseMatrixModal: React.FC<UseCaseMatrixModalProps> = ({ isOpen, onClose }) => {
  const [filterXor, setFilterXor] = useState<string>('all');

  if (!isOpen) return null;

  const useCases = [
    {
      id: 'UC.01',
      name: 'Đăng nhập và phân quyền nhân viên',
      actor: 'Lễ tân, Bác sĩ, KTV Cận lâm sàng, Thu ngân, Admin',
      uiComponent: 'Thanh Header / Modal Chuyển vai trò Demo (Role Switcher)',
      preCondition: 'Nhân viên có tài khoản hợp lệ, hệ thống hoạt động',
      mainFlow: '1. Chọn vai trò/đăng nhập -> 2. Xác thực phiên làm việc -> 3. Chuyển hướng đúng giao diện chuyên môn',
      altFlow: 'Đăng xuất hoặc chuyển đổi vai trò nhanh phục vụ kiểm thử',
      exceptionFlow: 'Sai thông tin, truy cập trái quyền (403)',
      inputStatus: 'Chưa xác thực',
      outputStatus: 'Phiên làm việc vai trò được kích hoạt',
      notifications: 'Nhật ký đăng nhập ghi nhận vào Audit Log',
      xorGate: '-',
    },
    {
      id: 'UC.02',
      name: 'Tra cứu hồ sơ bằng CCCD hoặc SĐT',
      actor: 'Bệnh nhân, Hệ thống',
      uiComponent: 'Module Tiếp đón Bệnh nhân - Tab Đăng ký',
      preCondition: 'Bệnh nhân có số CCCD (12 số) hoặc SĐT (10 số)',
      mainFlow: '1. Nhập CCCD/SĐT -> 2. Tìm thấy hồ sơ -> 3. Hiển thị thông tin che bớt và lịch sử -> 4. Tạo lượt khám',
      altFlow: 'Chưa có hồ sơ (G1 = Không) -> Mở biểu mẫu tạo mới hồ sơ bệnh nhân',
      exceptionFlow: 'Sai định dạng 12 số CCCD / 10 số SĐT -> Báo lỗi chặn gửi',
      inputStatus: 'Chưa có lượt khám',
      outputStatus: 'Visit: registered',
      notifications: 'Hệ thống chuẩn bị khung khai báo triệu chứng',
      xorGate: 'G1 (Đã có hồ sơ?)',
    },
    {
      id: 'UC.03',
      name: 'Khai triệu chứng và nhận đề xuất phân luồng',
      actor: 'Bệnh nhân, AI Workflow Orchestrator',
      uiComponent: 'Module Khai báo Triệu chứng & Chatbot AI',
      preCondition: 'Lượt khám ở trạng thái registered',
      mainFlow: '1. Chat triệu chứng -> 2. Tóm tắt cấu trúc -> 3. Kiểm tra nguy hiểm (G2=K) -> 4. Khớp chuyên khoa (G3=Có) -> 5. Đề xuất khoa & ưu tiên',
      altFlow: 'G2 = Có: Phát hiện đau thắt ngực, khó thở -> Cờ khẩn cấp, Ưu tiên 1\nG3 = Không: Triệu chứng mơ hồ -> Cần phân luồng thủ công',
      exceptionFlow: 'Mô tả quá ngắn (<5 ký tự) -> Yêu cầu mô tả thêm; Lỗi AI -> Chuyển lễ tân',
      inputStatus: 'Visit: registered',
      outputStatus: 'Visit: pending_triage hoặc pending_emergency_eval',
      notifications: 'Gửi yêu cầu duyệt đến Lễ tân; Cảnh báo đỏ nếu ca khẩn cấp',
      xorGate: 'G2 (Nguy hiểm?), G3 (Có đề xuất?)',
    },
    {
      id: 'UC.04',
      name: 'Đánh giá ca khẩn',
      actor: 'Lễ tân, Hệ thống',
      uiComponent: 'Dashboard Lễ tân - Banner đỏ Cảnh báo Ca khẩn cấp',
      preCondition: 'Có ca mang cờ khẩn chờ đánh giá (G2 = Có)',
      mainFlow: '1. Lễ tân mở cảnh báo ca khẩn -> 2. Xem tóm tắt -> 3. Xác nhận khẩn -> 4. Đưa thẳng vào đầu hàng (không cần slot)',
      altFlow: 'Không khẩn -> Chọn "Hạ mức", nhập lý do, chuyển duyệt thường',
      exceptionFlow: 'Nhắc lại cảnh báo sau 2 phút nếu chưa xử lý',
      inputStatus: 'Visit: pending_emergency_eval',
      outputStatus: 'Visit: approved (Ưu tiên 1) -> Đầu hàng khám',
      notifications: 'Báo động đỏ cho Bác sĩ chuyên khoa & BN được tiếp nhận ngay',
      xorGate: 'G2 (Xác nhận khẩn)',
    },
    {
      id: 'UC.05',
      name: 'Duyệt đề xuất, phân luồng và cấp khung giờ, mã QR',
      actor: 'Lễ tân, Hệ thống, Bệnh nhân',
      uiComponent: 'Dashboard Lễ tân - Bảng Duyệt phân luồng & Cấp lịch',
      preCondition: 'Có lượt khám ở trạng thái pending_triage',
      mainFlow: '1. Xem đề xuất AI -> 2. Nhấn Duyệt -> 3. Cấp khung giờ gần nhất còn chỗ (BR06) & cấp mã QR -> 4. Chuyển Đã duyệt',
      altFlow: 'Đề xuất không phù hợp (G4=K) -> Lễ tân đổi khoa/ưu tiên kèm lý do\nKhoa hết chỗ -> Cấp khung giờ tiếp theo',
      exceptionFlow: 'Thiếu lý do khi điều chỉnh -> Bắt buộc nhập lý do',
      inputStatus: 'Visit: pending_triage',
      outputStatus: 'Visit: approved, tạo QR Code & Slot time',
      notifications: 'Gửi lịch khám, phòng khám và mã QR điện tử cho bệnh nhân',
      xorGate: 'G3, G4 (Đề xuất phù hợp?)',
    },
    {
      id: 'UC.06',
      name: 'Check-in tại bệnh viện',
      actor: 'Bệnh nhân, Lễ tân, Hệ thống',
      uiComponent: 'Kiosk / Quầy Check-in (Quét mã QR hoặc nhập CCCD)',
      preCondition: 'Lượt khám ở trạng thái approved',
      mainFlow: '1. Quét QR -> 2. Kiểm tra mã hợp lệ, chưa dùng -> 3. Đúng khung giờ (G5=Có) -> 4. Cấp STT, vào hàng đợi',
      altFlow: 'Đến muộn quá 15p (G5=Không) -> Lùi lượt xếp sau\nĐến quá sớm (>30p) -> Từ chối check-in, hẹn giờ mở\nCa khẩn -> Vào thẳng đầu hàng',
      exceptionFlow: 'Mã QR đã dùng hoặc đã hủy -> Từ chối check-in',
      inputStatus: 'Visit: approved',
      outputStatus: 'Visit: checked_in, QueueItem: waiting',
      notifications: 'Thông báo STT và thời gian chờ ước tính cho bệnh nhân',
      xorGate: 'G5 (Đúng khung giờ?)',
    },
    {
      id: 'UC.07',
      name: 'Theo dõi hàng đợi và nhận thông báo',
      actor: 'Bệnh nhân, Hệ thống',
      uiComponent: 'Cổng Bệnh nhân - Màn hình Tra cứu Trạng thái Hàng đợi',
      preCondition: 'Bệnh nhân đã check-in vào hàng đợi',
      mainFlow: '1. Mở màn hình theo dõi -> 2. Xem vị trí và số người phía trước -> 3. Nhận thông báo "Sắp đến lượt" khi còn ≤ 3 người',
      altFlow: 'Vị trí thay đổi do có ca cấp cứu chen đầu hàng -> Cập nhật giải thích',
      exceptionFlow: 'Mất kết nối mạng -> Giữ dữ liệu lần cập nhật gần nhất',
      inputStatus: 'QueueItem: waiting',
      outputStatus: 'Thông tin hàng đợi cập nhật thời gian thực',
      notifications: 'Thông báo nhắc nhở khi còn ≤ 3 người (BR10)',
      xorGate: '-',
    },
    {
      id: 'UC.08',
      name: 'Gọi số vào khám và xử lý vắng mặt',
      actor: 'Bác sĩ, Bệnh nhân, Hệ thống',
      uiComponent: 'Màn hình Phòng khám Bác sĩ & Bảng điện tử sảnh chờ',
      preCondition: 'Có bệnh nhân đang chờ trong hàng đợi',
      mainFlow: '1. Bác sĩ nhấn Gọi số tiếp theo -> 2. Hệ thống gọi STT ưu tiên -> 3. BN có mặt (G6=Có) -> 4. Bắt đầu khám lâm sàng',
      altFlow: 'BN vắng mặt quá 3 phút (G6=K) -> Đánh dấu Bỏ lượt, gọi người tiếp theo\nBN bỏ lượt quay lại -> Lễ tân hỗ trợ đăng ký lại 1 lần (BR11), xếp cuối hàng',
      exceptionFlow: 'Hàng đợi trống -> Hiển thị thông báo không có bệnh nhân chờ',
      inputStatus: 'QueueItem: waiting -> calling',
      outputStatus: 'Visit: in_consultation (hoặc missed)',
      notifications: 'Loa/Màn hình gọi số hiển thị STT và tên phòng khám',
      xorGate: 'G6 (BN có mặt đúng giờ?)',
    },
    {
      id: 'UC.09',
      name: 'Khám bệnh và tạo chỉ định cận lâm sàng',
      actor: 'Bác sĩ, Hệ thống',
      uiComponent: 'Phòng Bác sĩ - Bệnh án điện tử & Phiếu chỉ định',
      preCondition: 'Lượt khám đang ở in_consultation',
      mainFlow: '1. Khám lâm sàng -> 2. Cần cận lâm sàng (G7=Có) -> 3. Chọn các dịch vụ độc lập (XN, X-Quang, Siêu âm) -> 4. Tạo phiếu chỉ định điện tử',
      altFlow: 'G7 = Không cần CLS -> Chuyển thẳng sang bước kết luận và kê đơn (UC.11)',
      exceptionFlow: 'Chưa chọn loại chỉ định -> Cảnh báo yêu cầu chọn ít nhất 1 loại',
      inputStatus: 'Visit: in_consultation',
      outputStatus: 'Visit: pending_paraclinical, ClinicalOrder: ordered',
      notifications: 'Chuyển phiếu điện tử đến Khoa Cận lâm sàng & hướng dẫn BN phòng thực hiện',
      xorGate: 'G7 (Cần cận lâm sàng?)',
    },
    {
      id: 'UC.10',
      name: 'Thực hiện cận lâm sàng và nhập kết quả',
      actor: 'KTV Cận lâm sàng, Bệnh nhân, Hệ thống',
      uiComponent: 'Module Khoa Cận lâm sàng (BPMN Inclusive Gateway)',
      preCondition: 'Có phiếu chỉ định ở trạng thái ordered',
      mainFlow: '1. Tiếp nhận bệnh nhân/mẫu -> 2. Thực hiện kỹ thuật -> 3. Nhập kết quả -> 4. Kiểm tra hợp lệ (G8=Có) -> 5. Hoàn tất phiếu',
      altFlow: 'G8 = Không hợp lệ (mẫu hỏng/kết quả sai lệch) -> Đánh dấu Cần làm lại, nhập lý do, chỉ làm lại phiếu bị lỗi (xử lý độc lập)',
      exceptionFlow: 'Nhập sai định dạng số liệu -> Cảnh báo lỗi định dạng ngay tại ô nhập',
      inputStatus: 'ClinicalOrder: ordered -> in_progress',
      outputStatus: 'ClinicalOrder: completed (hoặc invalid)',
      notifications: 'Thông báo Bác sĩ khi TẤT CẢ chỉ định của BN đã hoàn tất hợp lệ',
      xorGate: 'G8 (Kết quả hợp lệ?)',
    },
    {
      id: 'UC.11',
      name: 'Xem kết quả và kết luận',
      actor: 'Bác sĩ, Hệ thống, Bệnh nhân',
      uiComponent: 'Phòng Bác sĩ - Bảng tổng hợp kết quả & Kết luận',
      preCondition: 'Tất cả chỉ định đã hoàn tất hoặc không cần CLS',
      mainFlow: '1. Xem kết quả CLS -> 2. Đủ thông tin (G9=Có) -> 3. Nhập chẩn đoán xác định & đơn thuốc -> 4. Kết luận',
      altFlow: 'G9 = Chưa đủ thông tin -> Bác sĩ chỉ định bổ sung thêm dịch vụ mới',
      exceptionFlow: 'Còn chỉ định chưa có kết quả -> Chặn kết luận (BR14), chỉ cho phép khi có lý do hủy',
      inputStatus: 'Visit: paraclinical_completed',
      outputStatus: 'Visit: pending_payment, Invoice được tự động tạo',
      notifications: 'Thông báo Quầy thanh toán tiếp nhận viện phí; Gửi kết luận cho BN',
      xorGate: 'G9 (Đủ thông tin để kết luận?)',
    },
    {
      id: 'UC.12',
      name: 'Theo dõi và xử lý chỉ định quá hạn',
      actor: 'KTV Cận lâm sàng, Hệ thống, Bác sĩ, Bệnh nhân',
      uiComponent: 'Module Cận lâm sàng - Bộ đếm Timer 8 giờ (Event Gateway)',
      preCondition: 'Phiếu chỉ định vượt hạn xử lý mà chưa có kết quả',
      mainFlow: '1. Timer 8h kích hoạt -> 2. Gắn cờ Quá hạn -> 3. Gửi cảnh báo chậm trễ -> 4. KTV nhập nguyên nhân -> 5. Chọn Tiếp tục xử lý & đặt hạn mới',
      altFlow: 'G10 = Không thể tiếp tục -> Hủy phiếu chỉ định, thông báo Bác sĩ để kết luận hoặc chỉ định thay thế',
      exceptionFlow: 'Lỗi gửi thông báo -> Ghi nhật ký lỗi, hỗ trợ nhân viên liên hệ trực tiếp',
      inputStatus: 'ClinicalOrder: in_progress',
      outputStatus: 'ClinicalOrder: delayed -> gia hạn hoặc cancelled',
      notifications: 'Gửi thông báo trễ hẹn cho Bệnh nhân & cảnh báo Bác sĩ điều trị',
      xorGate: 'G10 (Có thể tiếp tục xử lý?)',
    },
    {
      id: 'UC.13',
      name: 'Nhập dữ liệu từ file CSV/JSON',
      actor: 'Admin',
      uiComponent: 'Trung tâm Giám sát & Quản trị - Tab Nạp dữ liệu',
      preCondition: 'Admin đăng nhập, file đúng định dạng',
      mainFlow: '1. Chọn file JSON/CSV -> 2. Kiểm tra tính hợp lệ từng dòng -> 3. Xem trước -> 4. Nạp vào cơ sở dữ liệu',
      altFlow: 'Dòng trùng CCCD -> Chọn Bỏ qua hoặc Cập nhật ghi đè',
      exceptionFlow: 'Thiếu cột bắt buộc / File rỗng -> Từ chối và nêu rõ danh sách cột thiếu',
      inputStatus: 'File ngoài',
      outputStatus: 'Dữ liệu được tích hợp vào LocalStorage',
      notifications: 'Báo cáo số dòng nạp thành công và danh sách lỗi',
      xorGate: '-',
    },
    {
      id: 'UC.14',
      name: 'Cấu hình tham số và đồng hồ giả lập',
      actor: 'Admin',
      uiComponent: 'Trung tâm Giám sát - Cấu hình tham số & Time Warp',
      preCondition: 'Admin đăng nhập',
      mainFlow: '1. Xem tham số hiện tại -> 2. Chỉnh sửa dung sai, hạn CLS, thời gian khám -> 3. Điều chỉnh đồng hồ giả lập (+15p, +30p, +8h) -> 4. Lưu',
      altFlow: 'Chọn "Đặt lại mặc định" hoặc "Reset dữ liệu demo"',
      exceptionFlow: 'Nhập giá trị âm hoặc ký tự chữ -> Báo lỗi chặn lưu (BR19)',
      inputStatus: 'SystemConfig hiện tại',
      outputStatus: 'SystemConfig mới áp dụng toàn hệ thống',
      notifications: 'Ghi nhật ký thay đổi cấu hình vào Audit Log (BR17)',
      xorGate: '-',
    },
    {
      id: 'UC.15',
      name: 'Hủy lượt khám bệnh',
      actor: 'Bệnh nhân, Lễ tân, Hệ thống',
      uiComponent: 'Cổng Bệnh nhân (Nút Hủy lịch) & Dashboard Lễ tân',
      preCondition: 'Lượt khám chưa hoàn thành điều trị',
      mainFlow: '1. Bệnh nhân/Lễ tân gửi yêu cầu hủy -> 2. Nhập lý do -> 3. Hệ thống xác nhận -> 4. Hủy mã QR, xóa khỏi hàng đợi, giải phóng slot',
      altFlow: 'Bệnh nhân đổi ý -> Hủy thao tác',
      exceptionFlow: 'Lượt khám đã hoàn tất thanh toán -> Chặn hủy',
      inputStatus: 'Visit: approved hoặc checked_in',
      outputStatus: 'Visit: cancelled, QR vô hiệu hóa',
      notifications: 'Thông báo xác nhận hủy thành công cho BN và ghi Audit Log',
      xorGate: '-',
    },
    {
      id: 'UC.16',
      name: 'Thanh toán viện phí và xuất Hóa đơn điện tử',
      actor: 'Quầy thu ngân, Bệnh nhân, Hệ thống',
      uiComponent: 'Module Quầy thanh toán & Hóa đơn điện tử',
      preCondition: 'Bác sĩ đã hoàn tất kết luận chuyên môn (pending_payment)',
      mainFlow: '1. Tiếp nhận hồ sơ -> 2. Tính tổng viện phí & tỷ lệ BHYT (ví dụ 80%) -> 3. Xác nhận thu phần BN trả -> 4. Phát hành Hóa đơn điện tử',
      altFlow: 'BHYT chi trả 100% (BN trả 0đ) -> Bỏ qua bước thu tiền, tự động duyệt và phát hành hóa đơn ngay',
      exceptionFlow: 'Thanh toán không đủ -> Báo lỗi còn nợ phí',
      inputStatus: 'Invoice: pending, Visit: pending_payment',
      outputStatus: 'Invoice: paid, Visit: completed',
      notifications: 'Gửi Hóa đơn điện tử mô phỏng cho BN, cho phép xem và in hóa đơn',
      xorGate: 'Cổng BHYT (Chi trả 100% hay còn phần phải thu?)',
    },
  ];

  const filteredUseCases = useCases.filter(uc => {
    if (filterXor === 'all') return true;
    if (filterXor === 'xor') return uc.xorGate !== '-';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl max-h-[90vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150 border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-100 text-teal-800 rounded-lg">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">Bảng Đối Chiếu Nghiệp Vụ Use Case & BPMN (System Analyst Matrix)</h3>
                <span className="text-[10px] bg-teal-50 text-teal-700 border border-teal-200 px-2 py-0.5 rounded font-mono font-semibold">16 Use Cases</span>
              </div>
              <p className="text-xs text-slate-500">Đối chiếu 100% đặc tả MIS3047, BPMN To-Be và 10 Cổng rẽ nhánh XOR/Inclusive/Event Gateway</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Note on BPMN & UC reconciliation */}
        <div className="px-6 py-3 bg-blue-50/70 border-b border-blue-100 text-xs text-blue-900 flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong>Ghi chú Đối chiếu Nghiệp vụ (System Analyst):</strong> Hệ thống thực hiện đúng phạm vi 5 nhóm chức năng chính (Bỏ qua quầy thuốc và nhắc tái khám). 
            Hai cải tiến lớn so với sơ đồ cũ: <strong>(1)</strong> Ca khẩn cấp được lễ tân xác nhận vào đầu hàng ngay không cần slot; <strong>(2)</strong> Bệnh nhân bỏ lượt được đăng ký lại một lần xếp cuối hàng.
            Cận lâm sàng tuân thủ Inclusive Gateway (các phiếu độc lập, chỉ tổng hợp khi đã đủ kết quả hoặc hủy có lý do).
          </div>
        </div>

        {/* Filter bar */}
        <div className="px-6 py-2.5 border-b border-slate-200 bg-white flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-500 font-medium">Lọc bảng:</span>
            <button
              onClick={() => setFilterXor('all')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${filterXor === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              Tất cả Use Case (16)
            </button>
            <button
              onClick={() => setFilterXor('xor')}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${filterXor === 'xor' ? 'bg-teal-700 text-white' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              Chỉ các cổng rẽ nhánh BPMN (G1 - G10)
            </button>
          </div>
        </div>

        {/* Table content */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-slate-700 font-semibold uppercase text-[11px] tracking-wider z-10">
              <tr>
                <th className="py-3 px-3 w-16">ID</th>
                <th className="py-3 px-3 w-48">Tên Use Case & Cổng</th>
                <th className="py-3 px-3 w-36">Actor</th>
                <th className="py-3 px-3 w-44">Chức năng Giao diện</th>
                <th className="py-3 px-3">Luồng chính & Luồng thay thế / Ngoại lệ</th>
                <th className="py-3 px-3 w-32">Trạng thái Vào/Ra</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-slate-700">
              {filteredUseCases.map((uc) => (
                <tr key={uc.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-blue-700 align-top">
                    {uc.id}
                  </td>
                  <td className="py-3 px-3 align-top">
                    <p className="font-bold text-slate-900 leading-snug">{uc.name}</p>
                    {uc.xorGate !== '-' && (
                      <span className="inline-block mt-1 font-mono text-[10px] bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded font-semibold">
                        {uc.xorGate}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-slate-600 text-[11px] align-top">
                    {uc.actor}
                  </td>
                  <td className="py-3 px-3 text-teal-800 font-medium text-[11px] align-top">
                    {uc.uiComponent}
                  </td>
                  <td className="py-3 px-3 space-y-1 align-top text-[11px] leading-relaxed">
                    <div><strong className="text-slate-800">Chính:</strong> {uc.mainFlow}</div>
                    <div className="text-blue-900"><strong className="text-blue-700">Thay thế:</strong> {uc.altFlow}</div>
                    <div className="text-rose-900"><strong className="text-rose-700">Ngoại lệ:</strong> {uc.exceptionFlow}</div>
                  </td>
                  <td className="py-3 px-3 font-mono text-[10px] space-y-1 align-top">
                    <div><span className="text-slate-400">Vào:</span> <span className="bg-slate-100 px-1 rounded text-slate-700">{uc.inputStatus}</span></div>
                    <div><span className="text-slate-400">Ra:</span> <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 px-1 rounded font-semibold">{uc.outputStatus}</span></div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
