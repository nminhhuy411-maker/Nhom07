import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { ClinicalOrder, LabOrderStatus, LabResult } from '../../types';
import { 
  FlaskConical, 
  Clock, 
  CheckCircle2, 
  Check,
  AlertTriangle, 
  AlertCircle, 
  RefreshCw, 
  X, 
  Search, 
  Filter, 
  FileText, 
  RotateCcw,
  Zap
} from 'lucide-react';

export const ParaclinicalModule: React.FC = () => {
  const { 
    labOrders, 
    visits, 
    patients, 
    receiveLabOrder, 
    saveLabResult, 
    validateLabResult, 
    redoLabOrder, 
    handleDelayedLabOrder, 
    triggerDemoSimulatedLabTimeout,
    markLabOrderUnprocessable,
    quickCompleteLabOrder,
    activeAccount 
  } = useHospital();

  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // Result entry modal
  const [isResultModalOpen, setIsResultModalOpen] = useState(false);
  const [resultSummary, setResultSummary] = useState('');
  const [technicianNotes, setTechnicianNotes] = useState('');
  const [resultParam1, setResultParam1] = useState('Chỉ số chính');
  const [resultValue1, setResultValue1] = useState('Bình thường');
  const [isParam1Abnormal, setIsParam1Abnormal] = useState(false);

  // Validation modal (G8)
  const [isValidModalOpen, setIsValidModalOpen] = useState(false);
  const [invalidReason, setInvalidReason] = useState('Mẫu máu bị vỡ hồng cầu (tán huyết)');

  // Delay resolution modal (G10)
  const [isDelayModalOpen, setIsDelayModalOpen] = useState(false);
  const [delayReasonInput, setDelayReasonInput] = useState('Thiếu thuốc thử đặc hiệu / Máy đang bảo trì');
  const [extendMinutes, setExtendMinutes] = useState(60);

  const selectedOrder = labOrders.find(o => o.id === selectedOrderId);
  const selectedVisit = selectedOrder ? visits.find(v => v.id === selectedOrder.visitId) : null;
  const selectedPatient = selectedOrder ? patients.find(p => p.id === selectedOrder.patientId) : null;

  // KPIs
  const totalOrders = labOrders.length;
  const orderedOrders = labOrders.filter(o => o.status === 'ordered');
  const inProgressOrders = labOrders.filter(o => o.status === 'in_progress');
  const resultReadyOrders = labOrders.filter(o => o.status === 'result_ready');
  const invalidOrders = labOrders.filter(o => o.status === 'invalid');
  const delayedOrders = labOrders.filter(o => o.status === 'delayed');
  const completedOrders = labOrders.filter(o => o.status === 'completed');

  const filteredOrders = labOrders.filter(o => {
    const patient = patients.find(p => p.id === o.patientId);
    const matchesSearch = 
      o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.serviceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (patient && patient.fullName.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = filterType === 'all' || o.serviceType === filterType;
    const matchesStatus = filterStatus === 'all' || o.status === filterStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const handleOpenEnterResult = (order: ClinicalOrder) => {
    setSelectedOrderId(order.id);
    if (order.result) {
      setResultSummary(order.result.summary);
      setTechnicianNotes(order.result.technicianNotes);
    } else {
      setResultSummary(
        order.serviceType === 'lab_test' ? 'Số lượng bạch cầu, hồng cầu và men gan trong giới hạn theo dõi.' :
        order.serviceType === 'xray' ? 'Hình ảnh tim phổi bình thường trên phim thẳng, không thấy thâm nhiễm.' :
        'Nhu mô gan đồng nhất, không sỏi mật, thận hai bên bình thường.'
      );
      setTechnicianNotes('Kỹ thuật viên thực hiện đúng quy trình chuyên môn chuẩn.');
      setResultParam1(order.serviceType === 'lab_test' ? 'RBC' : order.serviceType === 'xray' ? 'Phổi' : 'Gan');
      setResultValue1(order.serviceType === 'lab_test' ? '4.8' : 'Bình thường');
      setIsParam1Abnormal(false);
    }
    setIsResultModalOpen(true);
  };

  const handleSaveResult = () => {
    if (!selectedOrderId) return;
    const nowStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });

    const newResult: LabResult = {
      summary: resultSummary,
      details: [
        { param: resultParam1, value: resultValue1, unit: '', referenceRange: 'Chuẩn', isAbnormal: isParam1Abnormal }
      ],
      technicianNotes,
      performedBy: activeAccount.name,
      completedAt: nowStr,
      isValidated: false,
    };

    saveLabResult(selectedOrderId, newResult);
    setIsResultModalOpen(false);
  };

  const handleOpenValidate = (order: ClinicalOrder) => {
    setSelectedOrderId(order.id);
    setInvalidReason('Mẫu máu bị tán huyết hoặc bệnh nhân chưa chuẩn bị đúng yêu cầu');
    setIsValidModalOpen(true);
  };

  const handleOpenDelayResolution = (order: ClinicalOrder) => {
    setSelectedOrderId(order.id);
    setDelayReasonInput('Đầu dò đang hiệu chuẩn hoặc thiếu hóa chất xét nghiệm đột xuất');
    setIsDelayModalOpen(true);
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 bg-teal-50 border border-teal-200 px-2.5 py-0.5 rounded-md">
              Khoa Cận Lâm Sàng & Thăm Dò Chức Năng
            </span>
            <span className="text-xs text-slate-400">· Xét nghiệm, X-Quang & Siêu âm</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Quản Lý & Xử Lý Phiếu Cận Lâm Sàng
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Xử lý song song các chỉ định xét nghiệm, chẩn đoán hình ảnh, kiểm tra tính hợp lệ của mẫu phẩm và theo dõi hạn trả kết quả
          </p>
          <div className="flex flex-wrap items-center gap-2 mt-2 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
            <span className="inline-flex items-center gap-1 font-bold text-teal-800 bg-teal-50 px-2.5 py-0.5 rounded border border-teal-200">
              <Zap className="w-3 h-3 text-teal-600" /> Quy trình tiêu chuẩn:
            </span>
            <span>Bình thường trả kết quả nhanh ngẫu nhiên <strong>~5 phút</strong> (3 - 6 phút). Chỉ khi gặp sự cố kỹ thuật không xử lý được mới chuyển sang hạn <strong>8 tiếng (480 phút)</strong>.</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono text-slate-400 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200">
            KTV trực: <strong>{activeAccount.name}</strong>
          </span>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Tổng số phiếu</span>
          <p className="text-xl font-bold font-mono text-slate-800 mt-1">{totalOrders}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Chờ tiếp nhận</span>
          <p className="text-xl font-bold font-mono text-blue-600 mt-1">{orderedOrders.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Đang thực hiện</span>
          <p className="text-xl font-bold font-mono text-indigo-600 mt-1">{inProgressOrders.length}</p>
        </div>
        <div className={`p-3.5 border rounded-xl shadow-xs ${invalidOrders.length > 0 ? 'bg-rose-50 border-rose-300' : 'bg-white border-slate-200'}`}>
          <span className="text-[11px] text-rose-700 font-bold">Cần lấy lại mẫu</span>
          <p className="text-xl font-bold font-mono text-rose-700 mt-1">{invalidOrders.length}</p>
        </div>
        <div className={`p-3.5 border rounded-xl shadow-xs ${delayedOrders.length > 0 ? 'bg-amber-50 border-amber-300 animate-pulse' : 'bg-white border-slate-200'}`}>
          <span className="text-[11px] text-amber-700 font-bold">Cảnh báo quá hạn</span>
          <p className="text-xl font-bold font-mono text-amber-700 mt-1">{delayedOrders.length}</p>
        </div>
        <div className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-xs">
          <span className="text-[11px] text-slate-400 font-medium">Đã hoàn thành</span>
          <p className="text-xl font-bold font-mono text-emerald-600 mt-1">{completedOrders.length}</p>
        </div>
      </div>

      {/* Delayed Alert Banner if any */}
      {delayedOrders.length > 0 && (
        <div className="bg-amber-500 text-slate-950 rounded-2xl p-4 shadow-sm border border-amber-600 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-950 text-amber-400 rounded-xl">
              <Clock className="w-6 h-6 animate-spin" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-black text-sm uppercase tracking-wide">
                  CẢNH BÁO TIẾN ĐỘ: CÓ {delayedOrders.length} CHỈ ĐỊNH VƯỢT QUÁ THỜI HẠN TIÊU CHUẨN
                </h4>
              </div>
              <p className="text-xs text-slate-900 mt-0.5">
                Chỉ định vượt quá thời hạn quy định. Hệ thống đã đồng bộ trạng thái trễ hẹn đến Bác sĩ và Bệnh nhân. Kỹ thuật viên cần ghi nhận nguyên nhân và chọn phương án xử lý.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {delayedOrders.map(dOrder => (
              <button
                key={dOrder.id}
                onClick={() => handleOpenDelayResolution(dOrder)}
                className="px-3.5 py-2 bg-slate-950 text-white hover:bg-slate-900 text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                Xử lý phiếu: {dOrder.id} →
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Filters Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
          <Filter className="w-4 h-4 text-slate-400 shrink-0" />
          <span className="text-slate-400 font-medium">Dịch vụ:</span>
          {['all', 'lab_test', 'xray', 'ultrasound'].map(t => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                filterType === t ? 'bg-teal-700 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {t === 'all' ? 'Tất cả' : t === 'lab_test' ? 'Xét nghiệm' : t === 'xray' ? 'X-Quang' : 'Siêu âm'}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm theo Mã phiếu, BN, Dịch vụ..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 text-xs focus:ring-1 focus:ring-teal-500 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Mã Phiếu</th>
                <th className="py-3 px-3">Bệnh nhân</th>
                <th className="py-3 px-3">Dịch vụ chỉ định</th>
                <th className="py-3 px-3">Phòng thực hiện</th>
                <th className="py-3 px-3">Thời gian tạo</th>
                <th className="py-3 px-3">Hạn xử lý (Timer)</th>
                <th className="py-3 px-3">Trạng thái</th>
                <th className="py-3 px-4 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    Không tìm thấy phiếu cận lâm sàng nào phù hợp.
                  </td>
                </tr>
              ) : (
                filteredOrders.map(order => {
                  const patient = patients.find(p => p.id === order.patientId);

                  return (
                    <tr 
                      key={order.id} 
                      className={`hover:bg-slate-50/70 transition-colors ${
                        order.status === 'delayed' ? 'bg-amber-50/40' :
                        order.status === 'invalid' ? 'bg-rose-50/40' : ''
                      }`}
                    >
                      <td className="py-3 px-4 whitespace-nowrap font-mono">
                        <span className="font-bold text-slate-900 block">{order.id}</span>
                        <span className="text-[10px] text-slate-400">{order.visitId}</span>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className="font-bold text-slate-800 block">{patient?.fullName}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{patient?.id} · {patient?.gender}</span>
                      </td>

                      <td className="py-3 px-3">
                        <span className="font-bold text-teal-800 block">{order.serviceName}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {order.serviceType === 'lab_test' ? 'Xét nghiệm' : order.serviceType === 'xray' ? 'X-Quang' : 'Siêu âm'}
                        </span>
                      </td>

                      <td className="py-3 px-3 text-slate-600 max-w-[150px] truncate" title={order.roomName}>
                        {order.roomName}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap font-mono text-[11px] text-slate-500">
                        {order.orderTime}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap font-mono text-[11px]">
                        {order.isDelayed || order.status === 'delayed' ? (
                          <span className="text-rose-700 font-bold bg-rose-50 border border-rose-200 px-2 py-0.5 rounded text-[11px] inline-flex items-center gap-1 shadow-2xs">
                            <Clock className="w-3 h-3 text-rose-600 shrink-0" /> Sự cố: Chờ 8 tiếng
                          </span>
                        ) : (
                          <span className="text-teal-700 font-bold bg-teal-50 border border-teal-200 px-2 py-0.5 rounded text-[11px] inline-flex items-center gap-1 shadow-2xs">
                            <Zap className="w-3 h-3 text-teal-600 shrink-0" /> ~{order.deadlineMinutes || 5} phút (Nhanh)
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <span className={`inline-block px-2.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                          order.status === 'completed' ? 'bg-emerald-100 text-emerald-800' :
                          order.status === 'invalid' ? 'bg-rose-100 text-rose-800 animate-pulse' :
                          order.status === 'delayed' ? 'bg-rose-100 text-rose-800 border border-rose-200 animate-pulse' :
                          order.status === 'result_ready' ? 'bg-blue-100 text-blue-800' :
                          order.status === 'in_progress' ? 'bg-indigo-100 text-indigo-800' :
                          order.status === 'cancelled' ? 'bg-slate-200 text-slate-700' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {order.status === 'completed' ? 'Hoàn thành' :
                           order.status === 'invalid' ? 'Không hợp lệ (Làm lại)' :
                           order.status === 'delayed' ? 'Sự cố không xử lý được (8h)' :
                           order.status === 'result_ready' ? 'Đã có kết quả' :
                           order.status === 'in_progress' ? 'Đang thực hiện (~5p)' :
                           order.status === 'ordered' ? 'Mới chỉ định' : order.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {order.status === 'ordered' && (
                            <>
                              <button
                                onClick={() => receiveLabOrder(order.id)}
                                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs cursor-pointer"
                              >
                                Nhận phiếu
                              </button>
                              <button
                                onClick={() => {
                                  receiveLabOrder(order.id);
                                  quickCompleteLabOrder(order.id);
                                }}
                                title="Nhận và hoàn tất kết quả nhanh trong ~5 phút"
                                className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                              >
                                <Zap className="w-3.5 h-3.5" /> Trả KQ nhanh (5p)
                              </button>
                            </>
                          )}

                          {order.status === 'in_progress' && (
                            <>
                              <button
                                onClick={() => handleOpenEnterResult(order)}
                                className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs cursor-pointer"
                              >
                                Nhập kết quả
                              </button>
                              <button
                                onClick={() => quickCompleteLabOrder(order.id)}
                                title="Trả kết quả nhanh mô phỏng ~5 phút"
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                              >
                                <Zap className="w-3.5 h-3.5" /> Trả nhanh (5p)
                              </button>
                              {/* Trigger unprocessable 8h case */}
                              <button
                                onClick={() => markLabOrderUnprocessable(order.id, 'Sự cố thiết bị máy phân tích / Mẫu bất thường không thể xử lý trong 5 phút')}
                                title="Gặp sự cố không thể xử lý kết quả trong 5 phút -> Chuyển sang quy trình xử lý 8 tiếng theo chuẩn BPMN"
                                className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                              >
                                <AlertTriangle className="w-3 h-3 text-rose-600" /> Không xử lý được (8h)
                              </button>
                            </>
                          )}

                          {order.status === 'result_ready' && (
                            <button
                              onClick={() => handleOpenValidate(order)}
                              className="px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" /> Kiểm tra hợp lệ
                            </button>
                          )}

                          {order.status === 'invalid' && (
                            <button
                              onClick={() => redoLabOrder(order.id)}
                              className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                            >
                              <RotateCcw className="w-3.5 h-3.5" /> Yêu cầu lấy mẫu lại
                            </button>
                          )}

                          {order.status === 'delayed' && (
                            <button
                              onClick={() => handleOpenDelayResolution(order)}
                              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-bold rounded-lg transition-colors shadow-2xs flex items-center gap-1 cursor-pointer"
                            >
                              <Clock className="w-3.5 h-3.5" /> Khắc phục sự cố 8h
                            </button>
                          )}

                          {order.status === 'completed' && (
                            <button
                              onClick={() => handleOpenEnterResult(order)}
                              className="px-2 py-1 text-slate-500 hover:text-slate-800 text-[11px] font-medium cursor-pointer"
                            >
                              Xem kết quả
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: ENTER LAB RESULT */}
      {isResultModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-xl w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h4 className="font-extrabold text-slate-900 text-base">
                  Nhập Kết Quả Cận Lâm Sàng: {selectedOrder.serviceName}
                </h4>
                <p className="text-xs text-slate-500 font-mono">Phiếu: {selectedOrder.id} · Bệnh nhân: {selectedPatient?.fullName}</p>
              </div>
              <button onClick={() => setIsResultModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Mô tả kết quả tổng quát *</label>
                <textarea
                  rows={3}
                  value={resultSummary}
                  onChange={e => setResultSummary(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 font-medium text-xs focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Tên thông số kỹ thuật</label>
                  <input
                    type="text"
                    value={resultParam1}
                    onChange={e => setResultParam1(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Giá trị đo lường</label>
                  <input
                    type="text"
                    value={resultValue1}
                    onChange={e => setResultValue1(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="abnormalCheck"
                  checked={isParam1Abnormal}
                  onChange={e => setIsParam1Abnormal(e.target.checked)}
                  className="text-rose-600 rounded"
                />
                <label htmlFor="abnormalCheck" className="text-slate-700 font-medium cursor-pointer">
                  Đánh dấu chỉ số bất thường (cảnh báo bác sĩ)
                </label>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Ghi chú của Kỹ thuật viên</label>
                <input
                  type="text"
                  value={technicianNotes}
                  onChange={e => setTechnicianNotes(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setIsResultModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Hủy
              </button>
              <button
                onClick={handleSaveResult}
                className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <Check className="w-4 h-4" /> Lưu Kết Quả Chuyên Môn
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: VALIDITY CHECK - HỢP LỆ HAY KHÔNG HỢP LỆ */}
      {isValidModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-blue-600" />
                <h4 className="font-extrabold text-slate-900 text-base">Kiểm Tra Tính Hợp Lệ Mẫu & Kết Quả</h4>
              </div>
              <button onClick={() => setIsValidModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Kiểm tra tính hợp lệ của phiếu <strong>{selectedOrder.id}</strong> ({selectedOrder.serviceName}): mẫu phẩm đạt tiêu chuẩn, giá trị đo lường trong khoảng cho phép, không bị tán huyết hoặc lỗi thiết bị.
            </p>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1 text-xs">
              <span className="font-bold text-slate-800">Kết quả sơ bộ:</span>
              <p className="text-slate-600 italic">"{selectedOrder.result?.summary}"</p>
            </div>

            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-700">Nếu KHÔNG hợp lệ, chọn nguyên nhân:</label>
              <select
                value={invalidReason}
                onChange={e => setInvalidReason(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-rose-300 bg-rose-50/50 text-xs text-rose-900 font-medium"
              >
                <option value="Mẫu máu bị vỡ hồng cầu (tán huyết) trong ống nghiệm">Mẫu máu bị tán huyết (vỡ hồng cầu)</option>
                <option value="Bệnh nhân chưa nhịn ăn, lipid máu cao gây đục huyết thanh">Bệnh nhân chưa nhịn ăn, lipid máu đục</option>
                <option value="Phim X-Quang mờ do bệnh nhân chuyển động khi chụp">Phim X-Quang mờ do bệnh nhân chuyển động</option>
                <option value="Đầu dò siêu âm chập chờn, hình ảnh nhiễu không rõ">Hình ảnh siêu âm nhiễu, không đạt chuẩn</option>
              </select>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  validateLabResult(selectedOrder.id, false, invalidReason);
                  setIsValidModalOpen(false);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-colors shadow-2xs"
              >
                Không hợp lệ (Yêu cầu làm lại)
              </button>
              <button
                onClick={() => {
                  validateLabResult(selectedOrder.id, true);
                  setIsValidModalOpen(false);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                ✓ Xác nhận Hợp Lệ (Hoàn thành)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: DELAY RESOLUTION */}
      {isDelayModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 animate-in zoom-in-95 duration-150 border border-amber-300">
            <div className="flex items-center justify-between pb-3 border-b border-amber-100">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-amber-600" />
                <h4 className="font-extrabold text-slate-900 text-base">Xử Lý Phiếu Cận Lâm Sàng Quá Hạn</h4>
              </div>
              <button onClick={() => setIsDelayModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Phiếu <strong>{selectedOrder.id}</strong> ({selectedOrder.serviceName}) đã vượt quá thời hạn tiêu chuẩn. Vui lòng ghi nhận nguyên nhân và đưa ra phương án xử lý:
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Nguyên nhân chậm trễ *</label>
                <textarea
                  rows={2}
                  value={delayReasonInput}
                  onChange={e => setDelayReasonInput(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-300 text-xs focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Gia hạn thêm (phút):</label>
                <input
                  type="number"
                  min={15}
                  max={480}
                  value={extendMinutes}
                  onChange={e => setExtendMinutes(Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-mono text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <button
                onClick={() => {
                  handleDelayedLabOrder(selectedOrder.id, 'cancel', delayReasonInput);
                  setIsDelayModalOpen(false);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition-colors"
              >
                Không thể tiếp tục (Hủy phiếu)
              </button>
              <button
                onClick={() => {
                  handleDelayedLabOrder(selectedOrder.id, 'extend', delayReasonInput, extendMinutes);
                  setIsDelayModalOpen(false);
                }}
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
              >
                Tiếp tục xử lý (Gia hạn)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
