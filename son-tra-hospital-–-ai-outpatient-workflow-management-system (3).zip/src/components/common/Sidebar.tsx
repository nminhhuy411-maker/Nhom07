import React from 'react';
import { useHospital } from '../../context/HospitalContext';
import { 
  MessageSquareHeart, 
  UserCheck2, 
  Tv, 
  Stethoscope, 
  FlaskConical, 
  Receipt, 
  Activity, 
  RotateCcw,
  Sparkles,
  Pill,
  ShieldCheck,
  Lock,
  ChevronRight
} from 'lucide-react';
import { UserRole } from '../../types';

export type NavTab = 
  | 'patient' 
  | 'reception' 
  | 'queue' 
  | 'doctor' 
  | 'paraclinical' 
  | 'pharmacy'
  | 'cashier' 
  | 'admin';

interface SidebarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentTab, onSelectTab }) => {
  const { visits, labOrders, queueItems, invoices, prescriptions, resetDemoData, activeAccount } = useHospital();

  // Counts for badge notifications
  const pendingTriageCount = visits.filter(v => v.status === 'pending_triage' || v.status === 'pending_emergency_eval').length;
  const emergencyCount = visits.filter(v => v.status === 'pending_emergency_eval').length;
  const waitingQueueCount = queueItems.filter(q => q.status === 'waiting' || q.status === 'calling').length;
  const pendingLabCount = labOrders.filter(o => o.status === 'ordered' || o.status === 'in_progress').length;
  const delayedLabCount = labOrders.filter(o => o.status === 'delayed').length;
  const pendingPaymentCount = invoices.filter(i => i.status === 'pending').length;
  const pendingPharmacyCount = prescriptions.filter(p => p.status === 'preparing' || p.status === 'ready').length;

  const allNavItems = [
    {
      id: 'patient' as NavTab,
      label: '1. Chatbot & Khai bệnh',
      sublabel: 'Phân tích triệu chứng & AI Triage',
      icon: MessageSquareHeart,
      allowedRoles: ['admin', 'patient', 'reception', 'doctor'],
    },
    {
      id: 'reception' as NavTab,
      label: '2. Lễ tân & Phân luồng',
      sublabel: 'Duyệt đề xuất, Cấp giờ & Mã QR',
      icon: UserCheck2,
      badge: pendingTriageCount,
      badgeColor: emergencyCount > 0 ? 'bg-red-500 text-white animate-pulse' : 'bg-blue-600 text-white',
      allowedRoles: ['admin', 'reception'],
    },
    {
      id: 'queue' as NavTab,
      label: '3. Check-in & Hàng đợi',
      sublabel: 'Quét QR & Bảng điện tử phòng khám',
      icon: Tv,
      badge: waitingQueueCount,
      badgeColor: 'bg-indigo-600 text-white',
      allowedRoles: ['admin', 'reception', 'doctor', 'patient'],
    },
    {
      id: 'doctor' as NavTab,
      label: '4. Bác sĩ & Khám bệnh',
      sublabel: 'Khám lâm sàng, chỉ định CLS & Kê đơn',
      icon: Stethoscope,
      allowedRoles: ['admin', 'doctor'],
    },
    {
      id: 'paraclinical' as NavTab,
      label: '5. Cận lâm sàng & CĐHA',
      sublabel: 'Xét nghiệm, X-Quang & Siêu âm',
      icon: FlaskConical,
      badge: delayedLabCount > 0 ? delayedLabCount : pendingLabCount,
      badgeColor: delayedLabCount > 0 ? 'bg-amber-500 text-white animate-pulse' : 'bg-teal-600 text-white',
      allowedRoles: ['admin', 'paraclinical', 'doctor'],
    },
    {
      id: 'pharmacy' as NavTab,
      label: '6. Nhà thuốc & Cấp phát',
      sublabel: 'Cấp phát thuốc theo đơn điện tử',
      icon: Pill,
      badge: pendingPharmacyCount,
      badgeColor: 'bg-indigo-600 text-white',
      allowedRoles: ['admin', 'pharmacy', 'doctor'],
    },
    {
      id: 'cashier' as NavTab,
      label: '7. Quầy Thu phí & Viện phí',
      sublabel: 'Tính BHYT & Xuất hóa đơn điện tử',
      icon: Receipt,
      badge: pendingPaymentCount,
      badgeColor: 'bg-emerald-600 text-white',
      allowedRoles: ['admin', 'cashier'],
    },
    {
      id: 'admin' as NavTab,
      label: '8. Quản trị & Giám sát AI',
      sublabel: 'Quản lý tài khoản, Knowledge Base & KPI',
      icon: Activity,
      allowedRoles: ['admin'],
    },
  ];

  // Filter navigation items by active user role:
  // Admin sees all. Others only see permitted items or items relevant to their workflow.
  const visibleNavItems = allNavItems.filter(item => {
    if (activeAccount.role === 'admin') return true;
    return item.allowedRoles.includes(activeAccount.role);
  });

  return (
    <aside className="w-64 bg-[#163A5F] text-slate-200 flex flex-col shrink-0 border-r border-[#12304A] min-h-[calc(100vh-4rem)] select-none">
      {/* Brand Header Banner */}
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-2 mb-1">
          <Sparkles className="w-4 h-4 text-[#16A6A1]" />
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            Quy trình điều phối
          </span>
        </div>
        <p className="text-[11px] text-slate-300 leading-snug">
          Hệ thống điều phối liên thông ngoại trú Bệnh viện Sơn Trà
        </p>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        <div className="text-[10px] uppercase font-bold text-slate-400 px-3 py-1.5 tracking-wider">
          Phân hệ chuyên môn
        </div>
        
        {visibleNavItems.map(item => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center justify-between transition-all group cursor-pointer ${
                isActive 
                  ? 'bg-[#2878B5] text-white shadow-md font-semibold' 
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-slate-300 group-hover:text-teal-300'}`} />
                <div className="truncate">
                  <p className="text-xs leading-tight truncate font-medium">{item.label}</p>
                  <p className={`text-[10px] leading-tight truncate mt-0.5 ${isActive ? 'text-blue-100' : 'text-slate-400'}`}>
                    {item.sublabel}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {item.badge !== undefined && item.badge > 0 && (
                  <span className={`text-[10px] font-bold font-mono px-1.5 py-0.2 rounded-full ${item.badgeColor || 'bg-slate-700 text-white'}`}>
                    {item.badge}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-white/80" />}
              </div>
            </button>
          );
        })}
      </nav>

      {/* Footer System Status & Reset Demo Data */}
      <div className="p-4 border-t border-white/10 bg-[#12304A]/60 space-y-3">
        <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-xs">
          <div className="flex items-center justify-between text-slate-300 text-[11px] mb-1">
            <span>Động cơ điều phối AI</span>
            <span className="flex items-center gap-1 text-[#16A6A1] font-semibold text-[11px]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#16A6A1] animate-pulse" /> Sẵn sàng
            </span>
          </div>
          <p className="text-[10px] text-slate-400">Đồng bộ tự động dữ liệu liên màn hình</p>
        </div>

        <button
          onClick={() => {
            if (window.confirm('Khôi phục lại toàn bộ dữ liệu mẫu ban đầu của bệnh viện?')) {
              resetDemoData();
            }
          }}
          className="w-full py-2 px-3 bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center gap-2 border border-white/10 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
          <span>Khôi phục dữ liệu mẫu</span>
        </button>
      </div>
    </aside>
  );
};
