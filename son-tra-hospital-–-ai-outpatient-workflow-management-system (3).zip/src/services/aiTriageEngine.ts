import { 
  Patient, 
  PriorityLevel, 
  StandardAITriageOutput, 
  ChatMessage 
} from '../types';
import { 
  INITIAL_DEPARTMENTS_KB, 
  INITIAL_RED_FLAGS, 
  INITIAL_SYMPTOMS_KB,
  DepartmentKnowledge 
} from '../data/knowledgeBase';

export function normalizeVietnamese(str: string): string {
  if (!str) return '';
  return str
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .replace(/Đ/g, 'd')
    .trim();
}

export class AITriageEngine {
  /**
   * Main conversational triage entry point.
   * Analyzes the conversation history, extracts entities, evaluates red flags,
   * decides whether follow-up clarification is needed, or generates final department recommendation.
   */
  static processTriageConversation(
    patient: Patient,
    currentInput: string,
    history: ChatMessage[],
    existingAnalysis?: StandardAITriageOutput | null
  ): StandardAITriageOutput {
    const analysisId = `ANL-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const now = new Date();
    const timestamp = now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const age = now.getFullYear() - patient.birthYear;

    const normInput = normalizeVietnamese(currentInput);

    // 1. Detect if patient is amending / correcting symptoms
    const isAmendment = 
      normInput.includes('khong phai') || 
      normInput.includes('noi nham') || 
      normInput.includes('thuc ra la') ||
      normInput.includes('chinh xac la') ||
      normInput.includes('nham roi');

    // Aggregate user messages to build conversational context
    const userMessages = history
      .filter(m => m.sender === 'user')
      .map(m => m.text);
    
    // If amendment, discard conflicting older phrases, prioritize current input
    const contextText = isAmendment
      ? currentInput
      : [...userMessages, currentInput].join('. ');

    const normContext = normalizeVietnamese(contextText);

    // 2. RED FLAG DETECTION (Priority 1 - Safety First)
    const detectedRedFlags: string[] = [];
    let redFlagInstruction = '';
    let redFlagCategory = '';

    for (const rf of INITIAL_RED_FLAGS) {
      for (const trigger of rf.triggers) {
        if (normContext.includes(normalizeVietnamese(trigger))) {
          if (!detectedRedFlags.includes(rf.name)) {
            detectedRedFlags.push(rf.name);
            redFlagCategory = rf.category;
            redFlagInstruction = rf.immediateAction;
          }
          break;
        }
      }
    }

    // If red flag is detected: IMMEDIATELY escalate, do not ask more questions!
    if (detectedRedFlags.length > 0) {
      let recDept = 'Tim mạch';
      if (redFlagCategory === 'ho_hap') recDept = 'Hô hấp';
      else if (redFlagCategory === 'dot_quy') recDept = 'Thần kinh';
      else if (redFlagCategory === 'xuat_huyet' || redFlagCategory === 'ngoai_khoa') recDept = 'Tiêu hóa';

      return {
        analysis_id: analysisId,
        patient_id: patient.id,
        timestamp,
        symptoms: detectedRedFlags,
        anatomical_location: redFlagCategory === 'tim_mach' ? 'Vùng ngực trái / sau xương ức' : 'Đột quỵ / Toàn thân',
        onset_duration: 'Cấp tính / Cần can thiệp khẩn',
        severity_described: 'Nghiêm trọng / Dữ dội',
        associated_symptoms: [],
        missing_information: [],
        red_flags: detectedRedFlags,
        recommended_department: recDept,
        priority_level: 1, // Mức 1: Khẩn cấp
        reason: `DẤU HIỆU CẢNH BÁO NGUY HIỂM (Red Flag): Phát hiện [${detectedRedFlags.join(', ')}]. Bệnh nhân có nguy cơ cấp cứu khẩn cấp. Ưu tiên xử lý cấp cứu ngay, không chờ quy trình phân luồng thông thường.`,
        confidence: 0.99,
        need_more_information: false,
        requires_human_review: true,
        emergency_warning: true,
        emergency_instructions: redFlagInstruction,
        next_action: 'Chuyển thông tin khẩn cấp đến Lễ tân & Đưa vào đầu hàng phòng khám cấp cứu ngay lập tức.',
        workflow_status: 'EMERGENCY_ESCALATED',
      };
    }

    // 3. ENTITY EXTRACTION: Location, Duration, Severity, Associated Symptoms
    const extractedSymptoms: string[] = [];
    let location = '';
    let duration = '';
    let severity: 'Nhẹ' | 'Vừa' | 'Nặng' | 'Dữ dội' = 'Vừa';
    const associated: string[] = [];
    const missingInfo: string[] = [];

    // Anatomical location check
    if (normContext.includes('bung') || normContext.includes('da day') || normContext.includes('thuong vi') || normContext.includes('ruot')) {
      location = 'Vùng bụng / Thượng vị';
    } else if (normContext.includes('dau') || normContext.includes('gay') || normContext.includes('nua dau') || normContext.includes('tien dinh')) {
      location = 'Vùng đầu / Sau gáy';
    } else if (normContext.includes('hong') || normContext.includes('co') || normContext.includes('phoi') || normContext.includes('nguc')) {
      location = 'Vùng họng / Đường hô hấp';
    } else if (normContext.includes('tai')) {
      location = 'Tai / Vùng mang tai';
    } else if (normContext.includes('da') || normContext.includes('toan than')) {
      location = 'Ngoài da';
    }

    // Duration check
    if (normContext.includes('ngay') || normContext.includes('hom nay') || normContext.includes('sang nay') || normContext.includes('tuan') || normContext.includes('thang')) {
      // Find duration phrase
      const words = contextText.split(' ');
      const dayIdx = words.findIndex(w => normalizeVietnamese(w).includes('ngay') || normalizeVietnamese(w).includes('tuan'));
      if (dayIdx > 0) {
        duration = `${words[dayIdx - 1]} ${words[dayIdx]}`;
      } else {
        duration = 'Gần đây';
      }
    }

    // Severity check
    if (normContext.includes('du doi') || normContext.includes('rat dau') || normContext.includes('khong chiu noi') || normContext.includes('quan quai')) {
      severity = 'Dữ dội';
    } else if (normContext.includes('nhe') || normContext.includes('thoang qua') || normContext.includes('am i') || normContext.includes('hoi')) {
      severity = 'Nhẹ';
    } else if (normContext.includes('nang') || normContext.includes('nhieu')) {
      severity = 'Nặng';
    }

    // Match known symptoms from Knowledge Base
    for (const sym of INITIAL_SYMPTOMS_KB) {
      let matched = false;
      if (normContext.includes(normalizeVietnamese(sym.symptomName))) matched = true;
      if (!matched) {
        for (const alias of sym.commonAliases) {
          if (normContext.includes(normalizeVietnamese(alias))) {
            matched = true;
            break;
          }
        }
      }
      if (!matched) {
        for (const typo of sym.commonTypos) {
          if (normContext.includes(normalizeVietnamese(typo))) {
            matched = true;
            break;
          }
        }
      }
      if (matched && !extractedSymptoms.includes(sym.symptomName)) {
        extractedSymptoms.push(sym.symptomName);
      }
    }

    // Check missing critical information
    if (!location && extractedSymptoms.length === 0) {
      missingInfo.push('Vị trí xuất hiện triệu chứng cụ thể');
    }
    if (!duration) {
      missingInfo.push('Thời gian triệu chứng bắt đầu (bao lâu rồi)');
    }
    if (associated.length === 0 && !normContext.includes('khong co') && !normContext.includes('chi bi')) {
      missingInfo.push('Triệu chứng đi kèm (sốt, nôn, chóng mặt, ợ chua...)');
    }

    // 4. MULTI-TURN CLARIFICATION LOGIC
    // Determine whether to ask clarifying follow-up question
    const userTurnCount = userMessages.length + 1;
    const isVague = normInput.length < 12 || normInput === 'met moi' || normInput === 'met met' || normInput === 'dau' || normInput === 'kho chiu';
    
    // We ask follow-up if info is missing and turns < 3
    if ((isVague || missingInfo.length >= 2 || (!location && extractedSymptoms.length === 0)) && userTurnCount < 3) {
      let followUpQuestion = '';
      if (!location) {
        followUpQuestion = 'Bác có thể cho biết cảm giác khó chịu hoặc đau xuất hiện ở vị trí cụ thể nào trên cơ thể (ví dụ: ở đầu, bụng, ngực hay cổ họng) và kéo dài bao lâu rồi ạ?';
      } else if (!duration) {
        followUpQuestion = `Hệ thống đã ghi nhận bác có khó chịu ở ${location}. Xin hỏi triệu chứng này xuất hiện từ khi nào (mấy ngày nay), và bác có bị sốt hay nôn đi kèm không?`;
      } else {
        followUpQuestion = 'Bác có thể chia sẻ thêm triệu chứng này xuất hiện khi nào, và mức độ đau/khó chịu có tăng lên sau ăn hay khi vận động không?';
      }

      return {
        analysis_id: analysisId,
        patient_id: patient.id,
        timestamp,
        symptoms: extractedSymptoms.length > 0 ? extractedSymptoms : [currentInput],
        anatomical_location: location || 'Chưa xác định',
        onset_duration: duration || 'Chưa cung cấp',
        severity_described: severity,
        associated_symptoms: associated,
        missing_information: missingInfo,
        red_flags: [],
        recommended_department: 'Đang làm rõ triệu chứng',
        priority_level: 3,
        reason: 'Thông tin triệu chứng ban đầu còn sơ khai. AI cần đặt câu hỏi bổ sung để xác định chính xác chuyên khoa phù hợp.',
        confidence: 0.45,
        need_more_information: true,
        follow_up_question: followUpQuestion,
        uncertainties: ['Chưa rõ thời gian khởi phát', 'Chưa rõ các triệu chứng phối hợp'],
        requires_human_review: true,
        emergency_warning: false,
        next_action: 'Bệnh nhân trả lời câu hỏi làm rõ để AI hoàn tất phân luồng.',
        workflow_status: 'WAITING_INPUT',
      };
    }

    // 5. DEPARTMENT MATCHING & RULE ENGINE
    let bestDept = 'Nội tổng quát';
    let highestScore = 0;
    let matchedKeywords: string[] = [];

    for (const dept of INITIAL_DEPARTMENTS_KB) {
      let score = 0;
      const matchedThisDept: string[] = [];

      for (const kw of dept.primaryKeywords) {
        if (normContext.includes(normalizeVietnamese(kw))) {
          score += 3;
          matchedThisDept.push(kw);
        }
      }
      for (const kw of dept.secondaryKeywords) {
        if (normContext.includes(normalizeVietnamese(kw))) {
          score += 1;
          matchedThisDept.push(kw);
        }
      }

      if (score > highestScore) {
        highestScore = score;
        bestDept = dept.name;
        matchedKeywords = matchedThisDept;
      }
    }

    // 6. PRIORITY DETERMINATION & AGE VULNERABILITY (BR03)
    let priorityLevel: PriorityLevel = 3; // Tiêu chuẩn

    if (severity === 'Dữ dội' || severity === 'Nặng' || normContext.includes('sot cao') || highestScore >= 6) {
      priorityLevel = 2; // Ưu tiên cao
    }

    // Rule BR03: Bệnh nhân >= 65 tuổi hoặc < 6 tuổi tự động tăng 1 bậc ưu tiên
    let ageAdjustmentNote = '';
    if (priorityLevel === 3 && (age >= 65 || age < 6)) {
      priorityLevel = 2;
      ageAdjustmentNote = `(Áp dụng quy tắc BR03: Bệnh nhân ${age} tuổi được cộng thêm 1 bậc ưu tiên tiếp nhận sớm).`;
    }

    // Check if symptoms remain completely unclassifiable
    const isUnclassifiable = highestScore === 0 && extractedSymptoms.length === 0;
    if (isUnclassifiable) {
      bestDept = 'Cần phân luồng thủ công';
      return {
        analysis_id: analysisId,
        patient_id: patient.id,
        timestamp,
        symptoms: [currentInput],
        anatomical_location: location || 'Không rõ',
        onset_duration: duration || 'Không rõ',
        severity_described: severity,
        associated_symptoms: associated,
        missing_information: ['Không khớp bảng triệu chứng chuyên khoa'],
        red_flags: [],
        recommended_department: 'Cần phân luồng thủ công',
        priority_level: 3,
        reason: 'Triệu chứng bệnh nhân mô tả không khớp danh mục bệnh lý chuyên khoa đã phê duyệt (Cổng G3 = Không). Chuyển Lễ tân tiếp đón trực tiếp.',
        confidence: 0.35,
        need_more_information: false,
        uncertainties: ['Không có từ khóa định hướng chuyên khoa'],
        requires_human_review: true,
        emergency_warning: false,
        next_action: 'Chuyển Lễ tân phân luồng thủ công tại quầy tiếp đón.',
        workflow_status: 'MANUAL_REQUIRED',
      };
    }

    const rationale = `Khớp các từ khóa lâm sàng [${matchedKeywords.join(', ')}] thuộc phạm vi chuyên khoa ${bestDept}. Vị trí: ${location || 'phù hợp'}. Mức độ: ${severity}. ${ageAdjustmentNote}`;

    return {
      analysis_id: analysisId,
      patient_id: patient.id,
      timestamp,
      symptoms: extractedSymptoms.length > 0 ? extractedSymptoms : [currentInput],
      anatomical_location: location || 'Phù hợp chuyên khoa',
      onset_duration: duration || 'Vài ngày gần đây',
      severity_described: severity,
      associated_symptoms: associated,
      missing_information: [],
      red_flags: [],
      recommended_department: bestDept,
      priority_level: priorityLevel,
      reason: rationale,
      confidence: Math.min(0.72 + (highestScore * 0.05), 0.96),
      need_more_information: false,
      uncertainties: highestScore < 3 ? ['Mức độ đặc hiệu của triệu chứng ở mức trung bình'] : undefined,
      requires_human_review: true,
      emergency_warning: false,
      next_action: 'Chuyển đề xuất sang màn hình Lễ tân duyệt khung giờ và cấp mã QR.',
      workflow_status: 'WAITING_REVIEW',
    };
  }
}
