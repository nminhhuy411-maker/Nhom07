import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { X, Search, ShieldCheck, Download, History, ArrowRight } from 'lucide-react';

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({ isOpen, onClose }) => {
  const { workflowLogs } = useHospital();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');

  if (!isOpen) return null;

  const filteredLogs = workflowLogs.filter(log => {
    const matchesSearch = 
      log.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.patientId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.visitId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.reason && log.reason.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesRole = selectedRole === 'all' || log.role === selectedRole;
    return matchesSearch && matchesRole;
  });

  const exportCsv = () => {
    const headers = ['Mã Log', 'Mã Lượt', 'Mã BN', 'Tên BN', 'Người thực hiện', 'Vai trò', 'Hành động', 'Giai đoạn', 'Trạng thái cũ', 'Trạng thái mới', 'Lý do/Ghi chú', 'Thời gian'];
    const rows = filteredLogs.map(l => [
      l.id, l.visitId, l.patientId, `"${l.patientName}"`, `"${l.actorName}"`, l.role, `"${l.action}"`, `"${l.stage}"`, l.previousState, l.newState, `"${l.reason || ''}"`, l.timestamp
    ]);
    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Nhat_ky_hoat_dong_BV_Son_Tra_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[85vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-150 border border-slate-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 text-blue-700 rounded-lg">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Nhật ký Hoạt động Hệ thống (Audit Logs - BR17)</h3>
              <p className="text-xs text-slate-500">Ghi nhận minh bạch mọi hành động duyệt, đổi khoa, check-in, gọi số, nhập kết quả và thanh toán</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={exportCsv}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" /> Xuất CSV
            </button>
            <button 
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="p-4 border-b border-slate-200 bg-white flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="relative flex-1 min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm theo Mã BN, Tên BN, Mã lượt khám, thao tác..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 focus:outline-hidden focus:ring-2 focus:ring-blue-500 text-xs"
            />
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Vai trò:</span>
            <select
              value={selectedRole}
              onChange={e => setSelectedRole(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-medium focus:ring-2 focus:ring-blue-500"
            >
              <option value="all">Tất cả vai trò</option>
              <option value="patient">Bệnh nhân</option>
              <option value="reception">Lễ tân</option>
              <option value="doctor">Bác sĩ</option>
              <option value="paraclinical">Cận lâm sàng</option>
              <option value="cashier">Thu ngân</option>
              <option value="admin">Quản trị viên</option>
              <option value="Hệ thống AI">Hệ thống AI</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 sticky top-0 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[11px] tracking-wider z-10">
              <tr>
                <th className="py-2.5 px-4">Thời gian</th>
                <th className="py-2.5 px-3">Người thực hiện</th>
                <th className="py-2.5 px-3">Bệnh nhân</th>
                <th className="py-2.5 px-3">Hành động & Giai đoạn</th>
                <th className="py-2.5 px-3">Chuyển trạng thái</th>
                <th className="py-2.5 px-4">Lý do & Nội dung</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-slate-400">
                    Không tìm thấy bản ghi nhật ký phù hợp.
                  </td>
                </tr>
              ) : (
                filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-4 whitespace-nowrap font-mono text-[11px] text-slate-500">
                      {log.timestamp}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-900">{log.actorName}</div>
                      <span className="text-[10px] text-slate-400 capitalize">{log.role}</span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="font-semibold text-slate-800">{log.patientName}</div>
                      <span className="text-[10px] font-mono text-slate-400">{log.patientId} · {log.visitId}</span>
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="font-semibold text-blue-700">{log.action}</div>
                      <span className="text-[10px] text-slate-400">{log.stage}</span>
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 font-mono text-[11px]">
                        <span className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">{log.previousState}</span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                        <span className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded font-semibold">{log.newState}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-4 text-slate-600 max-w-xs truncate" title={log.reason}>
                      {log.reason || '—'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
