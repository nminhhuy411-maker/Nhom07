import React, { useState, useEffect, useRef } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { QrCodeView } from '../common/QrCodeView';
import { WorkflowProgressTracker } from '../common/WorkflowProgressTracker';
import { Patient, Visit } from '../../types';
import { 
  Send, 
  Mic, 
  MicOff, 
  Search, 
  UserCheck, 
  UserPlus, 
  Calendar, 
  Clock, 
  QrCode, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  X, 
  AlertTriangle,
  Receipt,
  RotateCcw,
  Volume2,
  FlaskConical,
  Pill,
  KeyRound,
  Shield,
  FileText,
  Lock,
  Eye,
  EyeOff,
  User,
  ShieldCheck,
  Zap
} from 'lucide-react';

export const PatientModule: React.FC = () => {
  const { 
    patients, 
    visits, 
    symptomRecords, 
    aiRecommendations, 
    queueItems, 
    invoices,
    labOrders,
    prescriptions,
    activeAccount,
    changePassword,
    lookupPatient, 
    createPatient, 
    submitSymptoms, 
    cancelVisit,
    activePatientId, 
    setActivePatientId,
    activeAnalysis
  } = useHospital();

  const isPatientRole = activeAccount.role === 'patient';
  const [activeTab, setActiveTab] = useState<'register' | 'chat' | 'appointment' | 'queue' | 'lab_results' | 'prescriptions' | 'invoice' | 'profile'>(() => isPatientRole ? 'appointment' : 'register');
  const [lookupInput, setLookupInput] = useState('048090000001'); // Pre-fill with Nguyen Van An
  const [lookupError, setLookupError] = useState('');
  const [showNewPatientForm, setShowNewPatientForm] = useState(false);

  // New patient registration form state
  const [newFullName, setNewFullName] = useState('');
  const [newCccd, setNewCccd] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newBirthYear, setNewBirthYear] = useState(1990);
  const [newGender, setNewGender] = useState<'Nam' | 'Nữ' | 'Khác'>('Nam');
  const [newAddress, setNewAddress] = useState('Sơn Trà, Đà Nẵng');
  const [newBhyt, setNewBhyt] = useState('DN448090009999');
  const [newBhytRate, setNewBhytRate] = useState(0.8);
  const [newHistory, setNewHistory] = useState('');

  // Chatbot state
  const [chatMessages, setChatMessages] = useState<{ id: string; sender: 'user' | 'bot' | 'system'; text: string; timestamp: string }[]>([
    { id: '1', sender: 'bot', text: 'Kính chào quý khách đến với Bệnh viện Sơn Trà! Vui lòng cho tôi biết triệu chứng khó chịu nhất khiến bạn muốn đi khám hôm nay?', timestamp: '08:00' }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isAiAnalyzing, setIsAiAnalyzing] = useState(false);
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('Bận việc đột xuất');

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Active patient and their latest visit
  const currentPatient = patients.find(p => p.id === activePatientId) || patients[0];
  const currentVisit = visits.find(v => v.patientId === currentPatient?.id && v.status !== 'cancelled') || visits.find(v => v.patientId === currentPatient?.id);
  const currentAiRec = currentVisit ? aiRecommendations.find(r => r.visitId === currentVisit.id) : null;
  const currentQueue = currentVisit ? queueItems.find(q => q.visitId === currentVisit.id) : null;
  const currentInvoice = currentVisit ? invoices.find(i => i.visitId === currentVisit.id) : null;
  const patientLabOrders = labOrders.filter(o => o.patientId === currentPatient?.id || (currentVisit && o.visitId === currentVisit.id));
  const patientPrescriptions = prescriptions.filter(p => p.patientId === currentPatient?.id || (currentVisit && p.visitId === currentVisit.id));

  // Profile Password Form State
  const [profilePwForm, setProfilePwForm] = useState({ oldPw: '', newPw: '', confirmPw: '' });
  const [profilePwMsg, setProfilePwMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [showProfilePw, setShowProfilePw] = useState(false);

  // Single Source of Truth for Triage output (Fix sync bug across chat & right-side card)
  const activeTriage = (activeAnalysis && activeAnalysis.patient_id === currentPatient?.id)
    ? activeAnalysis
    : currentAiRec?.standardOutput;

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isAiAnalyzing]);

  // Voice input handling using Web Speech API with fallback
  const toggleSpeechRecognition = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert('Trình duyệt của bạn chưa hỗ trợ nhận diện giọng nói tự động. Vui lòng nhập văn bản vào khung chat.');
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      return;
    }

    try {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'vi-VN';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onstart = () => setIsRecording(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputMessage(prev => (prev ? prev + ' ' + transcript : transcript));
        setIsRecording(false);
      };
      recognition.onerror = () => setIsRecording(false);
      recognition.onend = () => setIsRecording(false);

      recognition.start();
    } catch {
      setIsRecording(false);
    }
  };

  const handleLookup = () => {
    setLookupError('');
    const clean = lookupInput.trim();
    if (!clean) {
      setLookupError('Vui lòng nhập số CCCD (12 chữ số) hoặc Số điện thoại (10 chữ số)');
      return;
    }

    // BR01 Validation
    if (clean.length !== 12 && clean.length !== 10) {
      setLookupError('Định dạng không hợp lệ: CCCD gồm đúng 12 chữ số, Số điện thoại gồm đúng 10 chữ số bắt đầu bằng 0 (BR01).');
      return;
    }

    const { patient } = lookupPatient(clean);
    if (patient) {
      setActivePatientId(patient.id);
      setShowNewPatientForm(false);
      setActiveTab('chat');
    } else {
      setShowNewPatientForm(true);
      if (clean.length === 12) setNewCccd(clean);
      if (clean.length === 10) setNewPhone(clean);
    }
  };

  const handleCreatePatient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFullName || !newCccd || !newPhone) {
      alert('Vui lòng điền đầy đủ các trường bắt buộc (Họ tên, CCCD, SĐT)');
      return;
    }

    if (newCccd.length !== 12 || !/^\d+$/.test(newCccd)) {
      alert('Số CCCD phải gồm đúng 12 chữ số!');
      return;
    }

    if (newPhone.length !== 10 || !newPhone.startsWith('0')) {
      alert('Số điện thoại phải gồm 10 chữ số và bắt đầu bằng số 0!');
      return;
    }

    const created = createPatient({
      cccd: newCccd,
      phone: newPhone,
      fullName: newFullName,
      birthYear: Number(newBirthYear),
      dateOfBirth: `01/01/${newBirthYear}`,
      gender: newGender,
      address: newAddress,
      bhytCode: newBhyt,
      bhytRate: Number(newBhytRate),
      medicalHistory: newHistory ? newHistory.split(',').map(s => s.trim()) : [],
    });

    setActivePatientId(created.id);
    setShowNewPatientForm(false);
    setActiveTab('chat');
  };

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text || text.length < 5) {
      alert('Mô tả triệu chứng quá ngắn. Vui lòng mô tả chi tiết hơn ít nhất 5 ký tự để AI có thể phân luồng chính xác (UC.03).');
      return;
    }

    const nowStr = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const userMsg = { id: Date.now().toString(), sender: 'user' as const, text, timestamp: nowStr };
    const newChatHistory = [...chatMessages, userMsg];
    setChatMessages(newChatHistory);
    setInputMessage('');
    setIsAiAnalyzing(true);

    // AI analysis
    setTimeout(() => {
      const summary = {
        chiefComplaint: text,
        onsetDuration: 'Khoảng 1 - 2 ngày gần đây',
        severity: text.toLowerCase().includes('dữ dội') || text.toLowerCase().includes('khó thở') ? 'Dữ dội' : 'Vừa',
        associatedSymptoms: [],
        underlyingDiseases: currentPatient.medicalHistory.join(', ') || 'Không ghi nhận',
        age: new Date().getFullYear() - currentPatient.birthYear,
        gender: currentPatient.gender,
      };

      const result = submitSymptoms(currentPatient.id, text, newChatHistory, summary);
      setIsAiAnalyzing(false);

      let botReply = '';
      if (result.standardOutput?.need_more_information) {
        // Multi-turn clarification question (Section II)
        botReply = result.standardOutput.follow_up_question || 'Để gợi ý chuyên khoa chính xác nhất, bạn vui lòng cho biết triệu chứng xuất hiện từ khi nào và mức độ khó chịu ra sao?';
        // Note: Remain on chat tab so user can answer!
      } else if (result.recommendation.isEmergency) {
        botReply = `🚨 CẢNH BÁO NGUY HIỂM: ${result.standardOutput?.emergency_instructions || result.recommendation.rationale} Hệ thống đã xếp Ưu tiên 1 và báo động quầy Tiếp đón / Cấp cứu.`;
        setActiveTab('appointment');
      } else if (result.recommendation.triageType === 'manual_required') {
        botReply = `Triệu chứng chưa đặc hiệu: Hệ thống đã tóm tắt và chuyển hồ sơ của bạn sang danh sách chờ Lễ tân phân luồng thủ công (Cổng G3 = Không). Vui lòng theo dõi phiếu khám.`;
        setActiveTab('appointment');
      } else {
        botReply = `AI đã phân tích xong (Mã phân tích: ${result.standardOutput?.analysis_id || 'ANL'}): Đề xuất bạn khám tại chuyên khoa ${result.recommendation.suggestedDepartment} (Ưu tiên ${result.recommendation.suggestedPriority}). Yêu cầu đã được chuyển đến Lễ tân duyệt để cấp khung giờ và mã QR.`;
        setActiveTab('appointment');
      }

      setChatMessages(prev => [
        ...prev,
        { id: (Date.now() + 1).toString(), sender: 'bot', text: botReply, timestamp: new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }) }
      ]);
    }, 1000);
  };

  const handleQuickSymptomClick = (symptomText: string) => {
    handleSendMessage(symptomText);
  };

  const handleCancelAppointment = () => {
    if (!currentVisit) return;
    const success = cancelVisit(currentVisit.id, cancelReason);
    if (success) {
      setCancelModalOpen(false);
      alert('Lượt khám đã được hủy bỏ thành công.');
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Patient Selector */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-0.5 rounded-md">
              Chức năng 1 & Cổng Bệnh nhân
            </span>
            <span className="text-xs text-slate-400">· Hệ thống tự phục vụ (Self-service Kiosk/Web)</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Đăng Ký Khám Bệnh & Triage AI Bệnh Viện Sơn Trà
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Nhận diện hồ sơ CCCD, khai báo triệu chứng với Chatbot, nhận đề xuất khoa tự động và theo dõi hàng đợi
          </p>
        </div>

        {/* Patient Context Display */}
        {isPatientRole ? (
          <div className="flex items-center gap-3 bg-blue-50/80 px-4 py-2.5 rounded-xl border border-blue-200">
            <div className="w-9 h-9 rounded-xl bg-[#2878B5] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              {currentPatient?.fullName ? currentPatient.fullName.slice(0, 2).toUpperCase() : 'BN'}
            </div>
            <div className="text-left text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900">{currentPatient?.fullName}</span>
                <span className="font-mono bg-blue-100 text-[#163A5F] px-1.5 py-0.5 rounded text-[10px] font-bold">
                  {currentPatient?.id}
                </span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-50 text-emerald-700 text-[10px] font-semibold border border-emerald-200 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Đã xác thực
                </span>
              </div>
              <div className="text-[11px] text-slate-500 font-mono flex flex-wrap items-center gap-x-2 mt-0.5">
                <span>CCCD: {currentPatient?.cccd ? `${currentPatient.cccd.slice(0, 6)}******` : 'N/A'}</span>
                <span>· SĐT: {currentPatient?.phone}</span>
                <span>· BHYT: {currentPatient?.bhytCode} ({Math.round((currentPatient?.bhytRate || 0.8) * 100)}%)</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
            <div className="text-left">
              <p className="text-[10px] text-slate-400 font-medium">Bệnh nhân demo đang chọn:</p>
              <select
                value={activePatientId}
                onChange={e => setActivePatientId(e.target.value)}
                className="bg-transparent text-xs font-bold text-slate-800 focus:outline-hidden cursor-pointer"
              >
                {patients.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.fullName} ({p.id} - {p.birthYear} - {p.gender})
                  </option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Progress Tracker for Current Visit */}
      {currentVisit && (
        <WorkflowProgressTracker visit={currentVisit} />
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto text-xs font-semibold">
        {!isPatientRole && (
          <button
            onClick={() => setActiveTab('register')}
            className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
              activeTab === 'register' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Search className="w-3.5 h-3.5" /> Tra cứu / Nhận diện (UC.02)
          </button>
        )}
        <button
          onClick={() => setActiveTab('appointment')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'appointment' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <QrCode className="w-3.5 h-3.5 text-teal-300" /> Lịch khám & Mã QR
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'chat' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Khai báo AI Triage
        </button>
        <button
          onClick={() => setActiveTab('queue')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'queue' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-sky-300" /> Theo dõi Hàng đợi
        </button>
        <button
          onClick={() => setActiveTab('lab_results')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'lab_results' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FlaskConical className="w-3.5 h-3.5 text-teal-300" /> Kết quả Cận lâm sàng
        </button>
        <button
          onClick={() => setActiveTab('prescriptions')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'prescriptions' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Pill className="w-3.5 h-3.5 text-indigo-300" /> Đơn thuốc điện tử
        </button>
        <button
          onClick={() => setActiveTab('invoice')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'invoice' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Receipt className="w-3.5 h-3.5 text-emerald-300" /> Hóa đơn viện phí
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-3.5 py-2 rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
            activeTab === 'profile' ? 'bg-[#163A5F] text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <User className="w-3.5 h-3.5 text-purple-300" /> Hồ sơ cá nhân & Đổi MK
        </button>
      </div>

      {/* TAB 1: LOOKUP / REGISTER (UC.02) */}
      {activeTab === 'register' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Lookup Box */}
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <h3 className="text-base font-bold text-slate-900 mb-2 flex items-center gap-2">
                <Search className="w-5 h-5 text-blue-600" />
                Bước 1: Tra cứu Hồ sơ bằng CCCD hoặc Số điện thoại (UC.02)
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                Nhập số CCCD gồm 12 chữ số hoặc Số điện thoại gồm 10 chữ số bắt đầu bằng 0 (Quy tắc BR01) để xác định hồ sơ điện tử.
              </p>

              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  placeholder="Ví dụ CCCD: 048090000001 hoặc SĐT: 0905000001"
                  value={lookupInput}
                  onChange={e => setLookupInput(e.target.value)}
                  className="flex-1 px-4 py-2.5 rounded-xl border border-slate-300 text-sm font-mono focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
                <button
                  onClick={handleLookup}
                  className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <Search className="w-4 h-4" /> Tra cứu hồ sơ (G1)
                </button>
              </div>

              {lookupError && (
                <div className="mt-3 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-700 text-xs font-medium">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {lookupError}
                </div>
              )}

              {/* Quick sample chips for easy assessment */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-400 font-medium">Mẫu thử nhanh:</span>
                {patients.slice(0, 4).map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setLookupInput(p.cccd);
                      setActivePatientId(p.id);
                    }}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 rounded-md font-mono text-[11px] border border-slate-200 transition-colors"
                  >
                    {p.fullName} ({p.cccd})
                  </button>
                ))}
              </div>
            </div>

            {/* Found Patient Info Card (G1 = Có) */}
            {currentPatient && !showNewPatientForm && (
              <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-emerald-600" />
                    <h4 className="font-bold text-slate-900 text-sm">Hồ sơ Bệnh nhân Tìm thấy (G1 = Có hồ sơ)</h4>
                  </div>
                  <span className="text-xs font-mono font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200">
                    Mã BN: {currentPatient.id}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400">Họ và tên:</span>
                    <p className="font-bold text-slate-800 text-sm mt-0.5">{currentPatient.fullName}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">CCCD:</span>
                    <p className="font-mono font-semibold text-slate-800 mt-0.5">
                      {currentPatient.cccd.substring(0, 4)}****{currentPatient.cccd.substring(8)} (Đã che bảo mật BR01)
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400">Năm sinh / Giới tính:</span>
                    <p className="font-semibold text-slate-800 mt-0.5">{currentPatient.birthYear} ({new Date().getFullYear() - currentPatient.birthYear} tuổi) · {currentPatient.gender}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Số điện thoại:</span>
                    <p className="font-mono font-semibold text-slate-800 mt-0.5">{currentPatient.phone}</p>
                  </div>
                  <div>
                    <span className="text-slate-400">Mã BHYT & Mức hưởng:</span>
                    <p className="font-mono font-semibold text-teal-700 mt-0.5">
                      {currentPatient.bhytCode} · Mức hưởng {Math.round(currentPatient.bhytRate * 100)}%
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400">Tiền sử bệnh án:</span>
                    <p className="font-semibold text-slate-800 mt-0.5">
                      {currentPatient.medicalHistory.length > 0 ? currentPatient.medicalHistory.join(', ') : 'Không ghi nhận tiền sử dị ứng/mãn tính'}
                    </p>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                  <button
                    onClick={() => setActiveTab('chat')}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition-colors shadow-xs"
                  >
                    Xác nhận đúng là mình & Khai triệu chứng (UC.03) →
                  </button>
                </div>
              </div>
            )}

            {/* New Patient Registration Form (G1 = Chưa có hồ sơ) */}
            {showNewPatientForm && (
              <form onSubmit={handleCreatePatient} className="bg-white border border-blue-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-blue-100">
                  <div className="flex items-center gap-2">
                    <UserPlus className="w-5 h-5 text-blue-600" />
                    <h4 className="font-bold text-slate-900 text-sm">Tạo Hồ sơ Bệnh nhân Mới (G1 = Không tìm thấy)</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowNewPatientForm(false)}
                    className="text-slate-400 hover:text-slate-600 text-xs"
                  >
                    Hủy
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Họ và tên bệnh nhân *</label>
                    <input
                      type="text"
                      required
                      placeholder="Nguyễn Văn A"
                      value={newFullName}
                      onChange={e => setNewFullName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Số CCCD (12 số) *</label>
                    <input
                      type="text"
                      required
                      maxLength={12}
                      placeholder="048090000001"
                      value={newCccd}
                      onChange={e => setNewCccd(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Số điện thoại (10 số) *</label>
                    <input
                      type="text"
                      required
                      maxLength={10}
                      placeholder="0905000001"
                      value={newPhone}
                      onChange={e => setNewPhone(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Năm sinh *</label>
                    <input
                      type="number"
                      required
                      min={1910}
                      max={2026}
                      value={newBirthYear}
                      onChange={e => setNewBirthYear(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Giới tính</label>
                    <select
                      value={newGender}
                      onChange={e => setNewGender(e.target.value as any)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white"
                    >
                      <option value="Nam">Nam</option>
                      <option value="Nữ">Nữ</option>
                      <option value="Khác">Khác</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Địa chỉ thường trú</label>
                    <input
                      type="text"
                      value={newAddress}
                      onChange={e => setNewAddress(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Mã thẻ BHYT (tùy chọn)</label>
                    <input
                      type="text"
                      placeholder="DN448090000001"
                      value={newBhyt}
                      onChange={e => setNewBhyt(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Mức hưởng BHYT giả lập</label>
                    <select
                      value={newBhytRate}
                      onChange={e => setNewBhytRate(Number(e.target.value))}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white font-medium text-teal-800"
                    >
                      <option value={0.8}>80% (Hộ gia đình, người lao động chuẩn)</option>
                      <option value={1.0}>100% (Người có công, sĩ quan, trẻ em, người cao tuổi)</option>
                      <option value={0}>0% (Khám dịch vụ tự nguyện)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1 text-xs">Tiền sử bệnh án, dị ứng (ngăn cách bằng dấu phẩy)</label>
                  <input
                    type="text"
                    placeholder="Tăng huyết áp, Đái tháo đường, Dị ứng Penicillin..."
                    value={newHistory}
                    onChange={e => setNewHistory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
                  >
                    Lưu hồ sơ & Chuyển sang Khai triệu chứng →
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Quick Workflow Guidance Sidebar */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-5 space-y-4 text-xs">
            <h4 className="font-bold text-slate-800 flex items-center gap-1.5 text-sm">
              <Sparkles className="w-4 h-4 text-blue-600" />
              Quy tắc Nghiệp vụ Tiếp đón (MIS3047)
            </h4>
            <div className="space-y-3 text-slate-600 leading-relaxed">
              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <strong className="text-slate-800 block mb-1">BR01: Định dạng định danh</strong>
                Mỗi công dân tương ứng 01 mã CCCD duy nhất (12 chữ số). SĐT gồm 10 chữ số bắt đầu bằng 0. Khi trùng SĐT, hệ thống cho phép chọn đúng người theo họ tên che bớt.
              </div>
              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <strong className="text-slate-800 block mb-1">G1: Cổng kiểm tra hồ sơ</strong>
                Nếu đã có hồ sơ trong HIS, hệ thống tải thông tin và bệnh sử cũ để không cần khai báo lại, tạo ngay lượt khám mới.
              </div>
              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <strong className="text-slate-800 block mb-1">Bảo vệ quyền riêng tư</strong>
                Họ tên và số CCCD được che bớt theo tiêu chuẩn bảo mật dữ liệu y tế.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SYMPTOM CHATBOT & AI TRIAGE (3-COLUMN LAYOUT) */}
      {activeTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          
          {/* COLUMN 1: PATIENT PROFILE & MEDICAL HISTORY */}
          <div className="lg:col-span-3 space-y-4">
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100 mb-3.5">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2878B5] flex items-center justify-center font-bold text-xs">
                  BN
                </div>
                <div>
                  <h4 className="font-bold text-slate-800 text-xs">Thông Tin Bệnh Nhân</h4>
                  <p className="text-[10px] text-slate-400 font-mono">Mã BN: {currentPatient.id}</p>
                </div>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 text-[11px] block">Họ và tên:</span>
                  <p className="font-bold text-slate-900 text-sm mt-0.5">{currentPatient.fullName}</p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-slate-400 text-[11px] block">Năm sinh:</span>
                    <p className="font-semibold text-slate-800 mt-0.5">
                      {currentPatient.birthYear} ({new Date().getFullYear() - currentPatient.birthYear}t)
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[11px] block">Giới tính:</span>
                    <p className="font-semibold text-slate-800 mt-0.5">{currentPatient.gender}</p>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 text-[11px] block">Số điện thoại:</span>
                  <p className="font-mono font-medium text-slate-800 mt-0.5">{currentPatient.phone}</p>
                </div>

                <div>
                  <span className="text-slate-400 text-[11px] block">Số định danh CCCD:</span>
                  <p className="font-mono font-medium text-slate-700 mt-0.5">
                    {currentPatient.cccd.substring(0, 4)}****{currentPatient.cccd.substring(8)}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-slate-400 text-[11px] block">Thẻ BHYT & Mức chi trả:</span>
                  <div className="flex items-center justify-between mt-0.5">
                    <span className="font-mono font-bold text-[#16A6A1]">{currentPatient.bhytCode}</span>
                    <span className="px-2 py-0.5 bg-teal-50 text-teal-700 rounded text-[10px] font-bold border border-teal-200">
                      BHYT {Math.round(currentPatient.bhytRate * 100)}%
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100">
                  <span className="text-slate-400 text-[11px] block mb-1">Tiền sử bệnh án & Dị ứng:</span>
                  {currentPatient.medicalHistory.length > 0 ? (
                    <div className="space-y-1">
                      {currentPatient.medicalHistory.map((h, i) => (
                        <span key={i} className="inline-block text-[11px] bg-slate-50 border border-slate-200 text-slate-700 px-2 py-0.5 rounded-md">
                          {h}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-500 italic">Không có tiền sử đặc biệt</p>
                  )}
                </div>
              </div>
            </div>

            {/* Current Visit Context */}
            {currentVisit && (
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Lượt khám hiện tại</span>
                <div className="flex items-center justify-between font-mono font-bold text-[#163A5F] text-xs">
                  <span>{currentVisit.id}</span>
                  <span className="text-[11px] font-sans font-semibold text-[#2878B5]">
                    {currentVisit.status === 'registered' ? 'Đã khởi tạo' : currentVisit.status === 'symptom_declared' ? 'Đã khai triệu chứng' : 'Đang xử lý'}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* COLUMN 2: CHATBOT INTERACTION & SYMPTOM CHIPS */}
          <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs flex flex-col h-[640px]">
            {/* Chatbot Header */}
            <div className="pb-3 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-100 text-[#2878B5] flex items-center justify-center font-bold text-xs">
                  AI
                </div>
                <div>
                  <h3 className="font-bold text-slate-800 text-xs">Trợ lý AI Triage Khám Bệnh Ngoại Trú</h3>
                  <p className="text-[10px] text-slate-400">Trò chuyện thu thập & làm rõ triệu chứng</p>
                </div>
              </div>
              <span className="text-[10px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">
                AI Sẵn sàng
              </span>
            </div>

            {/* Quick Suggestion Chips */}
            <div className="py-2 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto text-xs">
              <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap">Gợi ý nhanh:</span>
              {[
                'Đau vùng thượng vị, ợ chua',
                'Đau thắt ngực trái dữ dội, khó thở',
                'Sốt nhẹ, ho đờm 3 ngày',
                'Đau nhức đầu, hoa mắt chóng mặt',
                'Ù tai, chảy mủ tai trái'
              ].map((chip, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickSymptomClick(chip)}
                  className="px-2 py-0.5 bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-700 rounded-md whitespace-nowrap text-[10px] transition-colors border border-slate-200/80 cursor-pointer"
                >
                  {chip}
                </button>
              ))}
            </div>

            {/* Chat Messages Log */}
            <div className="flex-1 overflow-y-auto py-3 space-y-2.5 pr-1">
              {chatMessages.map(msg => (
                <div 
                  key={msg.id} 
                  className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs ${
                    msg.sender === 'user' 
                      ? 'bg-[#163A5F] text-white rounded-tr-none' 
                      : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200/70'
                  }`}>
                    <p className="leading-relaxed whitespace-pre-line">{msg.text}</p>
                    <span className={`block text-[9px] mt-1 ${msg.sender === 'user' ? 'text-blue-200 text-right' : 'text-slate-400'}`}>
                      {msg.timestamp}
                    </span>
                  </div>
                </div>
              ))}

              {isAiAnalyzing && (
                <div className="flex justify-start">
                  <div className="bg-blue-50 border border-blue-200 rounded-2xl rounded-tl-none px-3.5 py-2.5 text-xs text-[#2878B5] flex items-center gap-2">
                    <Sparkles className="w-3.5 h-3.5 animate-spin" />
                    <span>AI đang phân tích triệu chứng & đối chiếu cơ sở tri thức y khoa...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input Form */}
            <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
              <input
                type="text"
                placeholder="Nhập mô tả triệu chứng của bạn (ví dụ: đau bụng, ho, đau đầu...)"
                value={inputMessage}
                onChange={e => setInputMessage(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-[#2878B5] focus:outline-hidden"
              />
              <button
                type="button"
                onClick={toggleSpeechRecognition}
                title={isRecording ? 'Đang nghe... bấm để dừng' : 'Nhập bằng giọng nói (Speech to Text)'}
                className={`p-2 rounded-xl border transition-colors cursor-pointer ${
                  isRecording 
                    ? 'bg-rose-500 text-white border-rose-600 animate-pulse' 
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border-slate-200'
                }`}
              >
                {isRecording ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={isAiAnalyzing}
                className="px-4 py-2 bg-[#163A5F] hover:bg-[#12304A] disabled:opacity-50 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" /> Gửi
              </button>
            </div>
          </div>

          {/* COLUMN 3: AI ANALYSIS, RECOMMENDATIONS & CONFIDENCE SCORE */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-white border border-slate-200/90 rounded-2xl p-5 shadow-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-[#2878B5]" />
                  <h4 className="font-bold text-slate-900 text-xs">Kết quả Phân Tích AI Triage</h4>
                </div>
                {(activeTriage?.analysis_id || currentAiRec?.analysis_id) && (
                  <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-2 py-0.5 rounded border border-blue-200 font-semibold">
                    {activeTriage?.analysis_id || currentAiRec?.analysis_id}
                  </span>
                )}
              </div>

              {activeTriage ? (
                <div className="mt-3.5 space-y-3 text-xs">
                  {/* Status Banner */}
                  {activeTriage.need_more_information ? (
                    <div className="p-3 bg-sky-50 border border-sky-200 rounded-xl text-sky-900 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-sky-800">
                        <Sparkles className="w-4 h-4 text-sky-600 animate-spin" />
                        <span>ĐANG LÀM RÕ THÔNG TIN</span>
                      </div>
                      <p className="text-[11px] leading-relaxed">
                        AI cần thêm chi tiết để định hướng khoa chính xác, tránh phân luồng sai.
                      </p>
                      {activeTriage.follow_up_question && (
                        <p className="text-[11px] font-medium text-sky-900 bg-white/70 p-2 rounded-lg border border-sky-200/60 mt-1">
                          💬 <em>"{activeTriage.follow_up_question}"</em>
                        </p>
                      )}
                    </div>
                  ) : activeTriage.emergency_warning ? (
                    <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 space-y-1.5">
                      <div className="flex items-center gap-1.5 font-bold text-rose-700">
                        <AlertCircle className="w-4 h-4 text-rose-600 animate-pulse" />
                        <span>CẢNH BÁO NGUY HIỂM (CỜ ĐỎ - RED FLAG)</span>
                      </div>
                      <p className="text-[11px] font-semibold text-rose-800">
                        Phát hiện dấu hiệu: {activeTriage.red_flags.join(', ')}
                      </p>
                      <p className="text-[11px] leading-relaxed">
                        {activeTriage.emergency_instructions || activeTriage.reason}
                      </p>
                    </div>
                  ) : (
                    <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold text-emerald-700">
                        <CheckCircle2 className="w-4 h-4" /> ĐÃ XÁC ĐỊNH CHUYÊN KHOA PHÙ HỢP
                      </div>
                      <p className="text-[11px] leading-relaxed">{activeTriage.reason}</p>
                    </div>
                  )}

                  {/* Metrics box */}
                  <div className="p-3.5 bg-slate-50 rounded-xl space-y-2.5 border border-slate-200/80">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Khoa đề xuất:</span>
                      <strong className="text-[#163A5F] font-bold text-sm">
                        {activeTriage.recommended_department}
                      </strong>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Mức độ ưu tiên:</span>
                      <span className={`font-bold px-2 py-0.5 rounded text-[11px] ${
                        activeTriage.priority_level === 1 
                          ? 'bg-rose-100 text-rose-700' 
                          : activeTriage.priority_level === 2 
                            ? 'bg-amber-100 text-amber-700' 
                            : 'bg-blue-100 text-blue-700'
                      }`}>
                        {activeTriage.priority_level === 1 ? 'Mức 1 - Khẩn cấp' : activeTriage.priority_level === 2 ? 'Mức 2 - Ưu tiên cao' : 'Mức 3 - Tiêu chuẩn'}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">Độ tin cậy đề xuất:</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-slate-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[#16A6A1] rounded-full" 
                            style={{ width: `${Math.round(activeTriage.confidence * 100)}%` }}
                          />
                        </div>
                        <span className="font-mono font-bold text-slate-800 text-xs">
                          {Math.round(activeTriage.confidence * 100)}%
                        </span>
                      </div>
                    </div>

                    {activeTriage.symptoms && activeTriage.symptoms.length > 0 && (
                      <div className="pt-2 border-t border-slate-200/70">
                        <span className="text-[10px] text-slate-400 block mb-1">Triệu chứng lâm sàng:</span>
                        <div className="flex flex-wrap gap-1">
                          {activeTriage.symptoms.map((s, idx) => (
                            <span key={idx} className="bg-white border border-slate-200 text-slate-700 text-[10px] px-2 py-0.5 rounded-md">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Next Step Action Button */}
                  <button
                    type="button"
                    onClick={() => setActiveTab('appointment')}
                    className="w-full py-2.5 bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5 cursor-pointer mt-2"
                  >
                    Xem lịch hẹn & Mã QR Check-in →
                  </button>

                  <p className="text-[10px] text-slate-400 italic text-center">
                    * Quyết định phân luồng chính thức được phê duyệt tại Quầy Lễ tân
                  </p>
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400 text-xs">
                  Vui lòng nhập triệu chứng để AI tiến hành phân loại và định hướng chuyên khoa.
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: APPOINTMENT & QR CODE (UC.05 & UC.15) */}
      {activeTab === 'appointment' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-5">
            <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Chi tiết Lịch hẹn & Phiếu Khám Ngoại Trú</h3>
                  <p className="text-xs text-slate-500">Mã lượt khám: <strong className="font-mono text-slate-800">{currentVisit?.id || 'Chưa khởi tạo'}</strong></p>
                </div>
                {currentVisit && (
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-md ${
                    currentVisit.status === 'approved' 
                      ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                      : currentVisit.status === 'checked_in'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : currentVisit.status === 'pending_triage'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-slate-100 text-slate-700'
                  }`}>
                    {currentVisit.status === 'approved' ? 'Đã duyệt - Sẵn sàng Check-in' : 
                     currentVisit.status === 'checked_in' ? 'Đã Check-in vào hàng đợi' :
                     currentVisit.status === 'pending_triage' ? 'Đang chờ Lễ tân duyệt' : currentVisit.status}
                  </span>
                )}
              </div>

              {currentVisit ? (
                <div className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-slate-400">Bệnh nhân:</span>
                      <p className="font-bold text-slate-900 text-sm">{currentPatient.fullName}</p>
                      <p className="text-[11px] text-slate-500 font-mono">CCCD: {currentPatient.cccd} · Năm sinh: {currentPatient.birthYear}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Chuyên khoa & Phòng khám:</span>
                      <p className="font-bold text-blue-700 text-sm">{currentVisit.assignedDepartment}</p>
                      <p className="text-[11px] text-slate-600 font-medium">{currentVisit.assignedRoom}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Khung giờ dự kiến (15 phút):</span>
                      <p className="font-mono font-bold text-slate-800 text-sm mt-0.5">{currentVisit.slotTime}</p>
                      <p className="text-[10px] text-slate-400">Ngày khám: {currentVisit.appointmentDate}</p>
                    </div>
                    <div>
                      <span className="text-slate-400">Mức ưu tiên:</span>
                      <p className="font-bold mt-0.5">
                        {currentVisit.priority === 1 ? 'Mức 1 - Khẩn cấp (Đầu hàng)' : currentVisit.priority === 2 ? 'Mức 2 - Ưu tiên cao' : 'Mức 3 - Tiêu chuẩn'}
                      </p>
                      <p className="text-[10px] text-slate-400">Dung sai trễ: 15 phút (BR07)</p>
                    </div>
                  </div>

                  {/* Actions: Cancel Visit UC.15 */}
                  <div className="flex items-center justify-between pt-3 border-t border-slate-100">
                    <span className="text-[11px] text-slate-400">
                      * Quý khách có thể hủy lịch khám trước khi bác sĩ bắt đầu khám bệnh (UC.15).
                    </span>
                    {currentVisit.status !== 'completed' && currentVisit.status !== 'cancelled' && (
                      <button
                        onClick={() => setCancelModalOpen(true)}
                        className="px-3.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-semibold rounded-lg transition-colors"
                      >
                        Hủy lượt khám (UC.15)
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center text-slate-400 text-xs">
                  Bệnh nhân chưa có lượt khám nào. Vui lòng khai triệu chứng để nhận lịch.
                </div>
              )}
            </div>
          </div>

          {/* QR Code Container */}
          <div className="space-y-4">
            <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col items-center text-center">
              <h4 className="font-bold text-slate-900 text-sm mb-1">Mã QR Định Danh Lượt Khám</h4>
              <p className="text-[11px] text-slate-500 mb-3">
                Dùng để quét check-in tự động tại kiosk hoặc quầy tiếp đón
              </p>

              {currentVisit && currentVisit.qrCode ? (
                <div className="space-y-3 w-full flex flex-col items-center">
                  <QrCodeView 
                    value={currentVisit.qrCode} 
                    size={190} 
                    label={currentVisit.id}
                  />

                  <div className="text-[11px] font-mono text-slate-600 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 max-w-full truncate">
                    Mã xác thực: {currentVisit.qrCode}
                  </div>

                  {currentVisit.qrUsed ? (
                    <div className="w-full p-2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" /> Đã quét Check-in lúc {currentVisit.checkInTime}
                    </div>
                  ) : (
                    <div className="w-full p-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-xs font-medium">
                      Mã còn hiệu lực (chưa check-in)
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-12 text-slate-400 text-xs">
                  Chưa có mã QR. Lễ tân cần duyệt để cấp mã.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: LIVE QUEUE TRACKER (UC.07) */}
      {activeTab === 'queue' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-5 h-5 text-indigo-600" />
                Theo dõi Hàng đợi Thời gian thực (UC.07)
              </h3>
              <p className="text-xs text-slate-500">
                Cập nhật tự động vị trí khám, thời gian chờ ước tính và thông báo khi sắp đến lượt
              </p>
            </div>
            {currentQueue && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Số thứ tự của bạn:</span>
                <span className="text-xl font-extrabold font-mono text-blue-700 bg-blue-50 px-3 py-1 rounded-xl border border-blue-200">
                  #{currentQueue.queueNumber}
                </span>
              </div>
            )}
          </div>

          {currentQueue ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2 space-y-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <span className="text-[11px] text-slate-400 font-medium">Phòng khám</span>
                    <p className="text-sm font-bold text-slate-800 mt-1">{currentQueue.room}</p>
                  </div>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center">
                    <span className="text-[11px] text-slate-400 font-medium">Thời gian chờ dự kiến</span>
                    <p className="text-sm font-bold text-blue-700 font-mono mt-1">~{currentQueue.estimatedWaitMinutes} phút</p>
                  </div>
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-center col-span-2 sm:col-span-1">
                    <span className="text-[11px] text-slate-400 font-medium">Trạng thái lượt khám</span>
                    <p className="text-sm font-bold text-emerald-700 mt-1 capitalize">
                      {currentQueue.status === 'calling' ? 'ĐANG GỌI SỐ VÀO KHÁM!' : currentQueue.status === 'in_consultation' ? 'Đang khám' : currentQueue.status === 'waiting' ? 'Đang chờ lượt' : currentQueue.status}
                    </p>
                  </div>
                </div>

                {/* Proximity / Calling Banner */}
                {currentQueue.status === 'calling' ? (
                  <div className="p-5 bg-rose-500 text-white rounded-2xl shadow-lg animate-pulse flex items-center justify-between">
                    <div>
                      <h4 className="font-extrabold text-base uppercase">BÁC SĨ ĐANG GỌI SỐ CỦA BẠN!</h4>
                      <p className="text-xs text-rose-100 mt-0.5">Vui lòng vào ngay {currentQueue.room}. Bạn có 3 phút để có mặt (BR11).</p>
                    </div>
                    <span className="text-2xl font-mono font-black bg-white text-rose-700 px-3.5 py-1 rounded-xl">
                      #{currentQueue.queueNumber}
                    </span>
                  </div>
                ) : currentQueue.status === 'waiting' && currentQueue.estimatedWaitMinutes <= 15 ? (
                  <div className="p-4 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl flex items-center gap-3 text-xs">
                    <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                    <div>
                      <strong className="block text-sm">Sắp đến lượt khám của bạn! (BR10)</strong>
                      <p className="text-[11px]">Còn không quá 3 người phía trước bạn. Vui lòng di chuyển đến ngồi chờ ngay trước cửa {currentQueue.room}.</p>
                    </div>
                  </div>
                ) : null}

                {/* Queue Table */}
                <div className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                  <div className="p-3 bg-slate-50 border-b border-slate-200 font-bold text-slate-700">
                    Danh sách hàng đợi tại {currentQueue.department}
                  </div>
                  <div className="divide-y divide-slate-100">
                    {queueItems
                      .filter(q => q.department === currentQueue.department && (q.status === 'waiting' || q.status === 'calling' || q.status === 'in_consultation'))
                      .map((item, idx) => (
                        <div 
                          key={item.id} 
                          className={`p-3 flex items-center justify-between ${
                            item.visitId === currentVisit?.id ? 'bg-blue-50/80 font-bold' : 'hover:bg-slate-50'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-mono font-bold text-slate-700 w-8">#{item.queueNumber}</span>
                            <div>
                              <p className="text-slate-800">{item.patientName} {item.visitId === currentVisit?.id && '(Bạn)'}</p>
                              <span className="text-[10px] text-slate-400">Giờ check-in: {item.checkInTime}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              item.status === 'calling' 
                                ? 'bg-rose-500 text-white animate-pulse' 
                                : item.status === 'in_consultation'
                                  ? 'bg-blue-100 text-blue-800'
                                  : 'bg-slate-100 text-slate-600'
                            }`}>
                              {item.status === 'calling' ? 'Đang gọi' : item.status === 'in_consultation' ? 'Đang khám' : 'Đang chờ'}
                            </span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>

              {/* Patient Info Summary */}
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-3">
                <h5 className="font-bold text-slate-800">Quy tắc Hàng đợi Thông minh</h5>
                <p className="text-slate-600 text-[11px] leading-relaxed">
                  Thứ tự khám được xếp tự động theo Mức độ ưu tiên (Khẩn cấp 1 &gt; Ưu tiên 2 &gt; Tiêu chuẩn 3), sau đó theo khung giờ hẹn và thời điểm check-in (BR09).
                </p>
                <div className="p-2.5 bg-white rounded-lg border border-slate-200 space-y-1 text-[11px]">
                  <strong className="text-slate-700 block">Thời hạn gọi số (BR11):</strong>
                  <p className="text-slate-500">Sau khi gọi số, nếu vắng mặt quá 3 phút, hệ thống tự động ghi nhận Bỏ lượt để chuyển sang bệnh nhân kế tiếp.</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs">
              Bệnh nhân chưa thực hiện check-in vào hàng đợi. Vui lòng quét mã QR tại Kiosk hoặc nhờ Lễ tân hỗ trợ.
            </div>
          )}
        </div>
      )}

      {/* TAB: ELECTRONIC INVOICE (UC.16) */}
      {activeTab === 'invoice' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs max-w-3xl mx-auto space-y-6">
          {currentInvoice ? (
            <>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                <div>
                  <span className="text-[11px] font-mono text-slate-400">Số hóa đơn: {currentInvoice.id}</span>
                  <h3 className="text-lg font-extrabold text-slate-900">Hóa Đơn Điện Tử Bệnh Viện Sơn Trà</h3>
                </div>
                <span className={`px-3 py-1 rounded-md text-xs font-bold ${
                  currentInvoice.status === 'paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {currentInvoice.status === 'paid' ? '✓ ĐÃ THANH TOÁN' : 'CHỜ THANH TOÁN'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-slate-400">Bệnh nhân:</span>
                  <p className="font-bold text-slate-900 text-sm">{currentInvoice.patientName}</p>
                  <p className="text-slate-500 font-mono">CCCD: {currentInvoice.cccd}</p>
                </div>
                <div className="text-right">
                  <span className="text-slate-400">BHYT áp dụng:</span>
                  <p className="font-mono font-bold text-teal-700">{currentInvoice.bhytCode}</p>
                  <p className="text-slate-500">Mức hưởng: {Math.round(currentInvoice.bhytRate * 100)}%</p>
                </div>
              </div>

              <table className="w-full text-xs text-left border-collapse">
                <thead className="bg-slate-50 border-y border-slate-200 font-semibold text-slate-600">
                  <tr>
                    <th className="py-2.5 px-3">Tên dịch vụ y tế</th>
                    <th className="py-2.5 px-3 text-center">SL</th>
                    <th className="py-2.5 px-3 text-right">Đơn giá (VNĐ)</th>
                    <th className="py-2.5 px-3 text-right">Thành tiền (VNĐ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {currentInvoice.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="py-2.5 px-3 font-sans text-slate-800 font-medium">{item.name}</td>
                      <td className="py-2.5 px-3 text-center text-slate-600">{item.quantity}</td>
                      <td className="py-2.5 px-3 text-right text-slate-600">{item.unitPrice.toLocaleString('vi-VN')}</td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900">{item.amount.toLocaleString('vi-VN')}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="p-4 bg-slate-50 rounded-xl space-y-2 text-xs font-mono border border-slate-200">
                <div className="flex justify-between text-slate-600">
                  <span>Tổng chi phí khám & cận lâm sàng:</span>
                  <span className="font-bold text-slate-900">{currentInvoice.totalAmount.toLocaleString('vi-VN')} VNĐ</span>
                </div>
                <div className="flex justify-between text-teal-700">
                  <span>Quỹ BHYT chi trả ({Math.round(currentInvoice.bhytRate * 100)}%):</span>
                  <span className="font-bold">- {currentInvoice.bhytAmount.toLocaleString('vi-VN')} VNĐ</span>
                </div>
                <div className="flex justify-between text-sm font-sans pt-2 border-t border-slate-200 text-slate-900">
                  <span className="font-bold">Bệnh nhân cần thanh toán (Đồng chi trả):</span>
                  <span className="font-bold text-blue-700 font-mono text-base">{currentInvoice.patientPaymentAmount.toLocaleString('vi-VN')} VNĐ</span>
                </div>
              </div>
            </>
          ) : (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <Receipt className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-medium text-slate-600">Chưa có hóa đơn phát sinh trong đợt khám này</p>
              <p className="text-[11px]">Hóa đơn sẽ xuất hiện tự động sau khi Bác sĩ chỉ định dịch vụ hoặc kết thúc khám.</p>
            </div>
          )}
        </div>
      )}

      {/* TAB: LAB & PARACLINICAL RESULTS */}
      {activeTab === 'lab_results' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <FlaskConical className="w-5 h-5 text-teal-600" />
                <h3 className="text-base font-bold text-slate-900">Theo dõi Kết quả Cận lâm sàng & Chẩn đoán hình ảnh</h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Các chỉ định xét nghiệm máu, chụp X-quang, siêu âm được liên thông trực tiếp từ phòng khám bác sĩ
              </p>
            </div>
            <span className="text-xs bg-teal-50 text-teal-700 font-bold px-3 py-1 rounded-full border border-teal-200">
              {patientLabOrders.length} chỉ định
            </span>
          </div>

          {patientLabOrders.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <FlaskConical className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-medium text-slate-600">Chưa có chỉ định cận lâm sàng nào</p>
              <p className="text-[11px]">Nếu bác sĩ yêu cầu xét nghiệm hoặc chụp chiếu, kết quả sẽ được hiển thị tại đây.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {patientLabOrders.map((order) => {
                const isCompleted = order.status === 'completed';
                const isDelayed = order.isDelayed || order.status === 'delayed' || order.isUnprocessable;

                return (
                  <div key={order.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded font-bold">
                            {order.id}
                          </span>
                          <span className="font-bold text-sm text-slate-900">{order.serviceName}</span>
                        </div>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Địa điểm: <strong className="text-slate-700">{order.roomName}</strong> · Chỉ định: {order.orderTime || 'Hôm nay'}
                        </p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {isDelayed ? (
                          <span className="px-2.5 py-1 rounded-md text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200 flex items-center gap-1 font-mono">
                            <Clock className="w-3 h-3 text-rose-600" /> Sự cố: Chờ xử lý 8 tiếng
                          </span>
                        ) : !isCompleted && (
                          <span className="px-2.5 py-1 rounded-md text-[10px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1 font-mono">
                            <Clock className="w-3 h-3 text-emerald-600" /> Dự kiến: ~{order.deadlineMinutes || 5} phút
                          </span>
                        )}
                        <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 ${
                          isCompleted
                            ? 'bg-emerald-100 text-emerald-800'
                            : isDelayed
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}>
                          {isCompleted ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5 animate-spin" />}
                          {isCompleted ? 'Đã có kết quả hợp lệ' : isDelayed ? 'Đang khắc phục sự cố (8h)' : `Đang phân tích mẫu (~${order.deadlineMinutes || 5}p)`}
                        </span>
                      </div>
                    </div>

                    {/* Result Details */}
                    {isCompleted && order.result ? (
                      <div className="bg-white p-3.5 rounded-lg border border-slate-200 text-xs space-y-2">
                        <div className="font-semibold text-slate-700 flex items-center justify-between">
                          <span>Kết quả chuyên môn:</span>
                          <span className="text-[11px] text-slate-400 font-mono">Bác sĩ duyệt: {order.result.validatedBy || 'BS. Trưởng khoa'}</span>
                        </div>
                        <p className="text-slate-800 leading-relaxed font-mono bg-slate-50 p-2.5 rounded border border-slate-100">
                          {order.result.summary || 'Các chỉ số nằm trong giới hạn tham chiếu bình thường.'}
                        </p>
                        {order.result.technicianNotes && (
                          <p className="text-[11px] text-slate-500">
                            <strong>Ghi chú KTV:</strong> {order.result.technicianNotes}
                          </p>
                        )}
                      </div>
                    ) : isDelayed ? (
                      <div className="p-3 bg-rose-50/70 rounded-lg border border-rose-200 text-xs text-rose-800 space-y-1">
                        <div className="flex items-center gap-2 font-bold">
                          <AlertTriangle className="w-4 h-4 text-rose-600" />
                          <span>Chỉ định phát sinh sự cố không thể xử lý trong 5 phút</span>
                        </div>
                        <p className="text-[11px] text-slate-600 pl-6 leading-relaxed">
                          Lý do: <em>{order.delayReason || 'Thiết bị máy phân tích gặp sự cố kỹ thuật hoặc mẫu bất thường cần kiểm tra lại.'}</em>. Khoa Cận lâm sàng đang phối hợp khắc phục trong thời hạn <strong>8 tiếng (480 phút)</strong>.
                        </p>
                      </div>
                    ) : (
                      <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-500 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-teal-600 animate-spin" />
                        <span>Kỹ thuật viên đang phân tích mẫu nhanh. Thời gian dự kiến khoảng <strong>~{order.deadlineMinutes || 5} phút</strong>. Quý khách vui lòng chờ thông báo kết quả.</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: PRESCRIPTIONS */}
      {activeTab === 'prescriptions' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div>
              <div className="flex items-center gap-2">
                <Pill className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-bold text-slate-900">Đơn Thuốc Ngoại Trú Điện Tử</h3>
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Toa thuốc do bác sĩ điều trị kê và hướng dẫn sử dụng thuốc an toàn
              </p>
            </div>
            <span className="text-xs bg-indigo-50 text-indigo-700 font-bold px-3 py-1 rounded-full border border-indigo-200">
              {patientPrescriptions.length} đơn thuốc
            </span>
          </div>

          {patientPrescriptions.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs space-y-2">
              <Pill className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-medium text-slate-600">Chưa có đơn thuốc phát sinh</p>
              <p className="text-[11px]">Đơn thuốc sẽ xuất hiện tại đây sau khi bác sĩ hoàn thành chẩn đoán.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {patientPrescriptions.map((rx) => {
                const isDispensed = rx.status === 'dispensed';
                const isReady = rx.status === 'ready';

                return (
                  <div key={rx.id} className="border border-slate-200 rounded-xl overflow-hidden text-xs">
                    <div className="p-4 bg-slate-50/80 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold bg-[#163A5F] text-white px-2 py-0.5 rounded text-[11px]">
                            {rx.id}
                          </span>
                          <span className="font-bold text-slate-900 text-sm">Bác sĩ kê: {rx.doctorName || 'BS. Điều trị'}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          Ngày kê: {rx.createdAt || 'Hôm nay'} · Chẩn đoán liên quan: {rx.diagnosis || 'Khám ngoại trú'}
                        </p>
                      </div>

                      <div>
                        <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold flex items-center gap-1 ${
                          isDispensed
                            ? 'bg-emerald-100 text-emerald-800'
                            : isReady
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isDispensed ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
                          {isDispensed ? 'Đã nhận thuốc tại quầy' : isReady ? 'Thuốc đã sẵn sàng - Mời đến quầy Dược' : 'Nhà thuốc đang soạn thuốc'}
                        </span>
                      </div>
                    </div>

                    <div className="p-4 bg-white space-y-3">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase text-[10px]">
                          <tr>
                            <th className="py-2 px-3">Tên thuốc / Hoạt chất</th>
                            <th className="py-2 px-3 text-center">Số lượng</th>
                            <th className="py-2 px-3">Hướng dẫn sử dụng</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {rx.items?.map((drug, dIdx) => (
                            <tr key={dIdx}>
                              <td className="py-2.5 px-3">
                                <div className="font-bold text-slate-800">{drug.drugName}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{drug.activeIngredient || drug.dosage}</div>
                              </td>
                              <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-700">
                                {drug.quantity} {drug.unit || 'viên'}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600">
                                {drug.instruction || 'Uống theo chỉ định của bác sĩ'}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      {rx.notes && (
                        <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px]">
                          <strong>Lời dặn bác sĩ / Dược sĩ:</strong> {rx.notes}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: PROFILE & SECURITY */}
      {activeTab === 'profile' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Patient Details */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
            <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#16A6A1] to-[#2878B5] flex items-center justify-center text-white font-bold text-lg shadow-sm">
                {currentPatient.fullName.slice(0, 2).toUpperCase()}
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900">{currentPatient.fullName}</h3>
                <p className="text-xs text-slate-500 font-mono">Mã hồ sơ: {currentPatient.id} · Sinh năm: {currentPatient.birthYear}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 text-[11px] block">Số định danh CCCD:</span>
                <span className="font-mono font-bold text-slate-800 text-sm">{currentPatient.cccd}</span>
                <span className="text-[10px] text-emerald-600 block mt-0.5">✓ Đã định danh cấp quốc gia</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 text-[11px] block">Số điện thoại liên hệ:</span>
                <span className="font-mono font-bold text-slate-800 text-sm">{currentPatient.phone}</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Nhận thông báo lịch khám & kết quả</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 text-[11px] block">Mã thẻ BHYT & Tỷ lệ chi trả:</span>
                <span className="font-mono font-bold text-[#2878B5] text-sm">{currentPatient.bhytCode}</span>
                <span className="text-[10px] text-teal-700 font-bold block mt-0.5">Hưởng {Math.round(currentPatient.bhytRate * 100)}% viện phí</span>
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 text-[11px] block">Giới tính & Quốc tịch:</span>
                <span className="font-bold text-slate-800">{currentPatient.gender} · Việt Nam</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Ngày sinh: {currentPatient.dateOfBirth}</span>
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="text-slate-400 text-[11px] block mb-1">Địa chỉ thường trú / Cư trú:</span>
              <p className="font-medium text-slate-800 leading-relaxed">{currentPatient.address}</p>
            </div>

            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="text-slate-400 text-[11px] block mb-1">Tiền sử bệnh mạn tính / Dị ứng:</span>
              <p className="font-medium text-slate-800">
                {currentPatient.medicalHistory.length > 0 ? currentPatient.medicalHistory.join(', ') : 'Không ghi nhận tiền sử bệnh lý mạn tính'}
              </p>
            </div>
          </div>

          {/* Right: Change Password Card */}
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
              <KeyRound className="w-5 h-5 text-[#2878B5]" />
              <h3 className="font-bold text-sm text-slate-900">Đổi Mật Khẩu Tài Khoản</h3>
            </div>

            {profilePwMsg && (
              <div className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                profilePwMsg.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-red-50 text-red-700 border border-red-200'
              }`}>
                {profilePwMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{profilePwMsg.text}</span>
              </div>
            )}

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mật khẩu hiện tại</label>
                <input
                  type={showProfilePw ? 'text' : 'password'}
                  value={profilePwForm.oldPw}
                  onChange={(e) => setProfilePwForm({ ...profilePwForm, oldPw: e.target.value })}
                  placeholder="Nhập mật khẩu hiện tại..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Mật khẩu mới (tối thiểu 8 ký tự)</label>
                <input
                  type={showProfilePw ? 'text' : 'password'}
                  value={profilePwForm.newPw}
                  onChange={(e) => setProfilePwForm({ ...profilePwForm, newPw: e.target.value })}
                  placeholder="Nhập mật khẩu mới..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Xác nhận mật khẩu mới</label>
                <input
                  type={showProfilePw ? 'text' : 'password'}
                  value={profilePwForm.confirmPw}
                  onChange={(e) => setProfilePwForm({ ...profilePwForm, confirmPw: e.target.value })}
                  placeholder="Nhập lại mật khẩu mới..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => setShowProfilePw(!showProfilePw)}
                  className="text-[11px] text-slate-500 hover:text-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  {showProfilePw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showProfilePw ? 'Ẩn ký tự' : 'Hiện ký tự'}</span>
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setProfilePwMsg(null);
                  if (!profilePwForm.oldPw || !profilePwForm.newPw) {
                    setProfilePwMsg({ text: 'Vui lòng nhập mật khẩu hiện tại và mật khẩu mới.', type: 'error' });
                    return;
                  }
                  if (profilePwForm.newPw.length < 8) {
                    setProfilePwMsg({ text: 'Mật khẩu mới phải có tối thiểu 8 ký tự.', type: 'error' });
                    return;
                  }
                  if (profilePwForm.newPw !== profilePwForm.confirmPw) {
                    setProfilePwMsg({ text: 'Mật khẩu xác nhận không khớp.', type: 'error' });
                    return;
                  }
                  const res = changePassword(profilePwForm.oldPw, profilePwForm.newPw);
                  if (!res.success) {
                    setProfilePwMsg({ text: res.message, type: 'error' });
                  } else {
                    setProfilePwMsg({ text: 'Đổi mật khẩu thành công! Hãy lưu lại mật khẩu mới.', type: 'success' });
                    setProfilePwForm({ oldPw: '', newPw: '', confirmPw: '' });
                  }
                }}
                className="w-full py-2.5 bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
              >
                Cập nhật mật khẩu mới
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CANCEL VISIT MODAL (UC.15) */}
      {cancelModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-rose-600" />
                Xác nhận Hủy Lượt Khám (UC.15)
              </h4>
              <button onClick={() => setCancelModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Bạn có chắc chắn muốn hủy lượt khám <strong>{currentVisit?.id}</strong>? Thao tác này sẽ xóa bạn khỏi hàng đợi, hủy giá trị mã QR và giải phóng khung giờ khám cho bệnh nhân khác.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Lý do hủy lịch *</label>
              <select
                value={cancelReason}
                onChange={e => setCancelReason(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs bg-white font-medium"
              >
                <option value="Bận việc đột xuất">Bận việc đột xuất không thể đến</option>
                <option value="Triệu chứng đã thuyên giảm">Triệu chứng đã thuyên giảm</option>
                <option value="Muốn đặt lại khung giờ khác">Muốn đặt lại khung giờ khác</option>
                <option value="Chọn nhầm khoa khám">Chọn nhầm khoa khám</option>
                <option value="Khác">Lý do khác</option>
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setCancelModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Giữ lại
              </button>
              <button
                onClick={handleCancelAppointment}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl"
              >
                Xác nhận hủy lượt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
