import React, { useState, useEffect } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { 
  Tv, 
  QrCode, 
  Search, 
  Clock, 
  Volume2, 
  AlertTriangle, 
  CheckCircle2, 
  ArrowRight, 
  UserCheck, 
  Users, 
  X,
  ShieldAlert,
  Play
} from 'lucide-react';

export const QueueDisplayModule: React.FC = () => {
  const { 
    queueItems, 
    visits, 
    patients, 
    checkInPatient, 
    config, 
    getSimulatedCurrentTime 
  } = useHospital();

  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [checkInText, setCheckInText] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'warning' | 'error'; message: string } | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Available departments
  const departments = ['all', 'Tiêu hóa', 'Tim mạch', 'Hô hấp', 'Nội tổng quát', 'Thần kinh', 'Tai mũi họng'];

  const filteredQueue = queueItems.filter(q => {
    if (selectedDept === 'all') return true;
    return q.department === selectedDept;
  });

  const callingItems = filteredQueue.filter(q => q.status === 'calling');
  const inConsultationItems = filteredQueue.filter(q => q.status === 'in_consultation');
  const waitingItems = filteredQueue
    .filter(q => q.status === 'waiting')
    .sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      if (a.bumpedCount !== b.bumpedCount) return a.bumpedCount - b.bumpedCount;
      return a.queueNumber - b.queueNumber;
    });

  const handleCheckInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkInText.trim()) return;

    const res = checkInPatient(checkInText);
    if (res.success) {
      if (res.message.includes('lùi lượt')) {
        setFeedback({ type: 'warning', message: res.message });
      } else {
        setFeedback({ type: 'success', message: res.message });
      }
      setCheckInText('');
    } else {
      setFeedback({ type: 'error', message: res.message });
    }
  };

  // Sound announcement synthesis simulation
  const speakCallingAnnouncement = (queueNum: number, room: string) => {
    if (!soundEnabled || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(`Mời số thứ tự ${queueNum} vào ${room}`);
      utterance.lang = 'vi-VN';
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    } catch {
      // Audio fallback
    }
  };

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-700 bg-indigo-50 border border-indigo-200 px-2.5 py-0.5 rounded-md">
              Hệ Thống Hàng Đợi & Gọi Số Tự Động
            </span>
            <span className="text-xs text-slate-400">· Tự động hóa tiếp nhận & Gọi số</span>
          </div>
          <h2 className="text-xl font-extrabold text-slate-900 mt-1">
            Bảng Điện Tử Phòng Khám & Kiosk Check-In QR
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Tự động tiếp nhận check-in qua QR code, điều phối số thứ tự theo mức độ ưu tiên, cập nhật thời gian chờ và phát loa thông báo
          </p>
        </div>

        {/* Sound toggle & dept filter */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              soundEnabled ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-slate-100 border-slate-200 text-slate-400'
            }`}
            title="Bật/tắt âm thanh đọc số gọi khám"
          >
            <Volume2 className="w-4 h-4" />
            <span>{soundEnabled ? 'Âm thanh: BẬT' : 'Âm thanh: TẮT'}</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: KIOSK CHECK-IN BAR */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-6 shadow-md">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <QrCode className="w-5 h-5 text-teal-400" />
              <h3 className="font-extrabold text-base tracking-wide uppercase">Cổng Tiếp Nhận Check-In Bệnh Nhân</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Bệnh nhân đưa mã QR trước camera Kiosk hoặc nhập số CCCD / Mã lượt khám. Hệ thống xác thực khung giờ khám và kiểm tra tính hợp lệ của mã hẹn.
            </p>

            <form onSubmit={handleCheckInSubmit} className="flex flex-col sm:flex-row gap-2 pt-1">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="Nhập mã QR (ví dụ: SONTRA-LK001-...) hoặc số CCCD..."
                  value={checkInText}
                  onChange={e => setCheckInText(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-white text-slate-900 text-xs font-mono font-medium focus:ring-2 focus:ring-teal-400 focus:outline-hidden"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-extrabold rounded-xl transition-colors shadow-xs flex items-center justify-center gap-1.5"
              >
                <UserCheck className="w-4 h-4" /> Xác nhận Check-in
              </button>
              <button
                type="button"
                onClick={() => setCameraActive(!cameraActive)}
                className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors flex items-center justify-center gap-1.5"
              >
                <QrCode className="w-4 h-4 text-teal-400" /> {cameraActive ? 'Đóng Camera' : 'Quét Camera'}
              </button>
            </form>

            {/* Quick check-in presets for assessment */}
            <div className="flex flex-wrap items-center gap-2 pt-2 text-[11px]">
              <span className="text-slate-400">BN chờ check-in thử:</span>
              {visits.filter(v => v.status === 'approved').slice(0, 3).map(v => {
                const p = patients.find(pat => pat.id === v.patientId);
                return (
                  <button
                    key={v.id}
                    onClick={() => {
                      setCheckInText(v.qrCode);
                    }}
                    className="px-2 py-0.5 bg-slate-800/80 hover:bg-teal-900 text-teal-300 font-mono rounded border border-slate-700 transition-colors"
                  >
                    {p?.fullName} ({v.slotTime})
                  </button>
                );
              })}
            </div>
          </div>

          {/* Camera Scanner Simulation */}
          <div className="flex flex-col items-center justify-center p-4 bg-slate-950/70 rounded-xl border border-slate-800 text-center">
            {cameraActive ? (
              <div className="relative w-44 h-44 rounded-xl border-2 border-teal-400/80 overflow-hidden flex flex-col items-center justify-center bg-black/80">
                <div className="absolute inset-x-2 top-0 h-0.5 bg-teal-400 animate-bounce" />
                <QrCode className="w-16 h-16 text-teal-400/40" />
                <span className="text-[10px] text-teal-300 mt-2 font-mono">Đang tìm mã QR...</span>
                <button
                  onClick={() => {
                    // Simulate instant QR detection
                    const appVisit = visits.find(v => v.status === 'approved') || visits[0];
                    if (appVisit) {
                      setCheckInText(appVisit.qrCode);
                      setCameraActive(false);
                      const res = checkInPatient(appVisit.qrCode);
                      setFeedback({ type: res.success ? 'success' : 'error', message: res.message });
                    }
                  }}
                  className="mt-2 text-[10px] bg-teal-500 text-slate-950 font-bold px-2 py-0.5 rounded shadow-xs"
                >
                  Giả lập quét mã thành công
                </button>
              </div>
            ) : (
              <div className="p-4 space-y-2">
                <QrCode className="w-10 h-10 text-slate-500 mx-auto" />
                <p className="text-xs text-slate-400 font-medium">Camera Kiosk Tự Động</p>
                <p className="text-[10px] text-slate-500">Hỗ trợ nhận diện mã QR trên điện thoại hoặc phiếu hẹn giấy</p>
              </div>
            )}
          </div>
        </div>

        {/* Feedback message */}
        {feedback && (
          <div className={`mt-4 p-3 rounded-xl border text-xs font-medium flex items-center justify-between ${
            feedback.type === 'success' 
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
              : feedback.type === 'warning'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
          }`}>
            <div className="flex items-center gap-2">
              {feedback.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
              <span>{feedback.message}</span>
            </div>
            <button onClick={() => setFeedback(null)}><X className="w-4 h-4" /></button>
          </div>
        )}
      </div>

      {/* Department Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-400 font-semibold uppercase text-[11px] tracking-wider">Chọn phòng khám:</span>
        {departments.map(d => (
          <button
            key={d}
            onClick={() => setSelectedDept(d)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors whitespace-nowrap ${
              selectedDept === d ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {d === 'all' ? 'Tất cả khoa phòng' : `Khoa ${d}`}
          </button>
        ))}
      </div>

      {/* SECTION 2: ELECTRONIC WAITING DISPLAY BOARD */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Calling & Current Consultation */}
        <div className="space-y-4">
          {/* NOW CALLING BOX (GỌI SỐ VÀO KHÁM) */}
          <div className="bg-white border-2 border-rose-500 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-rose-600 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping" />
                Số Đang Được Gọi (Calling)
              </span>
              <span className="text-[10px] font-mono text-slate-400">Thời hạn phản hồi: 3 phút</span>
            </div>

            {callingItems.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                Chưa có số nào đang gọi. Bác sĩ sẽ nhấn "Gọi số tiếp theo" trong phòng khám.
              </div>
            ) : (
              callingItems.map(item => (
                <div key={item.id} className="p-4 bg-rose-50 border border-rose-200 rounded-xl space-y-2">
                  <div className="flex items-baseline justify-between">
                    <span className="text-4xl font-extrabold font-mono text-rose-700">
                      #{item.queueNumber}
                    </span>
                    <span className="text-xs font-bold text-slate-900">{item.patientName}</span>
                  </div>
                  <div className="pt-2 border-t border-rose-200/60 flex items-center justify-between text-xs text-rose-900">
                    <span className="font-semibold">{item.room}</span>
                    <button
                      onClick={() => speakCallingAnnouncement(item.queueNumber, item.room)}
                      className="p-1 rounded text-rose-700 hover:bg-rose-200/60"
                      title="Phát lại loa thông báo"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* IN CONSULTATION BOX */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-extrabold text-blue-700 uppercase tracking-wider">
                Đang Khám Trong Phòng
              </span>
              <span className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                {inConsultationItems.length} ca
              </span>
            </div>

            {inConsultationItems.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                Hiện chưa có bệnh nhân nào đang trong phòng khám.
              </div>
            ) : (
              <div className="space-y-2">
                {inConsultationItems.map(item => (
                  <div key={item.id} className="p-3 bg-blue-50/60 border border-blue-200 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-blue-900 text-base">#{item.queueNumber}</span>
                      <p className="font-semibold text-slate-800">{item.patientName}</p>
                      <span className="text-[10px] text-slate-500">{item.room}</span>
                    </div>
                    <span className="text-[11px] font-semibold text-blue-700 bg-white px-2 py-1 rounded border border-blue-100">
                      Bác sĩ đang khám
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Ordered Waiting Queue */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-600" />
              <div>
                <h3 className="font-extrabold text-slate-900 text-sm">Danh Sách Bệnh Nhân Đang Chờ Khám</h3>
                <p className="text-[11px] text-slate-400">Sắp xếp: Ca khẩn cấp (P1) &gt; Ưu tiên cao (P2) &gt; Tiêu chuẩn (P3)</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-lg border border-indigo-200">
              Tổng chờ: {waitingItems.length} bệnh nhân
            </span>
          </div>

          <div className="flex-1 overflow-y-auto">
            {waitingItems.length === 0 ? (
              <div className="py-16 text-center text-slate-400 text-xs">
                Hiện không có bệnh nhân nào đang chờ trong danh sách hàng đợi.
              </div>
            ) : (
              <div className="space-y-2">
                {waitingItems.map((item, idx) => (
                  <div 
                    key={item.id}
                    className={`p-3.5 rounded-xl border flex items-center justify-between transition-colors ${
                      item.priority === 1 
                        ? 'bg-rose-50/70 border-rose-300 shadow-2xs' 
                        : item.bumpedCount > 0 
                          ? 'bg-amber-50/50 border-amber-200'
                          : 'bg-white border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className="text-center w-12">
                        <span className="text-lg font-black font-mono text-slate-900 leading-none">
                          #{item.queueNumber}
                        </span>
                        <span className="block text-[10px] text-slate-400 font-medium mt-0.5">Vị trí {idx + 1}</span>
                      </div>

                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-slate-800 text-xs">{item.patientName}</p>
                          <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded font-mono ${
                            item.priority === 1 ? 'bg-rose-600 text-white' : item.priority === 2 ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {item.priority === 1 ? 'P1 - Khẩn cấp' : item.priority === 2 ? 'P2 - Ưu tiên' : 'P3 - Thường'}
                          </span>
                          {item.bumpedCount > 0 && (
                            <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-medium">
                              Lùi lượt ({item.bumpedCount})
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">
                          {item.department} · {item.room} · Check-in: <span className="font-mono font-medium">{item.checkInTime}</span>
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-indigo-700 block">
                        ~{item.estimatedWaitMinutes} phút
                      </span>
                      <span className="text-[10px] text-slate-400">Thời gian chờ ước tính</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
