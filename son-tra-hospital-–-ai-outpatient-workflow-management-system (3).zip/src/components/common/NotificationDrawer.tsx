import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { UserRole } from '../../types';
import { X, Bell, Check, AlertTriangle, AlertCircle, Info, CheckCheck } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ isOpen, onClose }) => {
  const { notifications, activeAccount, markNotificationAsRead, markAllNotificationsAsRead } = useHospital();
  const [filterRole, setFilterRole] = useState<string>('all');

  if (!isOpen) return null;

  const filteredNotifications = notifications.filter(n => {
    if (filterRole === 'all') return true;
    if (filterRole === 'mine') return n.targetRole === activeAccount.role || n.targetRole === 'all';
    return n.targetRole === filterRole;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'alert':
        return <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />;
      case 'success':
        return <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />;
      default:
        return <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/30 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-blue-700" />
            <h3 className="font-bold text-slate-800 text-base">Trung tâm Thông báo tập trung</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="p-3 border-b border-slate-200 flex items-center justify-between gap-2 bg-white text-xs">
          <div className="flex items-center gap-1 overflow-x-auto py-0.5">
            {[
              { id: 'all', label: 'Tất cả' },
              { id: 'mine', label: 'Vai trò của tôi' },
              { id: 'reception', label: 'Lễ tân' },
              { id: 'doctor', label: 'Bác sĩ' },
              { id: 'paraclinical', label: 'Cận lâm sàng' },
              { id: 'cashier', label: 'Thu ngân' },
              { id: 'patient', label: 'Bệnh nhân' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilterRole(tab.id)}
                className={`px-2.5 py-1 rounded-md font-medium whitespace-nowrap transition-colors ${
                  filterRole === tab.id 
                    ? 'bg-blue-600 text-white' 
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <button
            onClick={() => markAllNotificationsAsRead()}
            className="text-blue-600 hover:text-blue-800 font-medium whitespace-nowrap flex items-center gap-1 shrink-0"
            title="Đánh dấu tất cả đã đọc"
          >
            <CheckCheck className="w-3.5 h-3.5" /> Đã đọc
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 divide-y divide-slate-100">
          {filteredNotifications.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-sm">
              <Bell className="w-8 h-8 mx-auto mb-2 opacity-30" />
              Không có thông báo nào trong danh mục này.
            </div>
          ) : (
            filteredNotifications.map(item => (
              <div 
                key={item.id} 
                onClick={() => markNotificationAsRead(item.id)}
                className={`pt-2.5 first:pt-0 cursor-pointer transition-colors p-3 rounded-lg border ${
                  item.isRead 
                    ? 'border-transparent bg-slate-50/50 hover:bg-slate-100/60' 
                    : 'border-blue-100 bg-blue-50/40 hover:bg-blue-50/70 shadow-xs'
                }`}
              >
                <div className="flex items-start gap-2.5">
                  {getIcon(item.type)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 mb-0.5">
                      <h4 className={`text-xs font-bold truncate ${item.isRead ? 'text-slate-700' : 'text-slate-900'}`}>
                        {item.title}
                      </h4>
                      <span className="text-[10px] font-mono text-slate-400 shrink-0">{item.createdAt}</span>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">{item.message}</p>
                    <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400">
                      <span className="uppercase tracking-wider font-semibold text-slate-500 bg-slate-200/60 px-1.5 py-0.5 rounded">
                        Gửi: {item.targetRole}
                      </span>
                      {!item.isRead && (
                        <span className="text-blue-600 font-semibold">Chưa đọc</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
