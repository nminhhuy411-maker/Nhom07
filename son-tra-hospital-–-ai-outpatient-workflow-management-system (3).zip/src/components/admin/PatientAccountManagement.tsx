import React, { useState } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { 
  Users, 
  Search, 
  ShieldCheck, 
  Lock, 
  Unlock, 
  KeyRound, 
  Link, 
  AlertTriangle, 
  CheckCircle2, 
  Eye, 
  EyeOff, 
  UserCheck,
  Calendar,
  Phone,
  CreditCard,
  Building2,
  Check,
  X,
  FileText,
  UserPlus
} from 'lucide-react';
import { UserAccount, Patient } from '../../types';

interface PatientAccountManagementProps {
  allowLockToggle?: boolean; // Admin can toggle lock, Reception can view and reset password
}

export const PatientAccountManagement: React.FC<PatientAccountManagementProps> = ({ 
  allowLockToggle = true 
}) => {
  const { 
    accounts, 
    patients, 
    adminToggleLockAccount, 
    adminResetPassword, 
    linkAccountToPatient,
    activeAccount
  } = useHospital();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'locked'>('all');
  const [showMaskedCccd, setShowMaskedCccd] = useState<Record<string, boolean>>({});

  // Modals
  const [selectedAccForReset, setSelectedAccForReset] = useState<UserAccount | null>(null);
  const [tempPasswordInput, setTempPasswordInput] = useState('Sontra@2026');
  const [resetSuccessMsg, setResetSuccessMsg] = useState<string | null>(null);

  const [selectedAccForLink, setSelectedAccForLink] = useState<UserAccount | null>(null);
  const [targetPatientId, setTargetPatientId] = useState<string>('');
  const [linkSuccessMsg, setLinkSuccessMsg] = useState<string | null>(null);

  // Filter only patient accounts
  const patientAccounts = accounts.filter(a => a.role === 'patient');

  const filteredAccounts = patientAccounts.filter(acc => {
    const matchesSearch = 
      acc.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      acc.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (acc.cccd && acc.cccd.includes(searchTerm)) ||
      (acc.phone && acc.phone.includes(searchTerm)) ||
      (acc.linkedPatientId && acc.linkedPatientId.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus = 
      statusFilter === 'all' ? true : 
      statusFilter === 'active' ? acc.status !== 'locked' : 
      acc.status === 'locked';

    return matchesSearch && matchesStatus;
  });

  // Mask CCCD helper (048099******)
  const formatCccd = (cccd?: string, isRevealed?: boolean) => {
    if (!cccd) return 'Chưa cập nhật';
    if (isRevealed) return cccd;
    if (cccd.length <= 6) return cccd;
    return `${cccd.slice(0, 6)}******`;
  };

  const toggleCccdVisibility = (accId: string) => {
    setShowMaskedCccd(prev => ({ ...prev, [accId]: !prev[accId] }));
  };

  // Find linked patient object
  const getLinkedPatient = (patientId?: string): Patient | undefined => {
    if (!patientId) return undefined;
    return patients.find(p => p.id === patientId);
  };

  // Detect potential duplicates
  const getDuplicateWarning = (acc: UserAccount): string | null => {
    if (!acc.cccd) return null;
    const sameCccdAccounts = patientAccounts.filter(a => a.cccd === acc.cccd);
    if (sameCccdAccounts.length > 1) {
      return `Phát hiện ${sameCccdAccounts.length} tài khoản có cùng số CCCD (${formatCccd(acc.cccd)})`;
    }
    return null;
  };

  const handleResetPassword = () => {
    if (!selectedAccForReset || !tempPasswordInput.trim()) return;
    adminResetPassword(selectedAccForReset.id, tempPasswordInput.trim());
    setResetSuccessMsg(`Đã đặt lại mật khẩu tạm thời cho bệnh nhân [${selectedAccForReset.name}] thành: ${tempPasswordInput.trim()}`);
    setTimeout(() => {
      setSelectedAccForReset(null);
      setResetSuccessMsg(null);
    }, 2000);
  };

  const handleLinkPatient = () => {
    if (!selectedAccForLink || !targetPatientId) return;
    const res = linkAccountToPatient(selectedAccForLink.id, targetPatientId);
    if (res.success) {
      setLinkSuccessMsg(res.message);
      setTimeout(() => {
        setSelectedAccForLink(null);
        setLinkSuccessMsg(null);
      }, 1500);
    }
  };

  return (
    <div className="space-y-5">
      {/* Header & Stats Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-blue-50 text-[#2878B5]">
                <Users className="w-5 h-5" />
              </span>
              <h2 className="text-base font-bold text-slate-900">
                Quản lý Tài khoản Bệnh nhân Ngoại trú
              </h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Quản lý định danh tài khoản bệnh nhân, liên kết hồ sơ y tế bệnh án, xử lý quên mật khẩu và bảo mật thông tin CCCD
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl font-medium text-slate-600">
              Tổng số tài khoản: <strong className="text-slate-900">{patientAccounts.length}</strong>
            </span>
            <span className="text-xs bg-emerald-50 border border-emerald-200 px-3 py-1.5 rounded-xl font-medium text-emerald-700">
              Hoạt động: <strong>{patientAccounts.filter(a => a.status !== 'locked').length}</strong>
            </span>
          </div>
        </div>

        {/* Security & Disclaimer Notice */}
        <div className="mt-4 p-3 bg-blue-50/60 rounded-xl border border-blue-200/60 text-xs text-slate-600 flex items-start gap-2.5">
          <ShieldCheck className="w-4 h-4 text-[#2878B5] shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <strong className="text-[#163A5F]">Nguyên tắc bảo vệ dữ liệu y tế:</strong> Mật khẩu người dùng được băm bảo mật (không hiển thị dạng văn bản thô). Số CCCD mặc định được che ký tự (`048099******`) để tuân thủ quyền riêng tư dữ liệu cá nhân theo Nghị định 13/2023/NĐ-CP.
          </div>
        </div>

        {/* Filter Controls */}
        <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo Tên, CCCD, Mã BN, SĐT..."
              className="w-full pl-9 pr-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder:text-slate-400 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <span className="text-xs text-slate-500 font-medium whitespace-nowrap">Trạng thái:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
            >
              <option value="all">Tất cả ({patientAccounts.length})</option>
              <option value="active">Đang hoạt động ({patientAccounts.filter(a => a.status !== 'locked').length})</option>
              <option value="locked">Bị khóa an ninh ({patientAccounts.filter(a => a.status === 'locked').length})</option>
            </select>
          </div>
        </div>
      </div>

      {/* Account Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-slate-600 font-bold border-b border-slate-200 uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Bệnh nhân / Tên đăng nhập</th>
                <th className="py-3 px-4">Định danh CCCD & SĐT</th>
                <th className="py-3 px-4">Hồ sơ bệnh án liên kết</th>
                <th className="py-3 px-4">Ngày đăng ký</th>
                <th className="py-3 px-4">Trạng thái tài khoản</th>
                <th className="py-3 px-4 text-right">Thao tác hỗ trợ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAccounts.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400 text-xs">
                    Không tìm thấy tài khoản bệnh nhân nào phù hợp với điều kiện tìm kiếm.
                  </td>
                </tr>
              ) : (
                filteredAccounts.map((acc) => {
                  const linkedPat = getLinkedPatient(acc.linkedPatientId);
                  const isRevealed = !!showMaskedCccd[acc.id];
                  const duplicateWarning = getDuplicateWarning(acc);
                  const isLocked = acc.status === 'locked';

                  return (
                    <tr key={acc.id} className="hover:bg-slate-50/60 transition-colors">
                      {/* Name & Username */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{acc.name}</div>
                        <div className="text-[11px] font-mono text-[#2878B5] mt-0.5 flex items-center gap-1.5">
                          <span>@{acc.username}</span>
                          {acc.registeredOnline && (
                            <span className="px-1.5 py-0.2 bg-teal-50 text-teal-700 text-[9px] rounded font-sans font-medium">
                              Online
                            </span>
                          )}
                        </div>
                      </td>

                      {/* CCCD & Phone */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-slate-700">
                          <span>{formatCccd(acc.cccd, isRevealed)}</span>
                          {acc.cccd && (
                            <button
                              type="button"
                              onClick={() => toggleCccdVisibility(acc.id)}
                              className="text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                              title={isRevealed ? 'Che số CCCD' : 'Xem số CCCD đầy đủ'}
                            >
                              {isRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <span>{acc.phone || 'Chưa có SĐT'}</span>
                        </div>
                        {duplicateWarning && (
                          <div className="mt-1 text-[10px] text-amber-600 font-medium flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 shrink-0" />
                            <span>{duplicateWarning}</span>
                          </div>
                        )}
                      </td>

                      {/* Linked Patient Profile */}
                      <td className="py-3.5 px-4">
                        {linkedPat ? (
                          <div className="space-y-0.5">
                            <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-[11px]">
                              {linkedPat.id}
                            </span>
                            <div className="text-[11px] text-slate-600 truncate max-w-[150px]">
                              {linkedPat.fullName} ({linkedPat.birthYear})
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <span className="text-[11px] text-amber-600 font-medium bg-amber-50 px-2 py-0.5 rounded">
                              Chưa liên kết
                            </span>
                            <div>
                              <button
                                type="button"
                                onClick={() => { setSelectedAccForLink(acc); setTargetPatientId(patients[0]?.id || ''); }}
                                className="text-[11px] text-[#2878B5] hover:underline flex items-center gap-1 cursor-pointer font-semibold"
                              >
                                <Link className="w-3 h-3" /> Liên kết hồ sơ
                              </button>
                            </div>
                          </div>
                        )}
                      </td>

                      {/* Registration Date */}
                      <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                        {acc.createdAt || 'N/A'}
                      </td>

                      {/* Status */}
                      <td className="py-3.5 px-4">
                        {isLocked ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <Lock className="w-3 h-3" /> Bị khóa an ninh
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3" /> Đang hoạt động
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Reset Password Button */}
                          <button
                            type="button"
                            onClick={() => { setSelectedAccForReset(acc); setTempPasswordInput('Sontra@2026'); setResetSuccessMsg(null); }}
                            className="px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 text-[11px] font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                            title="Đặt lại mật khẩu tạm thời"
                          >
                            <KeyRound className="w-3.5 h-3.5 text-[#2878B5]" />
                            <span>Cấp MK tạm</span>
                          </button>

                          {/* Lock/Unlock Toggle (Admin only) */}
                          {allowLockToggle && (
                            <button
                              type="button"
                              onClick={() => adminToggleLockAccount(acc.id)}
                              className={`p-1.5 rounded-lg border text-[11px] cursor-pointer transition-colors ${
                                isLocked
                                  ? 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                  : 'border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100'
                              }`}
                              title={isLocked ? 'Mở khóa tài khoản' : 'Khóa tài khoản khẩn cấp'}
                            >
                              {isLocked ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL: RESET PASSWORD */}
      {selectedAccForReset && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2878B5] flex items-center justify-center font-bold">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Cấp mật khẩu tạm thời</h3>
                  <p className="text-[11px] text-slate-500">Hỗ trợ bệnh nhân quên thông tin đăng nhập</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedAccForReset(null)}
                className="text-slate-400 hover:text-slate-600 p-1 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {resetSuccessMsg ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-700 flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{resetSuccessMsg}</span>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div><strong>Bệnh nhân:</strong> {selectedAccForReset.name}</div>
                  <div><strong>Tên đăng nhập:</strong> <span className="font-mono text-[#2878B5]">{selectedAccForReset.username}</span></div>
                  <div><strong>Số CCCD:</strong> <span className="font-mono">{formatCccd(selectedAccForReset.cccd, false)}</span></div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Mật khẩu tạm thời sẽ cấp:
                  </label>
                  <input
                    type="text"
                    value={tempPasswordInput}
                    onChange={(e) => setTempPasswordInput(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Bệnh nhân sẽ được yêu cầu đổi mật khẩu mới trong lần đăng nhập đầu tiên.
                  </span>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAccForReset(null)}
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Hủy bỏ
                  </button>
                  <button
                    type="button"
                    onClick={handleResetPassword}
                    className="px-4 py-2 rounded-lg bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
                  >
                    Xác nhận cấp lại
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* MODAL: LINK TO PATIENT RECORD */}
      {selectedAccForLink && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-6 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2878B5] flex items-center justify-center font-bold">
                  <Link className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">Liên kết tài khoản với hồ sơ bệnh án</h3>
                  <p className="text-[11px] text-slate-500">Đồng bộ tài khoản người dùng với hồ sơ HIS</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedAccForLink(null)}
                className="text-slate-400 hover:text-slate-600 p-1 text-sm font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            {linkSuccessMsg ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-700 flex items-center gap-2 mb-4">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{linkSuccessMsg}</span>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div><strong>Tài khoản:</strong> {selectedAccForLink.username} ({selectedAccForLink.name})</div>
                  <div><strong>Số CCCD:</strong> <span className="font-mono">{formatCccd(selectedAccForLink.cccd, false)}</span></div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Chọn hồ sơ bệnh nhân trong hệ thống:
                  </label>
                  <select
                    value={targetPatientId}
                    onChange={(e) => setTargetPatientId(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-medium text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-[#2878B5]"
                  >
                    {patients.map(p => (
                      <option key={p.id} value={p.id}>
                        [{p.id}] {p.fullName} - CCCD: {p.cccd} ({p.birthYear})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedAccForLink(null)}
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-600 hover:bg-slate-50 cursor-pointer"
                  >
                    Hủy bỏ
                  </button>
                  <button
                    type="button"
                    onClick={handleLinkPatient}
                    className="px-4 py-2 rounded-lg bg-[#2878B5] hover:bg-[#163A5F] text-white text-xs font-semibold shadow-xs cursor-pointer transition-colors"
                  >
                    Xác nhận liên kết
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
